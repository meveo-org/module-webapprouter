export const MEVEO_PATH = "/investigation-core";
export const MEVEO_PROVIDER = "SocialProfiles";
