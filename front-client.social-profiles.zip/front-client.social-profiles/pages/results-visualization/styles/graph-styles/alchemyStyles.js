import { css } from "lit-element";

export const AlchemyStyles = css`
  @-webkit-keyframes fadeIn {
      0% {
          opacity: 0
      }
      25% {
          opacity: .3
      }
      50% {
          opacity: .66
      }
      75% {
          opacity: 1
      }
  }
  @keyframes fadeIn {
      0% {
          opacity: 0
      }
      25% {
          opacity: .3
      }
      50% {
          opacity: .66
      }
      75% {
          opacity: 1
      }
  }
  @-webkit-keyframes pulse {
      0% {
          text-shadow: 0 0 10px rgba(255, 255, 255, .2), 0 0 12px rgba(255, 255, 255, .2), 0 0 16px rgba(255, 255, 255, .2)
      }
      25% {
          text-shadow: 0 0 12px rgba(255, 255, 255, .2), 0 0 15px rgba(255, 255, 255, .2), 0 0 20px rgba(255, 255, 255, .2), 0 0 6px rgba(104, 185, 254, .7), 0 0 10px rgba(104, 185, 254, .7)
      }
      50% {
          text-shadow: 0 0 12px rgba(255, 255, 255, .2), 0 0 15px rgba(255, 255, 255, .2), 0 0 20px rgba(255, 255, 255, .2), 0 0 8px rgba(104, 185, 254, .7), 0 0 10px rgba(104, 185, 254, .7), 0 0 15px rgba(104, 185, 254, .7)
      }
      75% {
          text-shadow: 0 0 12px rgba(255, 255, 255, .2), 0 0 15px rgba(255, 255, 255, .2), 0 0 25px rgba(255, 255, 255, .2), 0 0 8px rgba(104, 185, 254, .7), 0 0 12px rgba(104, 185, 254, .7), 0 0 15px rgba(104, 185, 254, .7), 0 0 20px rgba(104, 185, 254, .7)
      }
  }
  @keyframes pulse {
      0% {
          text-shadow: 0 0 10px rgba(255, 255, 255, .2), 0 0 12px rgba(255, 255, 255, .2), 0 0 16px rgba(255, 255, 255, .2)
      }
      25% {
          text-shadow: 0 0 12px rgba(255, 255, 255, .2), 0 0 15px rgba(255, 255, 255, .2), 0 0 20px rgba(255, 255, 255, .2), 0 0 6px rgba(104, 185, 254, .7), 0 0 10px rgba(104, 185, 254, .7)
      }
      50% {
          text-shadow: 0 0 12px rgba(255, 255, 255, .2), 0 0 15px rgba(255, 255, 255, .2), 0 0 20px rgba(255, 255, 255, .2), 0 0 8px rgba(104, 185, 254, .7), 0 0 10px rgba(104, 185, 254, .7), 0 0 15px rgba(104, 185, 254, .7)
      }
      75% {
          text-shadow: 0 0 12px rgba(255, 255, 255, .2), 0 0 15px rgba(255, 255, 255, .2), 0 0 25px rgba(255, 255, 255, .2), 0 0 8px rgba(104, 185, 254, .7), 0 0 12px rgba(104, 185, 254, .7), 0 0 15px rgba(104, 185, 254, .7), 0 0 20px rgba(104, 185, 254, .7)
      }
  }
  @-webkit-keyframes slide-in {
      0% {
          -webkit-transform: translate(-100%, 0);
          transform: translate(-100%, 0)
      }
      100% {
          -webkit-transform: translate(0%, 0);
          transform: translate(0%, 0)
      }
  }
  @keyframes slide-in {
      0% {
          -webkit-transform: translate(-100%, 0);
          transform: translate(-100%, 0)
      }
      100% {
          -webkit-transform: translate(0%, 0);
          transform: translate(0%, 0)
      }
  }
  @-webkit-keyframes slide-out {
      0% {
          -webkit-transform: translate(0%, 0);
          transform: translate(0%, 0)
      }
      100% {
          -webkit-transform: translate(-100%, 0);
          transform: translate(-100%, 0)
      }
  }
  @keyframes slide-out {
      100% {
          -webkit-transform: translate(-100%, 0);
          transform: translate(-100%, 0)
      }
  }
  .alchemy svg {
      /*position: absolute;*/
      display: block;
      cursor: -webkit-grab;
      height: 100%;
      width: 100%;
      color: #333
  }
  .node {
      cursor: pointer
  }
  .node text.root {
      font-size: 32px
  }
  .node text {
      display: none;
      fill: #0e0f75;
      font-weight: 200;
      text-anchor: middle;
      z-index: 1000;
  }
  .node.active {
      opacity: 1
  }
  .node.active.selected text,
  .node.active:hover text {
      display: block
  }
  defs #arrow path {
      stroke: #CCC;
      stroke-opacity: .2;
      fill: #CCC;
      opacity: 1
  }
  .edge text {
      stroke-width: 0
  }
  .edge .edge-handler {
      fill: none;
      stroke: none
  }
  .edge .edge-line {
      fill: none
  }
  .edge.active text {
      display: none;
      fill: #000000;
      font-weight: 200;
      text-anchor: middle;
      z-index: 1000
  }
  .edge.active.selected,
  .edge.active:hover {
      cursor: pointer
  }
  .edge.active.highlight text,
  .edge.active.selected text,
  .edge.active:hover text {
      display: block
  }
  #zoom-controls {
      background-color: transparent;
      background-image: url(images/maze-black.png);
      border-top-right-radius: 3px;
      border-bottom-right-radius: 3px;
      box-shadow: 0 0 5px rgba(255, 255, 255, .3);
      margin-top: 10%;
      z-index: 5;
      position: relative;
      display: block;
      width: 55px
  }
  #zoom-controls #zoom-in,
  #zoom-controls #zoom-out,
  #zoom-controls #zoom-reset {
      padding: 12px;
      margin: 0;
      width: 100%
  }
  #zoom-controls #zoom-in i,
  #zoom-controls #zoom-out i,
  #zoom-controls #zoom-reset i {
      color: #E89619
  }
  #zoom-controls #zoom-in:hover,
  #zoom-controls #zoom-out:hover,
  #zoom-controls #zoom-reset:hover {
      background-color: rgba(255, 255, 255, .2)
  }
  #zoom-controls #zoom-in:active,
  #zoom-controls #zoom-out:active,
  #zoom-controls #zoom-reset:active {
      border: 0
  }
  .fa-caret-down,
  .fa-caret-right,
  .fa-search {
      margin: 0 5px;
      color: #e89619
  }
  #search {
      margin-top: 2em;
      margin-bottom: 1em;
      padding: .5em 1em;
      width: 100%
  }
  #search span {
      vertical-align: bottom
  }
  #search input {
      background-color: #000;
      border: 0;
      font-size: 20px;
      color: #fff;
      padding-left: .5em
  }
  #search .search-icon {
      height: 22px;
      background-color: #000;
      border-color: #000;
      border-right-color: #111
  }
  #stats {
      padding: .5em 1em;
      background-color: transparent;
      border-bottom: thin dashed #e89619
  }
  #stats #stats-header {
      padding: 10px
  }
  #stats #all-stats {
      color: #fff;
      border-radius: none;
      border: 0;
      background: 0 0;
      overflow: auto
  }
  #stats #all-stats li {
      padding: 3px
  }
  #stats #edge-stats-graph,
  #stats #node-stats-graph {
      height: 250px
  }
  #stats #edge-stats-graph svg,
  #stats #node-stats-graph svg {
      opacity: .6;
      background: 0 0
  }
  #stats #edge-stats-graph text,
  #stats #node-stats-graph text {
      font-size: 16px;
      fill: #fff;
      font-weight: 200;
      text-anchor: middle;
      z-index: 1000
  }
  #stats #edge-stats-graph .no-data,
  #stats #node-stats-graph .no-data {
      margin: 30px 0;
      color: #e89619
  }
  #stats .badge {
      border-radius: 0;
      height: 100%;
      background-color: rgba(104, 185, 254, .6)
  }
  #editor {
      padding: .5em 1em;
      background-color: transparent;
      border-bottom: thin dashed #e89619
  }
  #editor h3 {
      padding: 10px
  }
  #editor #element-options {
      display: -webkit-flex;
      display: flex;
      -webkit-flex-direction: column;
      flex-direction: column;
      cursor: pointer;
      margin-top: 10px;
      margin-left: 2%;
      color: #fff
  }
  #editor #element-options #add-property-form,
  #editor #element-options .property {
      display: -webkit-inline-flex;
      display: inline-flex;
      margin: 4px 0;
      width: 100%
  }
  #editor #element-options #add-property-form #add-property #add-prop-value,
  #editor #element-options .property-value {
      border: thin rgba(255, 255, 255, .2) solid;
      border-left: 0;
      background-color: #000;
      color: #fff;
      width: 100%;
      border-top-left-radius: 0;
      border-bottom-left-radius: 0
  }
  #editor #element-options #add-property-form #add-property #add-prop-key,
  #editor #element-options .property-name {
      text-align: center;
      font-weight: 200;
      cursor: default;
      background: #2E2E2E;
      border: thin transparent solid;
      color: #e89619;
      border-right: 0;
      border-top-right-radius: 0;
      border-bottom-right-radius: 0
  }
  #editor #element-options #update-properties,
  #editor #element-options input[type=submit] {
      color: #e89619;
      border-top-right-radius: 4px;
      border-bottom-right-radius: 4px;
      width: auto;
      background: rgba(255, 255, 255, .1);
      border: thin solid #e89619;
      text-align: center
  }
  #editor #element-options #update-properties:active,
  #editor #element-options #update-properties:focus,
  #editor #element-options input[type=submit]:active,
  #editor #element-options input[type=submit]:focus {
      outline: 0
  }
  #editor #element-options #update-properties:hover,
  #editor #element-options input[type=submit]:hover {
      color: #fff;
      border: thin solid #fff
  }
  #editor #element-options #update-properties {
      border-radius: 4px;
      padding: 10px;
      width: 100%;
      margin-bottom: 20px
  }
  #editor #element-options #add-property-form #add-property {
      display: -webkit-flex;
      display: flex;
      -webkit-flex-grow: 2;
      flex-grow: 2;
      -webkit-flex-direction: column;
      flex-direction: column
  }
  #editor #element-options #add-property-form #add-property #add-prop-value {
      text-align: center;
      width: 100%;
      border-top-right-radius: 0;
      border-bottom-right-radius: 0;
      border-bottom-left-radius: 4px;
      border: thin rgba(255, 255, 255, .2) solid
  }
  #editor #element-options #add-property-form #add-property #add-prop-key {
      cursor: text;
      width: 100%;
      border-top-left-radius: 4px;
      border-bottom-left-radius: 0
  }
  #editor #editor-interactions.active {
      color: #e89619
  }
  #editor #editor-interactions.inactive {
      color: #fff
  }
  #editor #edge-editor.enabled,
  #editor #node-editor.enabled {
      -webkit-animation: fadeIn 1s linear;
      animation: fadeIn 1s linear
  }
  #control-dash-wrapper {
      font-family: 'Source Sans Pro', Helvetica, sans-serif;
      letter-spacing: .05em;
      height: inherit;
      z-index: inherit;
      padding: 0
  }
  #control-dash-wrapper.initial {
      -webkit-transform: translate(-100%, 0);
      transform: translate(-100%, 0)
  }
  #control-dash-wrapper.initial #dash-toggle {
      color: #e89619;
      -webkit-animation: 4s pulse linear;
      animation: 4s pulse linear
  }
  #control-dash-wrapper.off-canvas {
      -webkit-transform: translate(-100%, 0);
      transform: translate(-100%, 0);
      -webkit-animation: slide-out .75s linear;
      animation: slide-out .75s linear
  }
  #control-dash-wrapper.off-canvas #dash-toggle {
      color: #e89619;
      -webkit-animation: 4s pulse linear;
      animation: 4s pulse linear
  }
  #control-dash-wrapper.on-canvas {
      -webkit-animation: slide-in .75s ease-in-out;
      animation: slide-in .75s ease-in-out
  }
  #control-dash-wrapper.on-canvas * {
      box-shadow: none!important
  }
  #control-dash-wrapper.on-canvas #dash-toggle {
      color: rgba(232, 150, 25, .6)
  }
  #control-dash-wrapper.on-canvas #dash-toggle:hover {
      color: #e89619;
      -webkit-animation: 4s pulse linear;
      animation: 4s pulse linear
  }
  #control-dash-wrapper #control-dash {
      overflow-x: hidden;
      overflow-y: scroll;
      background-color: transparent;
      background-image: url(images/maze-black.png);
      padding: 0;
      height: inherit;
      z-index: 5
  }
  #control-dash-wrapper #control-dash h3 {
      display: inline;
      margin: 0
  }
  #control-dash-wrapper #dash-toggle {
      z-index: 5;
      background-color: transparent;
      background-image: url(images/maze-black.png);
      border-top-right-radius: 3px;
      border-bottom-right-radius: 3px;
      box-shadow: 0 0 5px rgba(255, 255, 255, .3);
      position: absolute;
      left: 0;
      top: 50%;
      font-size: 2.2em;
      color: rgba(255, 255, 255, .2);
      padding: 10px
  }
  #control-dash-wrapper button {
      border-radius: 0;
      border: 0;
      background-color: transparent
  }
  #control-dash-wrapper button:active {
      border: 0
  }
  #control-dash-wrapper h3 {
      font-weight: 200;
      margin-top: 10px;
      color: #fff;
      cursor: pointer;
      vertical-align: top
  }
  #control-dash-wrapper li {
      cursor: pointer;
      background: 0 0;
      border: 0;
      border-radius: 0
  }
  #clustering {
      padding: .5em 1em;
      cursor: pointer;
      color: #fff;
      border-bottom: thin dashed #E89619
  }
  #clustering #cluster-key-container,
  #clustering #cluster_control_header {
      padding: 10px 10px 0
  }
  #clustering #cluster-key {
      color: #333;
      background-color: #000;
      border-radius: 4px;
      border: thin solid #333;
      text-align: center;
      display: inline-block;
      width: 100%
  }
  #filters {
      padding: .5em 1em;
      background-color: transparent;
      border-bottom: thin dashed #e89619;
      color: #fff
  }
  #filters form {
      width: 100%
  }
  #filters #filter-header {
      padding: 10px
  }
  #filters #filter-nodes,
  #filters #filter-relationships {
      background-color: transparent;
      display: inline-block;
      width: 45%;
      margin-left: 2%;
      overflow: auto;
      text-align: center;
      vertical-align: top
  }
  #filters #filter-nodes #filter-node-header,
  #filters #filter-nodes #filter-rel-header,
  #filters #filter-relationships #filter-node-header,
  #filters #filter-relationships #filter-rel-header {
      margin: 10px 0;
      cursor: pointer;
      background-color: transparent;
      border: 0;
      border-radius: 0;
      width: 100%
  }
  #filters #filter-nodes #filter-node-header h4,
  #filters #filter-nodes #filter-rel-header h4,
  #filters #filter-relationships #filter-node-header h4,
  #filters #filter-relationships #filter-rel-header h4 {
      font-weight: 200;
      display: inline;
      color: #fff
  }
  #filters #filter-nodes #filter-node-header:active,
  #filters #filter-nodes #filter-rel-header:active,
  #filters #filter-relationships #filter-node-header:active,
  #filters #filter-relationships #filter-rel-header:active {
      border: 0;
      box-shadow: none
  }
  #filters #filter-nodes #node-dropdown,
  #filters #filter-nodes #rel-dropdown,
  #filters #filter-relationships #node-dropdown,
  #filters #filter-relationships #rel-dropdown {
      margin: 20px 0;
      border-radius: none;
      border: 0;
      background: 0 0
  }
  #filters #filter-nodes #node-dropdown li,
  #filters #filter-nodes #rel-dropdown li,
  #filters #filter-relationships #node-dropdown li,
  #filters #filter-relationships #rel-dropdown li {
      padding: 5px
  }
  #filters #filter-nodes #node-dropdown li:hover,
  #filters #filter-nodes #rel-dropdown li:hover,
  #filters #filter-relationships #node-dropdown li:hover,
  #filters #filter-relationships #rel-dropdown li:hover {
      background-color: rgba(255, 255, 255, .2)
  }
  #filters .disabled {
      color: rgba(255, 255, 255, .5)
  }
  #filters .disabled:hover {
      color: #fdc670
  }
  .alchemy {
      position: relative
  }
  .alchemy #search form {
      z-index: 2;
      display: inline;
      margin-left: 100px
  }
  .alchemy #add-tag {
      width: 300px;
      display: inline-block
  }
  .alchemy #tags input {
      max-width: 220px
  }
  .alchemy #tags-list {
      padding: 0
  }
  .alchemy #tags-list .icon-remove-sign {
      cursor: pointer
  }
  .alchemy #tags-list li {
      display: inline-block;
      margin-top: 5px
  }
  .alchemy #tags-list span {
      background-color: #ccc;
      color: #333;
      border-radius: 10em;
      display: inline-block;
      padding: 1px 6px
  }
  .alchemy #filter-nodes label,
  .alchemy #filter-relationships label {
      font-weight: 400;
      margin-right: 1em
  }
  .alchemy .clear {
      clear: both
  }
  .alchemy text {
      font-weight: 200;
      text-anchor: middle
  }
`;
