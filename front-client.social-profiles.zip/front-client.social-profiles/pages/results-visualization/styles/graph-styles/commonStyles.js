import { LitElement, html, css } from "lit-element";
export const CommonStyles = css`
  html {
      position: relative;
      min-height: 100%;
      font-family: sans-serif;
      -webkit-text-size-adjust: 100%;
          -ms-text-size-adjust: 100%;
  }
  body {
      font-family: "SourceSansPro", Gill Sans, Helvetica, Arial, " sans-serif";
      /*font-size: 1.5em;*/
      font-size: 14px;
      color: #404649 !important;
      text-rendering: optimizeLegibility;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
      margin: 0;
  }
  mark {
    color: #000;
    background: #ff0;
  }
  small {
    font-size: 80%;
  }
  h1 {
    margin: .67em 0;
    font-size: 2em;
  }
  .h4, h4 {
      font-size: 1.2em;
      font-weight: normal;
  }
  sub,
  sup {
    position: relative;
    font-size: 75%;
    line-height: 0;
    vertical-align: baseline;
  }
  sup {
    top: -.5em;
  }
  sub {
    bottom: -.25em;
  }
  img {
    border: 0;
  }
  svg:not(:root) {
    overflow: hidden;
  }

  div#iep_module {
    padding-top: 0 !important;
  }
  img, iframe, canvas, svg {
      max-width: 100%;
  }
  a {
      text-decoration: none;
      cursor: pointer;
  }
  a:hover, a:focus {
      text-decoration: none;
      cursor: pointer;
  }
  p {
      /*font-size: 16px;*/
      /*line-height: 24px;*/
      /*padding: 10px;*/
      /*margin: 10px 0;*/
      color: #666;
  }
  .clear {
      clear: both;
  }
  section {
      display: block;
      padding: 40px 0 0 0;
      /*min-height: 400px;*/
      height: auto;
      clear: both;
  }

  .text-center {
      text-align: center;
  }

  .text-right {
      text-align: right;
  }

  .text-left {
      text-align: left;
  }

  .text-bold{
    font-weight: 600;
  }

  label {

    font-weight: normal;

  }
  hr {
      background-color: #002050;
      width: 50px;
      height: 2px;
      display: inline-block;
      margin-bottom: 0;
      margin-top: 10px;
      border: 0;
      border-top: 1px solid rgba(0, 32, 80, .1);
      box-sizing: content-box;
  }
  .hide {
      display: none !important
  }

  .show {
      display: block !important
  }

  .hidden,
  .visible-lg,
  .visible-md,
  .visible-sm,
  .visible-xs {
      display: none !important
  }

  .invisible {
      visibility: hidden
  }

  .text-hide {
      font: 0/0 a;
      color: transparent;
      text-shadow: none;
      background-color: transparent;
      border: 0
  }

  .hidden {
      visibility: hidden !important
  }

  .affix {
      position: fixed
  }

  .row {
      margin: 0;
      padding: 0;
  }

  .fs0 {
      font-size: 12px !important;
  }
  .fs1 {
      font-size: 16px !important;
  }
  .fs2 {
      font-size: 20px !important;
  }
  .fs3 {
      font-size: 24px !important;
  }
  .fs4 {
      font-size: 40px !important;
  }

  /* up to 767px) */
  @media (max-width:767px) {
      #content {
          margin-top: 59px;
      }
  }

  /* 394px up to 435px) */
  @media (min-width: 394px)
  and (max-width:435px) {
      #content {
          margin-bottom: 145px;
      }
  }

  /* 393px and below) */
  @media (max-width:393px) {
      #content {
          margin-bottom: 155px;
      }
  }
`;
