import { css } from "lit-element";

export const BpStyles = css`
  .graph_page .node-urls-tooltip > body {
    box-sizing: border-box;
    padding: 0 10px;
  }

  .results-header {
    display: flex;
  }

  .results-header .keyword-header {
    width: 25%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px;
    color: #4E686D;
  }
  .results-header .tag-header {
    width: 15%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px;
    color: #4E686D;
  }
  .results-header .url-header {
    width: 30%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px;
    color: #4E686D;
  }
  .results-header .index-header {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px;
    color: #4E686D;
  }

  .results-header .publication-header {
    width: 20%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px;
  }

  .urls-filters {
    display: flex;
    text-align: left !important;
    width: 98%;
    margin: auto;
    height: 66px;
    align-items: center;
  }

  .urls-filters input[type].form-control {
    margin: 8px 0;
    font-size: 16px;
    padding: 15px 20px;
    -webkit-align-items: center;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    background-color: hsl(0,0%,100%);
    border-color: hsl(0,0%,80%);
    border-radius: 4px;
    border-style: solid;
    border-width: 1px;
    cursor: default;
    display: -webkit-box;
    display: -webkit-flex;
    display: -ms-flexbox;
    display: flex;
    -webkit-flex-wrap: wrap;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -webkit-box-pack: justify;
    -webkit-justify-content: space-between;
    -ms-flex-pack: justify;
    justify-content: space-between;
    min-height: 38px;
    outline: 0 !important;
    position: relative;
    -webkit-transition: all 100ms;
    transition: all 100ms;
    box-sizing: border-box;
    color: #80828C;
    width: 95%;
    font-family: 'MuseoSans', Arial, sans-serif;
    margin: auto;
  }

  .urls-filters .keyword-filter {
    width: 25%;
  }

  .urls-filters .tag-filter {
    width: 15%;
  }

  .urls-filters .website-filter {
    width: 30%;
  }

  .urls-filters .index-filter {
    width: 10%;
  }

  .urls-filters .publication-filter {
    width: 20%;
  }

  .urls-filters input {
    width: 95%;
    margin: auto;
  }

  .url-details {
    display: flex;
    height: 66px !important;
  }

  .url-details:hover {
    background-color: #EDEDED;
  }

  .url-details .keywords-info {
    width: 25%;
    box-sizing: border-box;
    padding: 0 10px;
    color: #80828C !important;
  }

  .url-details .tags-info {
    width: 15%;
    box-sizing: border-box;
    padding: 0 10px;
    color: #80828C !important;
  }

  .url-details .url-info {
    width: 30%;
    box-sizing: border-box;
    padding: 0 10px;
    color: #80828C !important;
  }

  .url-details .indexes-info {
    width: 10%;
    box-sizing: border-box;
    padding: 0 10px;
    color: #80828C !important;
  }

  .url-details .publicationDate-info {
    width: 20%;
    box-sizing: border-box;
    padding: 0 10px;
    color: #80828C !important;
  }

  .group-nodes-headers {
    display: flex;
  }

  .graph_page .node-urls-tooltip .urls-list {
    height: 400px !important;
  }

  .graph_page .node-urls-tooltip .urls-cols-headers {
    background-color: #F5F6FA !important;
    border-radius: 0 !important;
    width: 98% !important;
    text-align: left !important;
    margin: auto;
    font-size:1.2em;
    font-weight: 700;
    text-transform: uppercase;
    height: 66px !important;
    align-items: center;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details {
    width: 98%;
    padding: 0 !important;
    margin: auto;
    display: flex;
    align-items: center;
    height: 66px !important;
    border-bottom: 1px solid #E9E9E9 !important;
  }

  .urls-header {
    background-color: #fff !important;
    color: #64666E;
    text-align: left !important;
  }

  .urls-header h1 {
    font-family: 'Comfortaa-Bold', sans-serif;
    font-size: 30px;
    font-weight: 500px;
    line-height: 30px;
    color: #64666E;
    padding: 0 10px;
  }

  /* NODE HEADERS */
  .graph_page .group-nodes-tooltip .group-header {
    line-height: 2em;
    font-family: 'MuseoSans', Arial, sans-serif;
    font-size: 1em;
    text-align: left !important;
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .graph_page .group-nodes-tooltip .group-header h1 {
    font-family: 'Comfortaa-Bold', sans-serif;
    font-size: 30px;
    font-weight: 500px;
    line-height: 30px;
    color: #64666E;
    padding: 0 10px;
  }

  .group-nodes-headers {
    display: flex;
  }

  .group-nodes-headers .activity-code-header {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }
  .group-nodes-headers .activity-description-header {
    width: 25%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }
  .group-nodes-headers .date-header {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .address-header {
    width: 40%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .sanction-comment {
    width: 40%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .sanction-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .person-name {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .person-pos {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .person-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .person-birth-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .company-type-label {
    width: 40%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .company-type-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .company-name {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .company-id {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .company-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .company-status {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .status-header {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-headers .source-header {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }
  .group-nodes-headers .spacer-header {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  /* NODE DETAILS */

  .group-nodes-details {
    display: flex;
  }

  .group-nodes-details .activity-code-detail {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .activity-desc {
    width: 25%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .activity-mandate-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .node-details-status {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }
  .group-nodes-details .node-details-source-name {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .node-details-watch {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .nodes-address {
    width: 40%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .address-mandate-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .person-name {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .person-label {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .person-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .person-birth-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .sanction-comment {
    width: 40%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .sanction-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .company-type-label {
    width: 40%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .company-type-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .company-name {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .company-id {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .company-date {
    width: 16%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .group-nodes-details .company-status {
    width: 10%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    box-sizing: border-box;
    padding: 0 10px !important;
    color: #80828C !important;
  }

  .graph_page .group-nodes-tooltip .group-nodes-list .group-nodes-headers {
    border: 0 !important;
    height: 66px;
    display: flex;
    color: #4E686D !important;
    background-color: #F5F6FA !important;
    align-items: center;
    font-size:1.2em;
    text-transform: uppercase;
  }

  .graph_page #nodes-groupList-tooltip .group-filters-options {
    display: flex;
    text-align: left !important;
    justify-content: flex-end;
    width: 98%;
    margin: auto;
    height: 40px;
    align-items: center;
  }

  .graph_page .group-nodes-tooltip .group-nodes-details {
    height: 66px !important;
    display: flex;
    align-items: center;
    padding: 0.5rem;
    border-bottom: 1px solid #E9E9E9 !important;
  }

  .graph_page .group-nodes-tooltip .group-nodes-details:hover  {
    background-color: #EDEDED;
  }

  .paginator-block {
    margin-top: 25px !important;
  }
`;
