import { css } from "lit-element";

export const GraphStyles = css`
  :host {
    display: block;
    margin: 0;
    padding: 0;
  }

  .graph_page {
    height: 70%;
    margin: 0;
    padding: 0;
  }

  .graph_page .node {
      text-align: center;
  }
  .graph_page .QueryCategory text {
      font-size: 1.5em;
  }
  .graph_page text,
  .graph_page a,
  .graph_page p,
  .graph_page span,
  .graph_page div {
      font-family: "MuseoSans", sans-serif;
      font-size: 1em;
      color: #525c60;
  }

  .graph_page .svg {
      background: #FFFFFF !important;
  }

  .node.Person text {
      fill: #af62a5;
  }

  .node.website text {
      fill: #6586c1;
  }

  .node text {
      fill: #404649;
  }

  .graph_page .alchemy {
      width: 100% !important;
      height: calc(100% - 200px);
      margin: 0 auto;      
  }

  .graph_page div.map > div {
      position: inherit !important;
  }

  .graph_page #nodes-groupList-tooltip .group-filters-options {
    text-align: right;
  }

  .graph_page #nodes-groupList-tooltip .group-filters-options .filters-options-label {
    font-size: 16px;
    margin-right: 40px;
  }

  .graph_page .group-filters-options .verified-info,
  .node .groupNodes_stats .verified-info{
    background-color: #3e94d1;
  }
  .graph_page .group-filters-options .notfound-info,
  .node .groupNodes_stats .notfound-info{
    background-color: #fdb73d;
  }
  .graph_page .group-filters-options .outdated-info,
  .node .groupNodes_stats .outdated-info{
    background-color: #8a8a8a;
  }
  .graph_page .group-filters-options .new-info,
  .node .groupNodes_stats .new-info{
    background-color: #a199e4;
  }
  .graph_page #nodes-groupList-tooltip .group-filters-options [class^="wd-"],
  .graph_page #nodes-groupList-tooltip .group-filters-options [class*=" wd-"],
  .graph_page .groupNodes_stats [class^="wd-"],
  .graph_page .groupNodes_stats [class*=" wd-"]{
    color: white;
    border-radius: 20px;
  }

  /** CARTO **/

  .edge .edge-line {
      stroke: #bab9ba;
  }

  .edge .edge-line + text {
      fill: #bab9ba;
  }

  .inactive-node {
      opacity: 0.5;
  }

  .inactiveEdge.level-1 .edge-line {
      stroke: #f00 !important;
  }

  .inactiveEdge.level-2 .edge-line {
      stroke: #fdb129 !important;
  }

  .graph_page .subtable-title {
      color: #FFFFFF !important;
  }

  /************** NODES GROUPS DETAILS LIST **********/
  .graph_page .group-nodes-tooltip body {
    border: 1px solid #cccccc;
    -webkit-border-radius: 20px;
    -moz-border-radius: 20px;
    border-radius: 20px;
    background-color: white !important;
    overflow: hidden;
    height: 300px;
  }
  .graph_page .group-nodes-tooltip .group-nodes-list {
    text-align: left;
    padding: 5px 10px;
    height: 500px;
    overflow: auto;
  }
  .graph_page .group-nodes-tooltip .group-header {
    padding: 5px 0;
    text-align: center;
    color: #FFFFFF;
  }
  .graph_page .group-nodes-tooltip .group-header .tooltip-close-btn {
    float: right;
    margin: 6px 15px;
  }
  .graph_page .group-nodes-tooltip .group-nodes-list div {
    margin: 0;
    padding: 0;
  }
  .graph_page .group-nodes-tooltip .group-nodes-list .group-nodes-headers {
    border-top: 1px solid #cecece;
    border-bottom: 1px solid #cecece;
  }
  .graph_page .group-nodes-tooltip .group-nodes-list .group-nodes-headers div {
    font-weight: 600;
  }
  .graph_page .group-nodes-tooltip .group-nodes-details {
    border-bottom: 2px solid #cecece;
    line-height: 2;
    padding: 0 5px;
    height: 40px;
  }
  .graph_page .group-nodes-tooltip .group-nodes-details div{
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
  .graph_page .group-nodes-tooltip .group-nodes-details .group-node-action-btn {
    padding: 10px 0;
    text-align: center;
  }
  .graph_page .group-nodes-tooltip .group-nodes-details .group-node-action-btn .wd-eye {
    color: #5977b3 !important;
  }
  /********************************************/

  .graph_page .node-tooltip:hover {
      display: block !important;
  }

  /** Tooltips Infos noeuds **/

  .graph_page .node-tooltip, .graph_page .edge-tooltip {
      padding: 10px 0px 80px 0;
  }

  .graph_page .node-tooltip > body {
      background-color: white !important;
  }

  .graph_page .edge-tooltip > body {
      background-color: #d9d9d9 !important;
  }

  .graph_page .node-tooltip > body, .graph_page .edge-tooltip > body {
      padding: 20px;
      -webkit-box-shadow: 0 0 30px rgba(66, 66, 66, 0.3);
      -moz--webkit-box-shadow: 0 0 30px rgba(66, 66, 66, 0.3);
      box-shadow: 0 0 30px rgba(66, 66, 66, 0.3);
      -webkit-border-radius: 20px;
      -moz-border-radius: 20px;
      border-radius: 20px;
      height: 100%;
      width: 90%;
      margin: 40px auto;
  }

  .graph_page .node-tooltip > body > div.node-header, .graph_page .edge-tooltip > body > div.edge-header {
      padding: 10px 0 10px 0;
      font-size: 2em;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-agent,
  .graph_page .node-tooltip > body > div.node-header i.wd-agent + span {
      color: #8587f1;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-map-marker,
  .graph_page .node-tooltip > body > div.node-header i.wd-map-marker + span {
      color: #c485f0;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-apartment,
  .graph_page .node-tooltip > body > div.node-header i.wd-apartment + span {
      color: #54cab5;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-library,
  .graph_page .node-tooltip > body > div.node-header i.wd-library + span {
      color: #fd74ab;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-at-sign,
  .graph_page .node-tooltip > body > div.node-header i.wd-at-sign + span {
      color: #f29c72;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-credit-card,
  .graph_page .node-tooltip > body > div.node-header i.wd-credit-card + span {
      color: #9d8c98;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-phone,
  .graph_page .node-tooltip > body > div.node-header i.wd-phone + span {
      color: #13a3a6;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-tag,
  .graph_page .node-tooltip > body > div.node-header i.wd-tag + span {
      color: #8587f1;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-site,
  .graph_page .node-tooltip > body > div.node-header i.wd-site + span {
      color: #78d9ea;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-cash-euro,
  .graph_page .node-tooltip > body > div.node-header i.wd-cash-euro + span {
      color: #fdb73d;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-magnifier,
  .graph_page .node-tooltip > body > div.node-header i.wd-magnifier + span {
      color: #669900;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-document,
  .graph_page .node-tooltip > body > div.node-header i.wd-document + span {
      color: #669999;
  }

  /******** Query Category ********/
  .graph_page .node-tooltip > body > div.node-header i.wd-bag,
  .graph_page .node-tooltip > body > div.node-header i.wd-bag + span {
      color: #60be92;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-pencil-ruler2,
  .graph_page .node-tooltip > body > div.node-header i.wd-pencil-ruler2 + span {
      color: #fdb73d;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-light,
  .graph_page .node-tooltip > body > div.node-header i.wd-light + span {
      color: #a199e3;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-factory,
  .graph_page .node-tooltip > body > div.node-header i.wd-factory + span {
      color: #c485f0;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-puzzle,
  .graph_page .node-tooltip > body > div.node-header i.wd-puzzle + span {
      color: #78d9ea;
  }

  /*********************************/

  .graph_page .node-tooltip > body > div.node-header i.wd-database,
  .graph_page .node-tooltip > body > div.node-header i.wd-database + span {
      color: #80828c;
  }

  .graph_page .node-tooltip > body > div.node-header i.wd-list4,
  .graph_page .node-tooltip > body > div.node-header i.wd-list4 + span {
      color: #ffc43d;
  }

  .graph_page .node-tooltip > body > div > span {
      margin: 0 10px;
  }

  .graph_page .active-tooltip {
      display: block !important;
  }

  .graph_page #nodes-tooltip-group {
      -webkit-user-select: text;
      -khtml-user-select: text;
      -moz-user-select: text;
      -ms-user-select: text;
      -o-user-select: text;
      user-select: text;
  }

  .graph_page .close-tooltip-btn {
      color: black !important;
      cursor: pointer;
      float: right;
  }

  .graph_page .copy-status {
      margin-left: 5px;
  }

  .graph_page .node-score body {
      border-radius: 50%;
      font-size: 15px;
      line-height: 2.4;
  }

  .graph_page .node-score body span {
      color: white;
      font-family: "SourceSansPro";
  }

  .graph_page .node-scores-tooltip body {
      border-radius: 10%;
  }

  .graph_page .node-scores-tooltip .score-tooltip-icon {
      width: 50px;
      height: 50px;
      display: inline-block;
  }

  .graph_page .node-scores-tooltip .bing-icon, .graph_page .node-queries-tooltip .query_details .bing-icon {
      background: url("../images/graph/bing-icon.png") center /cover no-repeat;
  }

  .graph_page .node-scores-tooltip .twitter-icon, .graph_page .node-queries-tooltip .query_details .twitter-icon {
      background: url("../images/graph/twitter-icon.png") center /cover no-repeat;
  }

  .graph_page .node-scores-tooltip .google-icon, .graph_page .node-queries-tooltip .query_details .google-icon {
      background: url("../images/graph/google-icon.png") center /cover no-repeat;
  }

  .graph_page .node-urls-tooltip .urls-cols-headers {
      height: 65px;
      text-align: center;
      background-color: #b8b9bf;
      border-radius: 20px;
      margin-bottom: 5px;
  }
  .graph_page .node-urls-tooltip .urls-cols-headers .line-height-1 {
      line-height: 65px;
  }
  .graph_page .node-urls-tooltip .urls-cols-headers .line-height-2 {
      line-height: 33px;
  }

  .graph_page .node-urls-tooltip .indice-score-warning{
    color: #fb9b10;
    text-align: center;
  }
  .graph_page .node-urls-tooltip .indice-score-warning i {
    vertical-align: sub;
    margin-right: 10px;
  }

  .graph_page .node-urls-tooltip .paginator-block,
  .graph_page .group-nodes-tooltip .paginator-block{
      height: 35px;
      text-align: left;
      line-height: 2.2;
      font-size: 0.8em;
      color: #747885 !important;
      width: 100%;
      margin: 5px auto;
      text-align: center;
  }

  .graph_page .node-urls-tooltip .paginator-block i,
  .graph_page .group-nodes-tooltip .paginator-block i {
      padding: 5px;
      background-color: white;
      border-radius: 50%;
      margin-left: 5px;
      color: #747885 !important;
      cursor: pointer;
      box-shadow: 3px 3px 5px rgba(106, 106, 106, 0.3);
  }

  .graph_page .node-urls-tooltip .paginator-block .wd-arrow-right,
  .graph_page .group-nodes-tooltip .paginator-block .wd-arrow-right {
      margin-left: 5px;
  }

  .graph_page .node-urls-tooltip .paginator-block .wd-arrow-left,
  .graph_page .group-nodes-tooltip .paginator-block  .wd-arrow-left {
      margin-right: 5px;
  }

  .graph_page .query_details_btn body {
      box-shadow: 3px 3px 5px rgba(106, 106, 106, 0.3);
      border-radius: 5px 5px 10px 10px;
  }

  .graph_page .query_details_btn body i {
      color: #737373 !important;
  }

  /** COULEURS PICTOS **/

  .icon-color-all {
      background-color: #9eb0b9;
  }

  .icon-color-standard {
      background-color: transparent;
  }

  /****** PERSON *****/
  .node.Person i {
      color: #8587f1;
  }

  .node.Person circle {
      stroke: #8587f1 !important;
  }

  .filter-node-Person .filter-icon {
      border: 1px solid #8587f1 !important;
  }

  .icon-color-Person {
      background-color: #8587f1;
  }

  .selected-node.Person circle {
      fill: #8587f1 !important;
  }

  .Person .node-option i,
  .graph_page .Person i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Person .group-header {
      background-color: #8587f1;
  }

  .filter-node-Person i {
      color: #8587f1;
  }

  /****** ADDRESS *****/
  .node.Address i {
      color: #c485f0;
  }

  .node.Address circle {
      stroke: #c485f0 !important;
  }

  .filter-node-Address .filter-icon {
      border: 1px solid #c485f0 !important;
  }

  .icon-color-Address {
      background-color: #c485f0;
  }

  .selected-node.Address circle {
      fill: #c485f0 !important;
  }

  .Address .node-option i,
  .graph_page .Address i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Address .group-header {
      background-color: #c485f0;
  }

  .filter-node-Address i {
      color: #c485f0;
  }

  /****** COMPANY *****/
  .node.Company i {
      color: #54cab5;
  }

  .node.Company circle, .node.Company path {
      stroke: #54cab5 !important;
  }

  .filter-node-Company .filter-icon {
      border: 1px solid #54cab5 !important;
  }

  .icon-color-Company {
      background-color: #54cab5;
  }

  .selected-node.Company circle, .selected-node.Company path, .node.Company .text-score {
      fill: #54cab5 !important;
  }

  .selected-node.Company .text-score {
      fill: #FFFFFF !important;
  }

  .node.Company .score-value body {
      color: #54cab5 !important;
  }

  .selected-node.Company .score-value body {
      color: #FFFFFF !important;
  }

  .Company .node-option i,
  .graph_page .Company i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Company .group-header {
      background-color: #54cab5;
  }

  .filter-node-Company i {
      color: #54cab5;
  }

  /****** SOURCE *****/
  .node.Source i {
      color: #fd74ab;
  }

  .node.Source circle {
      stroke: #fd74ab !important;
  }

  .filter-node-Source .filter-icon {
      border: 1px solid #fd74ab !important;
  }

  .icon-color-Source {
      background-color: #fd74ab;
  }

  .selected-node.Source circle {
      fill: #fd74ab !important;
  }

  .Source .node-option i,
  .graph_page .Source i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Source .group-header {
      background-color: #fd74ab;
  }

  .filter-node-Source i {
      color: #fd74ab;
  }

  /****** EMAIL *****/
  .node.Email i {
      color: #f29c72;
  }

  .node.Email circle {
      stroke: #f29c72 !important;
  }

  .filter-node-Email .filter-icon {
      border: 1px solid #f29c72 !important;
  }

  .icon-color-Email {
      background-color: #f29c72;
  }

  .selected-node.Email circle {
      fill: #f29c72 !important;
  }

  .Email .node-option i,
  .graph_page .Email i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Email .group-header {
      background-color: #f29c72;
  }

  .filter-node-Email i {
      color: #f29c72;
  }

  /****** PAYMENT *****/
  .node.payment i {
      color: #9d8c98;
  }

  .node.payment circle {
      stroke: #9d8c98 !important;
  }

  .filter-node-payment .filter-icon {
      border: 1px solid #9d8c98 !important;
  }

  .icon-color-payment {
      background-color: #9d8c98;
  }

  .selected-node.payment circle {
      fill: #9d8c98 !important;
  }

  .payment .node-option i,
  .graph_page .payment i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-payment .group-header {
      background-color: #9d8c98;
  }

  .filter-node-payment i {
      color: #9d8c98;
  }

  /****** PHONE *****/
  .node.phone i {
      color: #13a3a6;
  }

  .node.phone circle {
      stroke: #13a3a6 !important;
  }

  .filter-node-phone .filter-icon {
      border: 1px solid #13a3a6 !important;
  }

  .icon-color-phone {
      background-color: #13a3a6;
  }

  .selected-node.phone circle {
      fill: #13a3a6 !important;
  }

  .phone .node-option i,
  .graph_page .phone i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-phone .group-header {
      background-color: #13a3a6;
  }

  .filter-node-phone i {
      color: #13a3a6;
  }

  /****** TRADEMARK *****/
  .node.trademark i {
      color: #8587f1;
  }

  .node.trademark circle {
      stroke: #8587f1 !important;
  }

  .filter-node-trademark .filter-icon {
      border: 1px solid #8587f1 !important;
  }

  .icon-color-trademark {
      background-color: #8587f1;
  }

  .selected-node.trademark circle {
      fill: #8587f1 !important;
  }

  .trademark .node-option i,
  .graph_page .trademark i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-trademark .group-header {
      background-color: #8587f1;
  }

  .filter-node-trademark i {
      color: #8587f1;
  }

  /****** WEBSITE *****/
  .node.website i {
      color: #78d9ea;
  }

  .node.website circle {
      stroke: #78d9ea !important;
  }

  .filter-node-website .filter-icon {
      border: 1px solid #78d9ea !important;
  }

  .icon-color-website {
      background-color: #78d9ea;
  }

  .selected-node.website circle {
      fill: #78d9ea !important;
  }

  .website .node-option i,
  .graph_page .website i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-website .group-header {
      background-color: #78d9ea;
  }

  .filter-node-website i {
      color: #78d9ea;
  }

  /****** FINANCIAL REPORT *****/
  .node.FinancialReport i {
      color: #fdb73d;
  }

  .node.FinancialReport circle {
      stroke: #fdb73d !important;
  }

  .filter-node-FinancialReport .filter-icon {
      border: 1px solid #fdb73d !important;
  }

  .icon-color-FinancialReport {
      background-color: #fdb73d;
  }

  .selected-node.FinancialReport circle {
      fill: #fdb73d !important;
  }

  .FinancialReport .node-option i,
  .graph_page .FinancialReport i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-FinancialReport .group-header {
      background-color: #fdb73d;
  }

  .filter-node-FinancialReport i {
      color: #fdb73d;
  }

  /****** IP ADDRESS *****/
  .node.IpAddress i {
      color: #80828c;
  }

  .node.IpAddress circle {
      stroke: #80828c !important;
  }

  .filter-node-IpAddress .filter-icon {
      border: 1px solid #80828c !important;
  }

  .icon-color-IpAddress {
      background-color: #80828c;
  }

  .selected-node.IpAddress circle {
      fill: #80828c !important;
  }

  .IpAddress .node-option i,
  .graph_page .IpAddress i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-IpAddress .group-header {
      background-color: #80828c !important;
  }

  .filter-node-IpAddress i {
      color: #80828c;
  }

  /****** IP RANGE *****/
  .node.IpRange i {
      color: #ffc43d;
  }

  .node.IpRange circle {
      stroke: #ffc43d !important;
  }

  .filter-node-IpRange .filter-icon {
      border: 1px solid #ffc43d !important;
  }

  .icon-color-IpRange {
      background-color: #ffc43d;
  }

  .selected-node.IpRange circle {
      fill: #ffc43d !important;
  }

  .IpRange .node-option i,
  .graph_page .IpRange i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-IpRange .group-header {
      background-color: #ffc43d !important;
  }

  .filter-node-IpRange i {
      color: #ffc43d;
  }

  /****** DOCUMENT *****/
  .node.Document i {
      color: #669999;
  }

  .node.Document circle {
      stroke: #669999 !important;
  }

  .filter-node-Document .filter-icon {
      border: 1px solid #669999 !important;
  }

  .icon-color-Document {
      background-color: #669999;
  }

  .selected-node.Document circle {
      fill: #669999 !important;
  }

  .Document .node-option i,
  .graph_page .Document i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Document .group-header {
      background-color: #669999;
  }

  .filter-node-Document i {
      color: #669999;
  }

  /****** ACTIVITY (node) *****/
  .node.Activity i {
      color: #999966;
  }

  .node.Activity circle {
      stroke: #999966 !important;
  }

  .filter-node-Activity .filter-icon {
      border: 1px solid #999966 !important;
  }

  .icon-color-Activity {
      background-color: #999966;
  }

  .selected-node.Activity circle {
      fill: #999966 !important;
  }

  .Activity .node-option i,
  .graph_page .Activity i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-Activity .group-header {
      background-color: #999966;
  }

  .filter-node-Activity i {
      color: #999966;
  }

  /****** Company Type *****/
  .node.CompanyType i {
      color: #54a112;
  }

  .node.CompanyType circle {
      stroke: #54a112 !important;
  }

  .filter-node-CompanyType .filter-icon {
      border: 1px solid #54a112 !important;
  }

  .icon-color-CompanyType {
      background-color: #54a112;
  }

  .selected-node.CompanyType circle {
      fill: #54a112 !important;
  }

  .CompanyType .node-option i,
  .graph_page .CompanyType i.wd-cross,
  .graph_page .group-nodes-tooltip .group-nodes-tooltip-body-CompanyType .group-header {
      background-color: #54a112;
  }

  .filter-node-CompanyType i {
      color: #54a112;
  }

  /****** QUERY *****/
  .node.Query i {
      color: #669900;
  }

  .node.Query circle {
      stroke: #669900;
  }

  .icon-color-Query {
      background-color: #669900;
  }

  .selected-node.Query circle {
      fill: #669900 !important;
  }

  .Query .node-option i,
  .graph_page .Query i.wd-cross {
      background-color: #669900;
  }

  /****** QUERY CATEGORY *****/
  .icon-color-QueryCategory {
      background-color: #78d9ea;
  }

  .node.QueryCategory i, .node.QueryCategory .score-value body {
      color: #78d9ea !important;
  }

  .selected-node.QueryCategory circle {
      fill: #78d9ea !important;
      stroke: #FFFFFF !important;
  }

  .selected-node.QueryCategory i {
      color: #FFFFFF !important;
  }

  /****** BRAND & PRODUCT *****/
  .node.BrandProduct circle {
      stroke: #2ec5b1 !important;
  }

  .icon-color-BrandProduct {
      background-color: #2ec5b1;
  }

  .BrandProduct.selected-node.QueryCategory circle {
      stroke: #00a28d !important;
  }

  .BrandProduct text,
  .BrandProduct circle {
      fill: #2ec5b1 !important;
  }

  .BrandProduct .node-option i,
  .graph_page .BrandProduct i.wd-cross {
      background-color: #2ec5b1;
  }

  .node-score .score-body-BrandProduct,
  .node-queries-tooltip .query-tooltip-body-BrandProduct .query_desc,
  .query-magnifier-icon .query-magnifier-icon-BrandProduct,
  .node-urls-tooltip .urls-tooltip-body-BrandProduct .urls-header {
      background-color: #2ec5b1;
  }

  /****** DS PRODUCT *****/
  .node.DsProduct circle {
      stroke: #60be92;
  }

  .icon-color-DsProduct {
      background-color: #60be92;
  }

  .DsProduct text,
  .DsProduct circle {
      fill: #60be92 !important;
  }

  .DsProduct .node-option i,
  .graph_page .DsProduct i.wd-cross {
      background-color: #60be92;
  }

  .node-score .score-body-DsProduct,
  .node-queries-tooltip .query-tooltip-body-DsProduct .query_desc,
  .query-magnifier-icon .query-magnifier-icon-DsProduct,
  .node-urls-tooltip .urls-tooltip-body-DsProduct .urls-header {
      background-color: #60be92;
  }

  /****** KNOW HOW *****/
  .node.KnowHow circle {
      stroke: #fdb73d;
  }

  .icon-color-KnowHow {
      background-color: #fdb73d;
  }

  .KnowHow text,
  .KnowHow circle {
      fill: #fdb73d !important;
  }

  .KnowHow .node-option i,
  .graph_page .KnowHow i.wd-cross {
      background-color: #fdb73d;
  }

  .node-score .score-body-KnowHow,
  .node-queries-tooltip .query-tooltip-body-KnowHow .query_desc,
  .query-magnifier-icon .query-magnifier-icon-KnowHow,
  .node-urls-tooltip .urls-tooltip-body-KnowHow .urls-header {
      background-color: #fdb73d;
  }

  /****** ACTIVITY (category) *****/
  .node.Activity.QueryCategory circle {
      stroke: #fd74ab !important;
  }

  .icon-color-category-Activity {
      background-color: #fd74ab;
  }

  .Activity.selected-node.QueryCategory circle {
      stroke: #fd3887 !important;
  }

  .Activity.QueryCategory text,
  .Activity.QueryCategory circle {
      fill: #fd74ab !important;
  }

  .Activity .node-option i,
  .graph_page .Activity i.wd-cross {
      background-color: #fd74ab;
  }

  .node-score .score-body-Activity,
  .node-queries-tooltip .query-tooltip-body-Activity .query_desc,
  .query-magnifier-icon .query-magnifier-icon-Activity,
  .node-urls-tooltip .urls-tooltip-body-Activity .urls-header {
      background-color: #fd74ab;
  }

  /****** SKILLs *****/
  .node.Skills circle {
      stroke: #fdb73d !important;
  }

  .icon-color-Skills {
      background-color: #fdb73d;
  }

  .Skills.selected-node.QueryCategory circle {
      stroke: #fca000 !important;
  }

  .Skills text,
  .Skills circle {
      fill: #fdb73d !important;
  }

  .Skills .node-option i,
  .graph_page .Skills i.wd-cross {
      background-color: #fdb73d;
  }

  .node-score .score-body-Skills,
  .node-queries-tooltip .query-tooltip-body-Skills .query_desc,
  .query-magnifier-icon .query-magnifier-icon-Skills,
  .node-urls-tooltip .urls-tooltip-body-Skills .urls-header {
      background-color: #fdb73d;
  }

  /****** BREVET *****/
  .node.Brevet circle {
      stroke: #a199e3;
  }

  .icon-color-Brevet {
      background-color: #a199e3;
  }

  .Brevet text,
  .Brevet circle {
      fill: #a199e3 !important;
  }

  .Brevet .node-option i,
  .graph_page .Brevet i.wd-cross {
      background-color: #a199e3;
  }

  .node-score .score-body-Brevet,
  .node-queries-tooltip .query-tooltip-body-Brevet .query_desc,
  .query-magnifier-icon .query-magnifier-icon-Brevet,
  .node-urls-tooltip .urls-tooltip-body-Brevet .urls-header {
      background-color: #a199e3;
  }

  /****** INNOVATION *****/
  .node.Innovation circle {
      stroke: #a199e3 !important;
  }

  .icon-color-Innovation {
      background-color: #a199e3;
  }

  .Innovation.selected-node.QueryCategory circle {
      stroke: #8478EA !important;
  }

  .Innovation text,
  .Innovation circle {
      fill: #a199e3 !important;
  }

  .Innovation .node-option i,
  .graph_page .Innovation i.wd-cross {
      background-color: #a199e3;
  }

  .node-score .score-body-Innovation,
  .node-queries-tooltip .query-tooltip-body-Innovation .query_desc,
  .query-magnifier-icon .query-magnifier-icon-Innovation,
  .node-urls-tooltip .urls-tooltip-body-Innovation .urls-header {
      background-color: #a199e3;
  }

  /****** CUSTOMER *****/
  .node.Customer circle {
      stroke: #c485f0 !important;
  }

  .icon-color-Customer {
      background-color: #c485f0;
  }

  .Customer.selected-node.QueryCategory circle {
      stroke: #AD4BF2 !important;
  }

  .Customer text,
  .Customer circle {
      fill: #c485f0 !important;
  }

  .Customer .node-option i,
  .graph_page .Customer i.wd-cross {
      background-color: #c485f0;
  }

  .node-score .score-body-Customer,
  .node-queries-tooltip .query-tooltip-body-Customer .query_desc,
  .query-magnifier-icon .query-magnifier-icon-Customer,
  .node-urls-tooltip .urls-tooltip-body-Customer .urls-header {
      background-color: #c485f0;
  }

  /****** SECTOR *****/
  .node.Sector circle {
      stroke: #c485f0;
  }

  .icon-color-Sector {
      background-color: #c485f0;
  }

  .Sector text,
  .Sector circle {
      fill: #c485f0 !important;
  }

  .Sector .node-option i,
  .graph_page .Sector i.wd-cross {
      background-color: #c485f0;
  }

  .node-score .score-body-Sector,
  .node-queries-tooltip .query-tooltip-body-Sector .query_desc,
  .query-magnifier-icon .query-magnifier-icon-Sector,
  .node-urls-tooltip .urls-tooltip-body-Sector .urls-header {
      background-color: #c485f0;
  }

  /****** Category WEBSITE ******/
  .node.QC_website circle {
      stroke: #78d9ea !important;
  }

  .icon-color-QC_website {
      background-color: #78d9ea;
  }

  .QC_website.selected-node.QueryCategory circle {
      stroke: #1bc7e5 !important;
  }

  .QC_website text,
  .QC_website circle {
      fill: #78d9ea !important;
  }

  .QC_website .node-option i,
  .graph_page .QC_website i.wd-cross {
      background-color: #78d9ea;
  }

  .node-score .score-body-QC_website,
  .node-queries-tooltip .query-tooltip-body-QC_website .query_desc,
  .query-magnifier-icon .query-magnifier-icon-QC_website,
  .node-urls-tooltip .urls-tooltip-body-QC_website .urls-header {
      background-color: #78d9ea;
  }

  /****** PERSO *****/
  .node.perso circle {
      stroke: #78d9ea !important;
  }

  .icon-color-perso {
      background-color: #78d9ea;
  }

  .perso.selected-node.QueryCategory circle {
      stroke: #1bc7e5 !important;
  }

  .perso text,
  .perso circle {
      fill: #78d9ea !important;
  }

  .perso .node-option i,
  .graph_page .perso i.wd-cross {
      background-color: #78d9ea;
  }

  .node-scores-tooltip body /*.score-tooltip-body-perso*/
  {
      -webkit-box-shadow: 0px 0px 10px rgba(106, 106, 106, 0.3);
      box-shadow: 0px 0px 10px rgba(106, 106, 106, 0.3);
  }

  .node-score .score-body-perso,
  .node-queries-tooltip .query-tooltip-body-perso .query_desc,
  .query-magnifier-icon .query-magnifier-icon-perso,
  .node-urls-tooltip .urls-tooltip-body-perso .urls-header {
      background-color: #78d9ea;
  }

  /*********** COLORS BY SCORE LEVEL ***********/
  .node-score body,
  .node-queries-tooltip .query_desc,
  .query-magnifier-icon body,
  .node-urls-tooltip .urls-header {
      background-color: #747885;
  }

  .selected-node.NodeScore path, .selected-node.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  .selected-node.NodeScore .score-value body {
      color: #FFFFFF !important;
  }

  /****** LEVEL 3 *****/
  .node.score-level-3 circle {
      stroke: #e83a17;
  }

  .icon-color-score-level-3 {
      background-color: #e83a17;
  }

  .score-level-3 text,
  .score-level-3 circle {
      fill: #e83a17 !important;
  }

  .score-level-3 .node-option i,
  .graph_page .score-level-3 i.wd-cross {
      background-color: #e83a17;
  }

  .node.score-level-3.NodeScore .NodeScoreIcon i, .node.score-level-3.NodeScore .score-value body {
      color: #e83a17 !important;
  }

  .node.score-level-3.NodeScore path {
      stroke: #e83a17 !important;
  }

  .selected-node.score-level-3.NodeScore path {
      fill: #e83a17 !important;
  }

  .selected-node.score-level-3.NodeScore .score-value body, .selected-node.score-level-3.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.score-level-3.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /****** LEVEL 2.5 *****/
  .node.score-level-2_5 circle {
      stroke: #ed6145;
  }

  .icon-color-score-level-2_5 {
      background-color: #ed6145;
  }

  .score-level-2_5 text,
  .score-level-2_5 circle {
      fill: #ed6145 !important;
  }

  .score-level-2_5 .node-option i,
  .graph_page .score-level-2_5 i.wd-cross {
      background-color: #ed6145;
  }

  .node.score-level-2_5.NodeScore .NodeScoreIcon i, .node.score-level-2_5.NodeScore .score-value body {
      color: #ed6145 !important;
  }

  .node.score-level-2_5.NodeScore path {
      stroke: #ed6145 !important;
  }

  .selected-node.score-level-2_5.NodeScore path {
      fill: #ed6145 !important;
  }

  .selected-node.score-level-2_5.NodeScore .score-value body, .selected-node.score-level-2_5.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.score-level-2_5.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /****** LEVEL 2 *****/
  .node.score-level-2 circle {
      stroke: #ff9933;
  }

  .icon-color-score-level-2 {
      background-color: #ff9933;
  }

  .score-level-2 text,
  .score-level-2 circle {
      fill: #ff9933 !important;
  }

  .score-level-2 .node-option i,
  .graph_page .score-level-2 i.wd-cross {
      background-color: #ff9933;
  }

  .node.score-level-2.NodeScore .NodeScoreIcon i, .node.score-level-2.NodeScore .score-value body {
      color: #ff9933 !important;
  }

  .node.score-level-2.NodeScore path {
      stroke: #ff9933 !important;
  }

  .selected-node.score-level-2.NodeScore path {
      fill: #ff9933 !important;
  }

  .selected-node.score-level-2.NodeScore .score-value body, .selected-node.score-level-2.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.score-level-2.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /****** LEVEL 1.5 *****/
  .node.score-level-1_5 circle {
      stroke: #ffd633;
  }

  .icon-color-score-level-1_5 {
      background-color: #ffd633;
  }

  .score-level-1_5 text,
  .score-level-1_5 circle {
      fill: #ffd633 !important;
  }

  .score-level-1_5 .node-option i,
  .graph_page .score-level-1_5 i.wd-cross {
      background-color: #ffd633;
  }

  .node.score-level-1_5.NodeScore .NodeScoreIcon i, .node.score-level-1_5.NodeScore .score-value body {
      color: #ffd633 !important;
  }

  .node.score-level-1_5.NodeScore path {
      stroke: #ffd633 !important;
  }

  .selected-node.score-level-1_5.NodeScore path {
      fill: #ffd633 !important;
  }

  .selected-node.score-level-1_5.NodeScore .score-value body, .selected-node.score-level-1_5.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.score-level-1_5.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /****** LEVEL 1 *****/
  .node.score-level-1 circle {
      stroke: #ffe680;
  }

  .icon-color-score-level-1 {
      background-color: #ffe680;
  }

  .score-level-1 text,
  .score-level-1 circle {
      fill: #ffe680 !important;
  }

  .score-level-1 .node-option i,
  .graph_page .score-level-1 i.wd-cross {
      background-color: #ffe680;
  }

  .node.score-level-1.NodeScore .NodeScoreIcon i, .node.score-level-1.NodeScore .score-value body {
      color: #ffe680 !important;
  }

  .node.score-level-1.NodeScore path {
      stroke: #ffe680 !important;
  }

  .selected-node.score-level-1.NodeScore path {
      fill: #ffe680 !important;
  }

  .selected-node.score-level-1.NodeScore .score-value body, .selected-node.score-level-1.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.score-level-1.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /****** LEVEL 0 *****/
  .node.score-level-0 circle {
      stroke: #66cd32;
  }

  .icon-color-score-level-0 {
      background-color: #66cd32;
  }

  .score-level-0 text,
  .score-level-0 circle {
      fill: #66cd32 !important;
  }

  .score-level-0 .node-option i,
  .graph_page .score-level-0 i.wd-cross {
      background-color: #66cd32;
  }

  .node.score-level-0.NodeScore .NodeScoreIcon i, .node.score-level-0.NodeScore .score-value body {
      color: #66cd32 !important;
  }

  .node.score-level-0.NodeScore path {
      stroke: #66cd32 !important;
  }

  .selected-node.score-level-0.NodeScore path {
      fill: #66cd32 !important;
  }

  .selected-node.score-level-0.NodeScore .score-value body, .selected-node.score-level-0.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.score-level-0.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /****** Inactive Node Style *****/

  .icon-color-score-level-3 {
      background-color: #e83a17;
  }

  .node.inactiveNode circle {
      stroke: #8c8c8c;
  }

  .inactiveNode text,
  .inactiveNode circle {
      fill: #8c8c8c !important;
  }

  .inactiveNode .node-option i,
  .graph_page .inactiveNode i.wd-cross {
      background-color: #8c8c8c;
  }

  .node.inactiveNode.NodeScore .NodeScoreIcon i, .node.inactiveNode.NodeScore .score-value body {
      color: #8c8c8c !important;
  }

  .node.inactiveNode.NodeScore path {
      stroke: #8c8c8c !important;
  }

  .selected-node.inactiveNode.NodeScore path {
      fill: #8c8c8c !important;
  }

  .selected-node.inactiveNode.NodeScore .score-value body, .selected-node.inactiveNode.NodeScore .NodeScoreIcon i {
      color: #FFFFFF !important;
  }

  .selected-node.inactiveNode.NodeScore .text-score {
      fill: #FFFFFF !important;
  }

  /*****************************************/

  .node.selected-node i {
      color: #FFFFFF;
  }

  /************ urls list tooltips ****************/

  .graph_page .node-urls-tooltip > body {
      border: 1px solid #cccccc;
      -webkit-border-radius: 20px;
      -moz-border-radius: 20px;
      border-radius: 20px;
      background-color: white !important;
      overflow: hidden;
      height: 630px;
  }

  .node-urls-tooltip .urls-header {
      padding: 5px 0;
      text-align: center;
      color: #FFFFFF;
      -webkit-border-radius: 20px;
      -moz-border-radius: 20px;
      border-radius: 20px;
  }

  .graph_page .node-urls-tooltip .urls-list {
      text-align: left;
      padding: 5px 0;
      height: 500px;
      overflow: auto;
  }

  .graph_page .node-urls-tooltip .urls-list .listPairPos {
      background-color: #f2f2f2;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details {
      height: 40px;
      border-bottom: 2px solid #cecece;
      line-height: 2;
      padding: 0 5px;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info {
      font-weight: 600;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .url-info,
  .graph_page .node-urls-tooltip .urls-list .url-details .keywords-info,
  .graph_page .node-urls-tooltip .urls-list .url-details .tags-info {
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
  }
  /****** URLS WINDOW SCORE COLORS ******/
  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color span {
      width: 10px;
      height: 10px;
      float: left;
      margin-top: 15px;
      border-radius: 50%;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color .score-color-3 {
      background-color: #e83a17;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color .score-color-2_5 {
      background-color: #ed6145;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color .score-color-2 {
      background-color: #ff9933;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color .score-color-1_5 {
      background-color: #ffd633;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color .score-color-1 {
      background-color: #ffe680;
  }

  .graph_page .node-urls-tooltip .urls-list .url-details .score-info-color .score-color-0 {
      background-color: #66cd32;
  }

  /** PICTOS OPTIONS NOEUD **/

  .graph_page .node-option i {
      color: white !important;
      -webkit-border-radius: 5px;
      -moz-border-radius: 5px;
      border-radius: 5px;
      width: 25px;
      height: 25px;
      display: block;
      text-align: center;
      line-height: 1.5;
  }

  .graph_page i.wd-cross {
      border-radius: 20px;
      color: white;
      text-align: center;
      padding: 0 0 1px 1px;
  }

  .search_result_page .Alchemy text {
      font-size: 18px;
  }

  .search_result_page .svg {
      background-color: #FFFFFF !important;
  }

  .search_result_page .alchemy {
      height: 100% !important;
      width: 100% !important;
      margin: 0 auto;
      border: 3px solid #3366cc;
      border-top: none;
  }

  .node circle, .node path {
      fill: #fff;
      stroke: steelblue;
      stroke-width: 0.5px;
  }

  .highlighted-node {
      stroke-width: 3px !important;
  }

  .group-filters {
      float: none;
      padding-left: 10px;
      border: 3px solid #3366cc;
      border-bottom: none;
  }

  .group-filters .filter {
      margin-right: 25px;
  }

  .group-filters input {
      margin-right: 5px;
  }

  .nodeModalDetails .node-prop {
      width: 30%;
      float: left;
  }

  .nodeModalDetails .prop-value {
      padding-left: 10px;
  }

  /*** PAGINATION **/
  .pagination {
      margin: 0 auto;
      padding-bottom: 5px;
      text-align: center;
      min-width: 100%;
  }

  .pagination > li {
      display: inline-block;
  }

  .pagination > li > a {
      border-radius: 30px;
      height: 30px;
      width: auto;
      min-width: 30px;
      background-color: white;
      -webkit-box-shadow: 2px 2px 5px rgba(106, 106, 106, 0.2);
      box-shadow: 2px 2px 5px rgba(106, 106, 106, 0.2);
      color: #747885 !important;
      border: none;
      margin: 0;
      padding: 0;
      line-height: 2.6em;
      font-size: 0.8em;
  }

  .pagination > li.disabled > a,
  .pagination > li.disabled:hover > a,
  .pagination > li.disabled > a:hover {
      opacity: 0.5;
      color: #747885 !important;
      cursor: not-allowed;
      pointer-events: none;
      background-color: white !important;
      border: none;
      -webkit-box-shadow: 2px 2px 5px rgba(106, 106, 106, 0.2);
      box-shadow: 2px 2px 5px rgba(106, 106, 106, 0.2);
  }

  .pagination > li:hover > a,
  .pagination > li:active > a,
  .pagination > li:focus > a,
  .pagination > li:visited > a,
  .pagination > li.active > a,
  .pagination > li.active:hover > a,
  .pagination > li.active:active > a,
  .pagination > li.active:visited > a,
  .pagination > li.active:focus > a {
      background-color: #747885 !important;
      box-shadow: none;
      border: none;
      color: white !important;
  }

  .pagination > li:last-child > a,
  .pagination > li:first-child > a {
      border-radius: 30px;
      width: 40px;
  }

  .graph_page .search-loader {
      float: none;
  }

  .graph_page .enabled-icon {
      color: #333 !important;
  }

  .graph_page .disabled-icon, .graph_page .disabled-icon div {
      color: #bfbfbf !important;
  }
  .text-danger {
      font-family: "SourceSansPro", Gill Sans, Helvetica, Arial, " sans-serif" !important;
      color: #d76a56 !important;
  }
`;
