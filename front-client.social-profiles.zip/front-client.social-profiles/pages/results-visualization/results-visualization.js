import { html, css } from "lit-element";
import { MvElement } from "mv-element";
import "mv-tab";
import "mv-linear-icons";
import "./listing-result.js";
import "./map-result.js";
import "./graph-result.js";
import "./dashboard/dashboard-profiles.js";
import "../../components/header/header.js";

export default class ResultsVisualization extends MvElement {
  static get properties() {
    return {
      view: { type: String, attribute: true },
      theme: { type: String, attribute: true },
      showFilters: { type: Boolean, attribute: true },
    };
  }

  static get styles() {
    return css`
      :host {
        --mv-font-size-m: 12pt;
        --p-color: #373e48;
        --mv-breadcrumbs-link-decoration: none;
        --mv-container-min-width: 300px;
        --mv-container-max-width: 100%;
      }

      .tabs {
        padding: 10px;
      }

      .list-container {
        width: 100%;
        min-height: 100%;
        overflow-x: auto;
        white-space: nowrap;
      }
    `;
  }

  constructor() {
    super();
    this.theme = "light";
    this.showFilters = true;
  }

  render() {
    const {
      parameters: { pathParameters },
    } = this;
    const { view } = pathParameters;
    return html`
      <investigation-header
        ?showFilters="${this.showFilters}"
        @toggle-filters="${this.toggleFilters}"
      ></investigation-header>
      <div class="tabs">
        <mv-tab selected="${view}" group .theme="${this.theme}">
          <mv-tab
            tab
            key="dashboard"
            @change-tab="${this.changeTab("dashboard")}"
          >
            Dashboard
          </mv-tab>
          <mv-tab content key="dashboard">
            <dashboard-profiles name="dashboard-profiles"></dashboard-profiles>
          </mv-tab>
          <mv-tab tab key="list" @change-tab="${this.changeTab("list")}">
            List
          </mv-tab>
          <mv-tab content key="list">
            <listing-result
              name="investigation-filter"
              storage-modes="local"
              ?showFilters="${this.showFilters}"
            ></listing-result>
          </mv-tab>
          <mv-tab tab key="graph" @change-tab="${this.changeTab("graph")}">
            Graph
          </mv-tab>
          <mv-tab content key="graph">
            <graph-result name="graph-result" ?should-initialize="${view==="graph"}"></graph-result>
          </mv-tab>
          <mv-tab tab key="map" @change-tab="${this.changeTab("map")}">
            Map
          </mv-tab>
          <mv-tab content key="map">
            <map-result name="map" ?should-initialize="${view==="map"}"></map-result>
          </mv-tab>
        </mv-tab>
      </div>
    `;
  }

  changeTab = (view) => () => {
    history.pushState(null, "", `./results/${view}`);
  };

  toggleFilters = (event) => {
    const {
      detail: { showFilters },
    } = event;
    this.showFilters = showFilters;
  };
}

customElements.define("results-visualization", ResultsVisualization);
