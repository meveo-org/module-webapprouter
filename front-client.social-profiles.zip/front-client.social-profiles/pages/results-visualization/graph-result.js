import { LitElement, html, css } from "lit-element";
import { GraphStyles } from "./styles/graph-styles/graphStyles.js";
import { IconStyles } from "./styles/graph-styles/iconStyles.js";
import { AlchemyStyles } from "./styles/graph-styles/alchemyStyles.js";
import { CommonStyles } from "./styles/graph-styles/commonStyles.js";
import { BpStyles } from "./styles/graph-styles/bpStyles.js";
import "vendor";
import "alchemy";
import * as GetNeo4jAPI from "GetNeo4jAPI";

import {
  neo4jToGraphJson,
  groupGraph,
  getEdgeCaption,
  getNodeCaption,
} from "graphFunctions";

class GraphResult extends LitElement {
  static get properties() {
    return {
      shouldInitialize: {
        type: Boolean,
        attribute: "should-initialize",
        reflect: true,
      },
      neo4jData: { type: Array, attribute: false },
    };
  }

  static get styles() {
    return [GraphStyles, IconStyles, CommonStyles, BpStyles, AlchemyStyles];
  }

  constructor() {
    super();
    this.neo4jData = [];
  }

  render() {
    return html`
      <div class="graph_page">
        <div id="alchemy" class="alchemy"></div>
      </div>
    `;
  }

  firstUpdated() {
    if (this.shouldInitialize) {
      this.loadData();
      this.loadGraph();
    }
  }

  loadData = () => {
    GetNeo4jAPI.executeApiCall(this, null, this.loadNeo4j);
  };

  loadNeo4j = (event) => {
    const {
      detail: { result },
    } = event;
    this.neo4jData = result;
  };

  loadGraph = () => {
    const translateX = (screen.width / 100) * 15;
    const translateY = (screen.height / 100) * 5;

    const highlighted_nodes = [];
    this.neo4jData.forEach((rowResult) => {
      rowResult.data.forEach((data) => {
        if (typeof data.row !== "undefined") {
          highlighted_nodes.push(data.row[0]);
        }
      });
    });
    localStorage.setItem("search_nodes", JSON.stringify(highlighted_nodes));
    const result = neo4jToGraphJson(this.neo4jData);
    groupGraph(result.graph, highlighted_nodes);

    const config = {
      dataSource: result.graph,
      divSelector: this.shadowRoot.querySelector("#alchemy"),
      shadowRoot: this.shadowRoot,
      forceLocked: true,
      alpha: 0.1,
      nodeOverlap: 100,
      edgeCaption: "type",
      curvedEdges: true,
      linkDistancefn: () => 250,
      nodeCaptionsOnByDefault: true,
      edgeCaptionsOnByDefault: true,
      nodeTypes: { labels: ["Person", "email", "Company"] },
      edgeTypes: { type: ["hasEmail", "manage", "located_in"] },
      directedEdges: true,
      nodeCaption: getNodeCaption,
      edgeCaption: getEdgeCaption,
      nodeStyle: {
        all: {
          width: 4,
          radius: 40,
          color: "#CCC",
          opacity: 1,
          selected: {
            opacity: 2,
          },
          highlighted: {
            opacity: 2,
          },
          hidden: {
            opacity: 0,
          },
        },
      },
      edgeStyle: {
        all: {
          width: 2,
          color: "#b4dcff",
          opacity: 0.3,
          selected: {
            opacity: 1,
          },
          highlighted: {
            opacity: 1,
          },
          hidden: {
            opacity: 0,
          },
        },
      },
      initialScale: 0.7,
      initialTranslate: [translateX, translateY],
    };
    alchemy = new Alchemy(config);
  };
}

window.customElements.define("graph-result", GraphResult);
