import { LitElement, html, css } from "lit-element";
import * as GetMapProfilesAPI from "GetMapProfilesAPI";

class MapResult extends LitElement {
  static get properties() {
    return {
      shouldInitialize: {
        type: Boolean,
        attribute: "should-initialize",
        reflect: true,
      },
      profiles: { type: Array, attribute: false, reflect: true },
    };
  }

  static get styles() {
    return css`
      .map-container {
        width: 100%;
        height: 100%;
      }
    `;
  }

  constructor() {
    super();
    this.map = null;
    this.profiles = [];
  }

  render() {
    return html`
      <div id="map" style="height: 100%;" class="map-container"></div>
    `;
  }

  firstUpdated() {
    if (!this.shouldInitialize) {
      this.removeMapScripts();
    }
  }

  connectedCallback() {
    super.connectedCallback();
    if (this.shouldInitialize) {
      GetMapProfilesAPI.executeApiCall(this, null, this.getProfiles);
      window.initMap = this.initMap;
      this.loadMap();
    }
  }

  loadMap = () => {
    const key = "AIzaSyDJMht1fBsxsa4REg-MR8_BAvmmsQRkNdM";
    var script = document.createElement("script");
    script.type = "text/javascript";
    script.id = "mapScript";
    script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&callback=initMap`;
    document.body.appendChild(script);
  };

  initMap = async () => {
    let center = { lat: 0, lng: 0 };
    let zoom = 3;
    const ip = await fetch("https://ipinfo.io/json?token=268f99373d784d");
    const data = await ip.json();
    try {
      center = {
        lat: parseInt(data.loc.split(",")[0]),
        lng: parseInt(data.loc.split(",")[1]),
      };
      zoom = 6;
    } catch (error) {
      console.log("Adblocked ipinfo");
    }
    this.map = new google.maps.Map(this.shadowRoot.querySelector("#map"), {
      center,
      zoom,
    });
    this.addMarkers();
  };

  getProfiles = (event) => {
    const {
      detail: { result },
    } = event;
    this.profiles = result;
  };

  addMarkers = () => {
    this.markers =
      this.profiles &&
      this.profiles.map((socialProfile) => this.addMarker(socialProfile));
  };

  addMarker = (socialProfile) => {
    const marker = new google.maps.Marker({
      position: { lat: socialProfile.lat, lng: socialProfile.lon },
      map: this.map,
      title: socialProfile.username,
    });
    return marker;
  };

  removeMapScripts = () => {
    const mapScript = document.getElementById("mapScript");
    if (mapScript && window.initMap && window.google) {
      delete window.initMap;
      delete window.google;
      document.body.removeChild(mapScript);
    }
  };
}

window.customElements.define("map-result", MapResult);
