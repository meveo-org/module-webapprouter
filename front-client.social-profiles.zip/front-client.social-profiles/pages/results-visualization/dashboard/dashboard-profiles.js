import { html, css, LitElement } from "lit-element";
import "mv-table";
import "mv-font-awesome";
import "mv-pagination";
import "mv-container";
import "mv-select";
import "mv-click-away";
import "mv-tooltip";
import "mv-radio";
import "../../../components/actions/profiles-action-column.js";

import * as GetProfilesAPI from "GetProfilesAPI";

const LIMIT_OPTIONS = [
  {
    label: "3",
    value: "3",
  },
  {
    label: "5",
    value: "5",
  },
  {
    label: "10",
    value: "10",
  },
  {
    label: "20",
    value: "20",
  },
];

const VISUALIZATION_MODE = [
  {
    name: "mode",
    checked: true,
    value: "full",
    tooltip: "Full dashboard",
  },
  {
    name: "mode",
    checked: false,
    value: "semi-condensed",
    tooltip: "Semi-condensed dashboard",
  },
  {
    name: "mode",
    checked: false,
    value: "condensed",
    tooltip: "Condensed dashboard",
  },
];

const COLUMNS_STYLE = [
  {
    name: "avatar",
    header: "text-align: center",
    cell: "text-align: center",
  },
];

class DashboardProfiles extends LitElement {
  static get properties() {
    return {
      columns: { type: Array, attribute: false, reflect: true },
      rows: { type: Array, attribute: false, reflect: true },
      pages: { type: Number, attribute: false, reflect: true },
      currentPage: { type: Number, attribute: false, reflect: true },
      screenshot: { type: String, attribute: true },
      showImage: { type: Boolean, attribute: true },
      statistics: { type: Object, attribute: false },
      limit: { type: Number, attribute: true },
      platforms: { type: Array, attribute: false },
      investigation: { type: Object, attribute: false },
      modes: { type: Array, attribute: false },
    };
  }

  static get styles() {
    return css`
      :host {
        font-family: var(--font-family, Arial);
        font-size: var(--font-size-m, 10pt);
      }

      mv-container {
        --mv-container-max-width: 100%;
      }

      mv-table {
        --mv-table-max-height: 825px;
      }

      .progress,
      .statistics {
        display: flex;
        justify-content: space-around;
        color: #80828c;
      }

      .progress > div,
      .statistics > div {
        font-size: 30px;
        width: 100%;
        text-align: center;
      }

      .progress span,
      .statistics span {
        color: #ff4861;
      }

      .top-matching {
        font-size: 25px;
        padding-bottom: 20px;
        color: #80828c;
      }

      mv-select {
        --mv-select-width: 50px;
        --mv-select-font-size: 20px;
      }

      .limit {
        display: inline-block;
        margin-bottom: -11px;
        --mv-select-border: 1px solid transparent;
      }

      .limit mv-select {
        --mv-select-input-padding: 3px;
        --mv-select-font-size: 25px;
      }

      .limit mv-select:hover {
        --mv-select-border: 1px solid #4e686d;
      }

      .title {
        font-size: 25px;
        color: #80828c;
      }

      .statistics div:nth-child(2) {
        border-right: 1px solid #80828c;
        border-left: 1px solid #80828c;
      }

      .screenshot {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: block;
        margin: auto;
        z-index: 1000;
        width: 600px;
        height: 400px;
      }

      .frame {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0.5;
        background-color: #000000;
        z-index: 999;
      }

      .icon {
        width: 80px;
        height: 80px;
        border-radius: 50%;
      }

      .platform li {
        display: inline-block;
        width: 140px;
        text-align: center;
      }

      .platform .count {
        text-align: center;
        color: #80828c;
      }

      .platform ul {
        white-space: nowrap;
        overflow: auto;
        background: beige;
        padding: 15px 0;
        font-size: 18px;
        scrollbar-color: #5a6473 #788394;
        scrollbar-width: thin;
      }

      .item {
        position: relative;
      }

      .badge {
        position: absolute;
        top: 0;
        right: 25px;
        width: 30px;
        height: 30px;
        background-color: #ff4861;
        color: #ffffff;
        border-radius: 50%;
      }

      .platform ul::-webkit-scrollbar {
        width: 14px;
        background-color: #dbe9ff;
        border-radius: 10px;
      }

      .platform ul::-webkit-scrollbar-thumb {
        border-radius: 10px;
        box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
        background-color: #c2d5ec;
      }

      .statistics span {
        cursor: pointer;
      }

      .statistics span:hover {
        text-shadow: 1px 1px 2px black, 0 0 1em blue, 0 0 0.2em darkblue;
      }

      input[name="mode"] {
        display: none;
      }

      input[name="mode"] + label {
        -webkit-appearance: none;
        background-color: #e1e1e1;
        border: 4px solid #e1e1e1;
        border-radius: 50%;
        display: inline-block;
        position: relative;
        width: 15px;
        height: 15px;
        cursor: pointer;
        margin-right: 10px;
      }

      input[name="mode"]:checked + label {
        background-color: #3999c1;
      }

      .mode {
        margin: 10px 0 0 12px;
        text-align: center;
      }

      .mode span {
        margin-right: 13px;
      }

      .mode mv-radio {
        --radio-light-background-color: #e1e1e1;
        --mv-radio-light-hover-background-color: #e1e1e1;
        --mv-radio-light-hover-border: 1px solid #e1e1e1;
        --mv-radio-light-border: 1px solid #e1e1e1;
        --mv-radio-light-checked-background-color: #e1e1e1;
        --mv-radio-radio-size: 22px;
        --mv-radio-checkmark-size: 16px;
      }
    `;
  }

  constructor() {
    super();
    this.offset = 0;
    this.limit = 5;
    this.pages = 0;
    this.currentPage = 0;
    this.columns = [];
    this.rows = [];
    this.actionColumn = {
      label: "",
      getActionComponent: (profile) => html`
        <profiles-actions
          .profile="${profile}"
          @change-status="${this.changeStatus}"
          @show-screenshot="${this.showScreenshot}"
        ></profiles-actions>
      `,
    };
    this.showImage = false;
    this.statistics = {};
    this.investigation = { launchedQueries: 100, qualifiedResults: 92 };
    this.modes = VISUALIZATION_MODE;
  }

  render() {
    const { detect, validate, bookmark } = this.statistics;
    const { launchedQueries, qualifiedResults } = this.investigation;
    const currentMode = this.modes.find((mode) => mode.checked).value;
    console.log("currentMode :", currentMode);
    const showList = currentMode === "full";
    const hiddenPlatforms = currentMode === "condensed";

    return html`
      <section>
        <div class="mode">
          ${this.modes.map(
            (item) => html`
              <span>
                <mv-tooltip>
                  <mv-radio
                    type="single"
                    .id="${item.value}"
                    .value="${item.value}"
                    .checked="${item.checked}"
                    @radio-clicked="${this.changeMode}"
                  ></mv-radio>
                  <div slot="tooltip-content">${item.tooltip}</div>
                </mv-tooltip>
              </span>
            `
          )}
        </div>
        <mv-container>
          <div class="progress">
            <div><span>${launchedQueries}%</span> Queries launched</div>
            <div><span>${qualifiedResults}%</span> Results qualified</div>
          </div>
        </mv-container>
        <mv-container>
          <div class="statistics">
            <div>
              <span @click="${this.changePage("detected")}">${detect}</span>
              Profiles detected
            </div>
            <div>
              <span @click="${this.changePage("validated")}">${validate}</span>
              Profiles validated
            </div>
            <div>
              <span @click="${this.changePage("bookmarked")}">${bookmark}</span>
              Profiles bookmarked
            </div>
          </div>
        </mv-container>
        ${showList
          ? html`
              <mv-container>
                <div class="top-matching">
                  Top
                  <div class="limit">
                    <mv-select
                      .value="${{ value: this.limit, label: this.limit }}"
                      .options=${LIMIT_OPTIONS}
                      @select-option="${this.changeLimit("limit")}"
                      no-clear-button
                    ></mv-select>
                  </div>
                  Matching Profiles
                </div>
                <mv-table
                  .columns="${this.columns}"
                  .rows="${this.rows}"
                  with-checkbox
                  .action-column="${this.actionColumn}"
                  .columnsStyle="${COLUMNS_STYLE}"
                ></mv-table>
              </mv-container>
            `
          : html``}
        ${hiddenPlatforms
          ? html``
          : html`
              <mv-container>
                <div class="platform">
                  <div class="title">Split by platform</div>
                  <ul>
                    ${this.platforms.map(
                      (platform) => html`
                        <li class="item">
                          <img
                            class="icon"
                            src=${`${this.baseURI}img/icon/${platform.icon}`}
                          />
                          <div class="count">${platform.count}</div>
                          <div class="badge">${platform.newCount}</div>
                        </li>
                      `
                    )}
                  </ul>
                </div>
              </mv-container>
            `}
        ${this.showImage
          ? html` <div class="frame"></div>
              <mv-click-away @clicked-away=${this.clickedAway}>
                <img class="screenshot" src="${this.screenshot}" />
              </mv-click-away>`
          : html``}
      </section>
    `;
  }

  connectedCallback() {
    this.loadColumns();
    this.loadData(1);
    window.addEventListener("scroll", this.closeScreenshot);
    super.connectedCallback();
  }

  disconnectedCallback() {
    document.removeEventListener("scroll", this.closeScreenshot);
    super.disconnectedCallback();
  }

  firstUpdated() {
    this.loadData(1);
    super.firstUpdated();
  }

  loadColumns = async () => {
    const { properties } = await GetProfilesAPI.getResponseSchema();
    this.columns = properties;
  };

  loadData = (page) => {
    this.currentPage = page < 1 ? 1 : page;
    this.offset = (this.currentPage - 1) * this.limit;
    GetProfilesAPI.executeApiCall(
      this,
      { offset: this.offset, limit: this.limit },
      this.loadRows
    );
  };

  loadRows = (event) => {
    const {
      detail: { result },
    } = event;
    const { count, results, statistics, platforms } = result;
    this.statistics = statistics;
    this.platforms = platforms;
    this.pages = this.limit > 0 ? Math.ceil(count / this.limit) : 0;
    this.rows = [
      ...results.map((row) => ({
        ...row,
        avatar: { ...row.avatar, content: row.name, title: row.id },
      })),
    ];
  };

  changeStatus = (event) => {
    const {
      detail: { profile, status },
    } = event;
    if (status === "TRASH") {
      this.rows = this.rows.filter((row) => row.id !== profile.id);
    }
    if (["VALIDATE", "BOOKMARK"].includes(status)) {
      this.rows = this.rows.reduce((list, item) => {
        const exists = item.id === profile.id;
        if (exists) {
          return [
            ...list,
            {
              ...item,
              status,
            },
          ];
        }
        return [...list, item];
      }, []);
    }
  };

  showScreenshot = (event) => {
    const {
      detail: { profile },
    } = event;
    this.screenshot = profile.screenshot.href;
    this.showImage = true;
  };

  clickedAway = () => {
    this.showImage = false;
  };

  closeScreenshot = () => {
    this.showImage = false;
  };

  changeLimit = () => {
    return (event) => {
      const {
        detail: { option },
      } = event;
      this.limit = option.value;
      this.loadData(1);
    };
  };

  changePage = (status) => () => {
    history.pushState(null, "", `./results/dashboard/${status}`);
  };

  changeMode = (originalEvent) => {
    const {
      target: { value },
    } = originalEvent;
    this.modes = this.modes.map((item) => {
      if (item.value === value) {
        return { ...item, checked: true };
      } else {
        return { ...item, checked: false };
      }
    });
  };
}

customElements.define("dashboard-profiles", DashboardProfiles);
