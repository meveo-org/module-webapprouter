import { html, css } from "lit-element";
import { MvElement } from "mv-element";
import "mv-table";
import "mv-font-awesome";
import "mv-pagination";
import "mv-click-away";
import "../../components/filters/filters-options.js";
import "../../components/filters/search-filter.js";
import "../../components/filters/dropdown-filter.js";
import "../../components/actions/profiles-action-column.js";

import * as GetProfilesAPI from "GetProfilesAPI";
import * as GetFiltersAPI from "GetFiltersAPI";

const filterListById = (list, id) => {
  if (list.length > 0) {
    return list.filter((item) => item.id === id);
  } else {
    return [];
  }
};

const checkValueById = (list, name) => {
  return list.length === 0 || !list.some((item) => item.id === name);
};

const findObjectById = (list, id) => {
  return list.find((item) => item.id === id);
};

const changeList = (list, checked) => {
  return list.map((item) => ({ value: item, checked }));
};

const sortByValue = (previous, next) => {
  if (previous.value) {
    return previous.value.localeCompare(next.value);
  }
  return false;
};

const COLUMNS_STYLE = [
  {
    name: "avatar",
    header: "text-align: center",
    cell: "text-align: center",
  },
];

class ListingResult extends MvElement {
  static get properties() {
    return {
      columns: { type: Array, attribute: false, reflect: true },
      rows: { type: Array, attribute: false, reflect: true },
      pages: { type: Number, attribute: false, reflect: true },
      currentPage: { type: Number, attribute: false, reflect: true },
      filters: { type: Array, attribute: false },
      filteredValue: { type: Array, attribute: false },
      options: { type: Array, attribute: false },
      values: { type: Array, attribute: false },
      showFilters: { type: Boolean, attribute: true },
      screenshot: { type: String, attribute: true },
      showImage: { type: Boolean, attribute: true },
      hasSavedData: { type: Boolean, attribute: true },
    };
  }

  static get model() {
    return {
      modelClass: "FilterForm",
      mappings: [{ property: "filteredValue", value: "filteredValue" }],
      filters: ["title"],
    };
  }

  static get styles() {
    return css`
      :host {
        font-family: var(--font-family, Arial);
        font-size: var(--font-size-m, 10pt);
      }

      mv-container {
        --mv-container-max-width: 100%;
      }

      img {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        display: block;
        margin: auto;
        z-index: 1000;
        width: 600px;
        height: 400px;
      }

      .frame {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        opacity: 0.5;
        background-color: #000000;
        z-index: 999;
      }
    `;
  }

  constructor() {
    super();
    this.offset = 0;
    this.limit = 10;
    this.pages = 0;
    this.currentPage = 0;
    this.columns = [];
    this.rows = [];
    this.filters = [];
    this.filteredValue = [];
    this.options = [];
    this.values = [];
    this.showFilters = false;
    this.actionColumn = {
      label: "",
      getActionComponent: (profile) => html`
        <profiles-actions
          .profile="${profile}"
          @change-status="${this.changeStatus}"
          @show-screenshot="${this.showScreenshot}"
        ></profiles-actions>
      `,
    };
    this.showImage = false;
    this.hasSavedData = false;
  }

  render() {
    return html`
      <section>
        ${this.showFilters && this.hasSavedData
          ? html`
              <filters-options
                @apply-filter="${this.handleFilter}"
                @reset-filter="${this.handleReset}"
              >
                ${this.filters.map((filter) => {
                  const { id, label, data, tags, storedTags, type } = filter;
                  if (type === "DROPDOWN") {
                    return html` <dropdown-filter
                      .name="${id}"
                      .label="${label}"
                      .data="${data}"
                      @data-change="${this.changeData}"
                    ></dropdown-filter>`;
                  }
                  if (type === "SEARCH") {
                    return html` <search-filter
                      .name="${id}"
                      .label="${label}"
                      .data="${data}"
                      @filter-change="${this.changeFilter}"
                      @option-change="${this.changeOption}"
                      @value-change="${this.changeValue}"
                      .tags="${tags || []}"
                      .storedTags="${storedTags || []}"
                      .value="${this.getValue(this.values, id)}"
                      .options="${this.getOptions(this.options, id).option ||
                      []}"
                      .checkedAll="${this.getOptions(this.options, id)
                        .checkedAll || false}"
                    ></search-filter>`;
                  }
                })}
              </filters-options>
            `
          : html``}
        <mv-container>
          <mv-table
            .columns="${this.columns}"
            .rows="${this.rows}"
            with-checkbox
            .action-column="${this.actionColumn}"
            .columnsStyle="${COLUMNS_STYLE}"
          ></mv-table>
          <mv-pagination
            type="text"
            .page="${this.currentPage}"
            .pages="${this.pages}"
            @change-page="${this.gotoPage}"
          ></mv-pagination>
        </mv-container>
        ${this.showImage
          ? html` <div class="frame"></div>
              <mv-click-away @clicked-away=${this.clickedAway}>
                <img src="${this.screenshot}" />
              </mv-click-away>`
          : html``}
      </section>
    `;
  }

  connectedCallback() {
    this.loadColumns();
    this.loadData(1);
    this.loadDataFilters();
    window.addEventListener("scroll", this.closeScreenshot);
    super.connectedCallback();
  }

  disconnectedCallback() {
    document.removeEventListener("scroll", this.closeScreenshot);
    super.disconnectedCallback();
  }

  firstUpdated() {
    this.hasSavedData = true;
    this.loadDataFilters();
    this.loadData(1);
    super.firstUpdated();
  }

  updateStore = (name, value) => {
    this.store.updateValue(name, value);
  };

  loadColumns = async () => {
    const { properties } = await GetProfilesAPI.getResponseSchema();
    this.columns = properties;
  };

  loadData = (page) => {
    this.currentPage = page < 1 ? 1 : page;
    this.offset = (this.currentPage - 1) * this.limit;
    GetProfilesAPI.executeApiCall(
      this,
      { offset: this.offset, limit: this.limit, filters: this.filteredValue },
      this.loadRows
    );
  };

  loadRows = (event) => {
    const {
      detail: { result },
    } = event;
    const { count, results } = result;
    this.pages = this.limit > 0 ? Math.ceil(count / this.limit) : 0;
    this.rows = [
      ...results.map((row) => ({
        ...row,
        avatar: { ...row.avatar, content: row.name, title: row.id },
      })),
    ];
  };

  gotoPage = (event) => {
    const {
      detail: { page },
    } = event;
    this.loadData(page);
  };

  loadDataFilters = () => {
    GetFiltersAPI.executeApiCall(this, null, this.loadFilters);
  };

  loadFilters = (event) => {
    const {
      detail: { result },
    } = event;
    this.filters = result.map((filter) => {
      if (filter.id === "status" && this.filteredValue.length > 0) {
        const filteredValue = findObjectById(this.filteredValue, "status").data;
        const statusesChecked = changeList(filteredValue, true);
        const statusesNotChecked = changeList(
          filter.data.filter((item) => !filteredValue.includes(item)),
          false
        );
        return {
          ...filter,
          data: [...statusesChecked, ...statusesNotChecked].sort(sortByValue),
        };
      } else {
        return {
          ...filter,
          data: changeList(filter.data, false).sort(sortByValue),
        };
      }
    });

    this.filters = this.filters.reduce((list, item) => {
      const exists = this.filteredValue.some((filter) => filter.id === item.id);
      if (exists) {
        const filteredValue = findObjectById(this.filteredValue, item.id);
        return [
          ...list,
          {
            ...item,
            tags: filteredValue.tags,
            storedTags: filteredValue.storedTags,
          },
        ];
      }
      return [...list, item];
    }, []);
  };

  changeFilter = (event) => {
    const {
      detail: { tags, name },
    } = event;
    this.filters = this.filters.reduce((list, item) => {
      const exists = item.id === name;
      if (exists) {
        return [
          ...list,
          {
            ...item,
            tags,
          },
        ];
      }
      return [...list, item];
    }, []);
  };

  changeOption = (event) => {
    const {
      detail: { name, option, checkedAll },
    } = event;
    if (checkValueById(this.options, name)) {
      this.options = [...this.options, { id: name, option }];
    } else {
      this.options = this.options.reduce((list, item) => {
        const exists = item.id === name;
        if (exists) {
          return [
            ...list,
            {
              ...item,
              option,
              checkedAll,
            },
          ];
        }
        return [...list, item];
      }, []);
    }
  };

  changeValue = (event) => {
    const {
      detail: { name, value },
    } = event;
    if (checkValueById(this.values, name)) {
      this.values = [...this.values, { id: name, value }];
    } else {
      this.values = this.values.reduce((list, item) => {
        const exists = item.id === name;
        if (exists) {
          return [
            ...list,
            {
              ...item,
              value,
            },
          ];
        }
        return [...list, item];
      }, []);
    }
  };

  handleFilter = () => {
    this.filteredValue = this.filters.map((filter) => ({
      tags: filter.tags,
      storedTags: filter.tags,
      id: filter.id,
      data:
        [
          ...(filter.tags || []),
          ...filter.data
            .filter((item) => item.checked)
            .map((item) => item.value),
        ] || [],
    }));
    this.updateStore("filteredValue", this.filteredValue);
    this.loadDataFilters();
    this.loadData(1);
  };

  handleReset = () => {
    this.filters = this.filters.map((filter) => ({
      ...filter,
      tags: [],
      storedTags: [],
      data: filter.data.map((item) => ({ ...item, checked: false })),
    }));
    this.options = [];
    this.values = [];
    this.updateStore("filteredValue", []);
    this.loadData(1);
  };

  getValue = (values, id) => {
    if (filterListById(values, id).length > 0) {
      return filterListById(values, id)[0].value;
    } else {
      return [];
    }
  };

  getOptions = (options, id) => {
    if (filterListById(options, id).length > 0) {
      return {
        option: filterListById(options, id)[0].option,
        checkedAll: filterListById(options, id)[0].checkedAll,
      };
    } else {
      return [];
    }
  };

  changeStatus = (event) => {
    const {
      detail: { profile, status },
    } = event;
    if (status === "TRASH") {
      this.rows = this.rows.filter((row) => row.id !== profile.id);
    }
    if (["VALIDATE", "BOOKMARK"].includes(status)) {
      this.rows = this.rows.reduce((list, item) => {
        const exists = item.id === profile.id;
        if (exists) {
          return [
            ...list,
            {
              ...item,
              status,
            },
          ];
        }
        return [...list, item];
      }, []);
    }
  };

  showScreenshot = (event) => {
    const {
      detail: { profile },
    } = event;
    this.screenshot = profile.screenshot.href;
    this.showImage = true;
  };

  clickedAway = () => {
    this.showImage = false;
  };

  closeScreenshot = () => {
    this.showImage = false;
  };

  changeData = (event) => {
    const {
      detail: { data, name },
    } = event;
    this.filters = this.filters.reduce((list, item) => {
      const exists = item.id === name;
      if (exists) {
        return [
          ...list,
          {
            ...item,
            data,
          },
        ];
      }
      return [...list, item];
    }, []);
  };
}

customElements.define("listing-result", ListingResult);
