import { LitElement, html, css } from "lit-element";
import { changeField, matchError } from "mv-form-utils";
import "mv-form-group";
import "mv-form-field";

const EMPTY_LOCATION = {
  streetAddress: "",
  city: "",
  state: "",
  country: ""
};

export class LocationForm extends LitElement {
  static get properties() {
    return {
      name: { type: String },
      label: { type: String },
      locations: { type: Array },
      required: { type: Boolean },
      errors: { type: Object }
    };
  }

  static get styles() {
    return css`
      label {
        display: inline-flex;
        margin-bottom: 10px;
        align-items: center; 
      }

      button {
        display: inline-block;
        width: 25px;
        height: 25px;
        line-height: 20px;
        font-size: 14px;
        border-radius: 50%;
        text-align: center;
        border: none;
        color: #ffffff;
        padding: 0;
        background-color: #3999c1;
        outline: none;
        cursor: pointer;
        margin-right: 10px;
      }

      button:hover {
        background-color: #007fad;
      }

      button.delete {
        margin-top: 10px;
        margin-right: 0;
        background-color: #dd5c55;
      }

      button.delete:hover {
        background-color: #e71919;
      }

      fieldset {
        border-radius: 5px;
        padding: 0 10px;
        margin: 0 0 10px 0;
      }
    `;
  }

  constructor() {
    super();
  }

  render() {
    return html`
      <mv-form-group
        name="${this.name}"
        .values="${this.locations}"
        .error="${matchError(this.errors, this.name)}"
      >
        <label>
          <button class="round-button" @click="${this.addLocation}">
            &#x271A;
          </button>
          ${this.label}${this.required
            ? html`
                <i class="required">*</i>
              `
            : html``}
        </label>
        ${this.locations && this.locations.length > 0
          ? html`
              ${(this.locations || []).map(
                (address, index) => html`
                  <fieldset>
                    <legend>
                      <label>
                        <button
                          class="delete"
                          @click="${this.removeLocation(index)}"
                        >
                          &#x2716;
                        </button>
                      </label>
                    </legend>
                    <mv-form-field
                      item
                      label-position="none"
                      name="streetAddress"
                      label="Street address"
                      placeholder="Enter street address..."
                      .value="${address.streetAddress}"
                      .index="${index}"
                      .error="${matchError(
                        this.errors,
                        "streetAddress",
                        this.name,
                        index
                      )}"
                      required
                    ></mv-form-field>
                    <mv-form-field
                      item
                      label-position="none"
                      name="city"
                      label="City"
                      placeholder="Enter city..."
                      .value="${address.city}"
                      .index="${index}"
                      .error="${matchError(
                        this.errors,
                        "city",
                        this.name,
                        index
                      )}"
                      required
                    ></mv-form-field>
                    <mv-form-field
                      item
                      label-position="none"
                      name="state"
                      label="State"
                      placeholder="Enter state..."
                      .value="${address.state}"
                      .index="${index}"
                      .error="${matchError(
                        this.errors,
                        "state",
                        this.name,
                        index
                      )}"
                    ></mv-form-field>
                    <mv-form-field
                      item
                      label-position="none"
                      name="country"
                      label="Country"
                      placeholder="Enter country..."
                      .value="${address.country}"
                      .index="${index}"
                      .error="${matchError(
                        this.errors,
                        "country",
                        this.name,
                        index
                      )}"
                      required
                    ></mv-form-field>
                  </fieldset>
                `
              )}
            `
          : html``}
      </mv-form-group>
    `;
  }

  addLocation = event => {
    const value = [...this.locations, { ...EMPTY_LOCATION }];
    changeField(event.target, {
      name: this.name,
      originalEvent: event,
      value
    });
  };

  removeLocation = index => event => {
    const value = [
      ...[...this.locations.slice(0, index)],
      ...[...this.locations.slice(index + 1)]
    ];
    changeField(event.target, {
      name: this.name,
      validateGroup: true,
      originalEvent: event,
      value
    });
  };
}

customElements.define("location-form", LocationForm);
