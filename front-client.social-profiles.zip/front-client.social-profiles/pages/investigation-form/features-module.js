import { LitElement, html, css } from "lit-element";
import "mv-container";
import "mv-radio";

export class FeaturesModule extends LitElement {
  static get properties() {
    return {
      container: { type: Boolean, attribute: true },
      section: { type: Boolean, attribute: true },
      item: { type: Boolean, attribute: true },
      feature: { type: String, attribute: true },
      first: { type: Boolean, attribute: true },
      last: { type: Boolean, attribute: true },
      lastItem: { type: String, attribute: true },
      firstItem: { type: String, attribute: true },
      label: { type: String, attribute: true },
      "selected-features": { type: Object, attribute: false, reflect: true },
      "enabled-features": { type: Object, attribute: false, reflect: true },
      color: { type: String, attribute: true },
      name: { type: String, attribute: true },
      group: { type: String, attribute: true },
    };
  }

  static get styles() {
    return css`
      .features-container {
        display: grid;
        height: 120px;
      }

      .features-section {
        display: grid;
        grid-template-rows: 20px auto;
      }

      .features-section .label {
        font-weight: bold;
        text-align: center;
      }

      .features-section .options {
        display: grid;
        height: 100px;
        padding: 0 10px;
        justify-content: center;
        align-items: center;
      }

      .features-section.first .options {
        border-radius: 0 0 0 40px;
      }

      .features-section.last .options {
        border-radius: 0 0 40px 0;
      }

      .option {
        display: grid;
        text-align: center;
        justify-content: center;
        align-items: center;
        padding: 20px;
        font-size: 0.8rem;
      }

      .option .name {
        margin-top: 10px;
      }

      mv-radio {
        --mv-radio-light-background-color: #e1e1e1;
        --mv-radio-light-hover-background-color: #e1e1e1;
        --mv-radio-light-hover-border: 1px solid #e1e1e1;
        --mv-radio-light-border: 1px solid #e1e1e1;
        --mv-radio-light-checked-background-color: #e1e1e1;
        --mv-radio-disabled-background: #808080;
        --mv-radio-disabled-border: 1px solid #808080;
        --mv-radio-radio-size: 14px;
        --mv-radio-checkmark-size: 10px;
        --font-size-m: 12.8px;
        --mv-radio-light-color: #ffffff;
      }
    `;
  }

  constructor() {
    super();
    this.enable = false;
  }

  render() {
    if (this.container) {
      const total = this.children.length;
      const gridStyle = `grid-template-columns: repeat(${total}, 1fr)`;

      return html`
        <div class="features-container" style="${gridStyle}">
          <slot name="section"></slot>
        </div>
      `;
    }
    if (this.section) {
      const total = this.children.length;
      const grid = `grid-template-columns: repeat(${total}, 1fr)`;
      const backgroundColor = `background-color: ${this.color}`;
      const color = `color: ${this.color}`;
      const padding = total === 2 ? "padding: 0 50px" : "";
      const optionsStyle = `${grid};${backgroundColor};${padding}`;
      this.setAttribute("slot", "section");

      return html`
        <div
          class="features-section ${this.first ? "first" : ""}${this.last
            ? "last"
            : ""}"
        >
          <div class="label" style="${color}">${this.feature}</div>
          <div class="options" style="${optionsStyle}">
            <slot name="item"></slot>
          </div>
        </div>
      `;
    }
    if (this.item) {
      this.setAttribute("slot", "item");
      const { name, group } = this;
      const enabledFeatures = this["enabled-features"] || {};
      const enabledGroup = enabledFeatures[group] || {};
      const enabled = enabledGroup[name];

      const selectedFeatures = this["selected-features"] || {};
      const selectedGroup = selectedFeatures[group] || {};
      const selected = selectedGroup[name];

      return html`
        <div class="option">
          <mv-radio
            type="single"
            .checked="${selected}"
            @radio-clicked="${this.toggleRadio}"
            .disabled="${!enabled}"
          >
            <div class="name">${this.label}</div>
          </mv-radio>
        </div>
      `;
    }
  }

  connectedCallback() {
    if (this.container) {
      this.firstItem =
        this.children &&
        this.children[0] &&
        this.children[0].getAttribute("feature");
      this.lastItem =
        this.children &&
        this.children[this.children.length - 1] &&
        this.children[this.children.length - 1].getAttribute("feature");
    }
    if (this.section) {
      this.last = this.feature === this.parentNode.lastItem;
      this.first = this.feature === this.parentNode.firstItem;
    }
    super.connectedCallback();
  }

  toggleRadio = (event) => {
    const {
      detail: { checked },
    } = event;
    const { name, group } = this;
    this.dispatchEvent(
      new CustomEvent("update-feature", {
        detail: { name, group, checked },
      })
    );
  };
}

customElements.define("features-module", FeaturesModule);
