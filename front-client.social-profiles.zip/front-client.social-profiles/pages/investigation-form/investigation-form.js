import { LitElement, html, css } from "lit-element";
import "mv-container";
import "mv-font-awesome";
import "mv-tab";
import "mv-tooltip";
import "../../components/layout/page-layout.js";
import "./individual-form.js";
import "./company-form.js";
import "./perimeter-form.js";

export default class InvestigationForm extends LitElement {
  static get properties() {
    return {};
  }

  static get styles() {
    return css`
      :host {
        --mv-tab-content-padding: 0;
      }

      .main-container {
        background: var(--light-9-background);
        height: calc(100% - 40px);
        width: calc(100% - 80px);
        min-width: 990px;
        overflow: auto;
        padding: 40px 40px 0 40px;
        margin: 0;
      }

      .form-details {
        margin-top: 20px;
      }

      .form-details mv-tab[type="icon"] {
        --mv-tab-icon-border-radius: 50%;
        --mv-tab-icon-size: 64px;
        --mv-tab-icon-border: none;
        --icon-justify-items: center;
      }

      .form-details mv-tab {
        --mv-tab-icon-z-index: 10;
      }

      individual-form {
        height: auto;
      }

      mv-fa.tab-icon {
        font-size: 42px;
      }
    `;
  }

  constructor() {
    super();
  }

  render() {
    return html`
      <page-layout name="online-profiling" storage-modes="local">
        <div class="main-container">
          <mv-tab group>
            <mv-tab tab key="targets">Target(s)</mv-tab>
            <mv-tab content key="targets">
              <div class="form-details">
                <mv-tab group type="icon">
                  <mv-tab tab key="individual">
                    <mv-tooltip position="bottom">
                      <mv-fa icon="user" regular class="tab-icon"></mv-fa>
                      <div slot="tooltip-content">Individual</div>
                    </mv-tooltip>
                  </mv-tab>
                  <mv-tab content key="individual">
                    <individual-form
                      name="individual-form"
                      storage-modes="local"
                    ></individual-form>
                  </mv-tab>
                  <mv-tab tab key="company">
                    <mv-tooltip position="bottom">
                      <mv-fa icon="building" regular class="tab-icon"></mv-fa>
                      <div slot="tooltip-content">Company</div>
                    </mv-tooltip>
                  </mv-tab>
                  <mv-tab content key="company">
                    <company-form
                      name="company-form"
                      storage-modes="local"
                    ></company-form>
                  </mv-tab>
                </mv-tab>
              </div>
            </mv-tab>
            <mv-tab tab key="perimeter">Perimeter</mv-tab>
            <mv-tab content key="perimeter">
              <perimeter-form
                name="perimeter-form"
                storage-modes="local"
              ></perimeter-form>
            </mv-tab>
          </mv-tab>
        </div>
      </page-layout>
    `;
  }
}

customElements.define("investigation-form", InvestigationForm);
