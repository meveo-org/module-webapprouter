import { LitElement, html, css } from "lit-element";
import { changeField, matchError } from "mv-form-utils";
import "mv-form-field";
import "mv-input";

export class MultiInput extends LitElement {
  static get properties() {
    return {
      name: { type: String },
      label: { type: String },
      values: { type: Array },
      required: { type: Boolean },
      errors: { type: Object }
    };
  }

  static get styles() {
    return css`
      label {
        display: inline-flex;
        margin-bottom: 10px;
        align-items: center;
      }

      mv-input {
        --mv-input-suffix-width: 30px;
      }

      button {
        display: inline-block;
        width: 25px;
        min-width: 25px;
        height: 25px;
        line-height: 24px;
        font-size: 14px;
        border-radius: 50%;
        text-align: center;
        border: none;
        padding: 0;
        margin-right: 5px;
        color: #ffffff;
        background-color: #3999c1;
        outline: none;
        cursor: pointer;
      }

      button:hover {
        background-color: #007fad;
      }

      button.delete {
        margin: 0 0 0 10px;
        background-color: #dd5c55;
      }

      button.delete:hover {
        background-color: #e71919;
      }

      .multi-input-field {
        margin: 10px 0;
      }
    `;
  }

  constructor() {
    super();
    this.type = "text";
  }

  render() {
    return html`
      <div class="multi-input-field">
        <label>
          <button @click="${this.addValue}">&#x271A;</button>
          ${this.label}${this.required
            ? html`
                <i class="required"> *</i>
              `
            : html``}
        </label>
        ${(this.values || []).map((value, index) => {
          const error = matchError(this.errors, null, this.name, index);
          const hasError = !!error;
          return html`
            <mv-form-field
              item
              label-position="none"
              name="${this.name}"
              label="Street address"
              .error="${error}"
            >
              <mv-input
                label="${this.label}"
                slot="field"
                type="${this.type}"
                .placeholder="${this.label}"
                .value="${value}"
                @input-change="${this.changeValue(index)}"
                ?has-error="${hasError}"
                required
              >
                <button
                  slot="suffix"
                  class="delete"
                  @click="${this.removeValue(index)}"
                >
                  &#x2716;
                </button>
              </mv-input>
            </mv-form-field>
          `;
        })}
      </div>
    `;
  }

  addValue = event => {
    const value = [...this.values, ""];
    changeField(event.target, {
      name: this.name,
      originalEvent: event,
      value
    });
  };

  removeValue = index => event => {
    const value = [
      ...[...this.values.slice(0, index)],
      ...[...this.values.slice(index + 1)]
    ];
    changeField(event.target, {
      name: this.name,
      validateGroup: true,
      originalEvent: event,
      value
    });
  };

  changeValue = index => event => {
    const { detail } = event;
    const value = [
      ...[...this.values.slice(0, index)],
      detail.value,
      ...[...this.values.slice(index + 1)]
    ];
    changeField(event.target, {
      name: this.name,
      validateGroup: true,
      originalEvent: event,
      value
    });
  };
}

customElements.define("multi-input", MultiInput);
