import { LitElement, html, css } from "lit-element";

export class SummaryText extends LitElement {
  static get properties() {
    return {
      label: { type: String },
      value: { type: Array, attribute: false, reflect: true },
      summary: { type: String, attribute: false, reflect: true },
      moreCount: { type: Number, attribute: false, reflect: true },
    };
  }

  static get styles() {
    return css`
      :host {
        font-family: var(--font-family, Arial);
        font-size: var(--font-size-xs);
      }

      .label {
        color: #ffffff;
        background: var(--summary-text-label-background, #6c757d);
        display: inline-block;
        font-weight: bold;
        border-radius: 4px;
        box-sizing: border-box;
        padding: 3px 4.8px;
        text-align: center;
        vertical-align: baseline;
        white-space: nowrap;
      }

      .summary-text {
        color: var(--summary-text-color, #898c91);
        padding: var(--summary-text-padding, 0 20px 20px 20px);
        width: var(--summary-text-width, 455px);
      }

      .more {
        color: #008fc3;
        display: inline-block;
      }

      .hide {
        visibility: hidden;
        display: none;
      }

      .show {
        visibility: visible;
      }
    `;
  }

  constructor() {
    super();
    this.summary = "";
    this.moreCount = 0;
  }

  set value(value) {
    this.updateSummary(value);
  }

  render() {
    const moreClass = this.moreCount > 0 ? "show" : "hide";
    return html`
      <div class="summary-text">
        <span class="label">${this.label}</span>
        <span class="summary-content">${this.summary}</span>
        <span class="more ${moreClass}"> +${this.moreCount} more</span>
      </div>
    `;
  }

  updateSummary = (value) => {
    const hasValue = value.length > 0;
    const hasMore = value.length > 5;
    this.moreCount = value.length - 5;
    this.summary = hasValue
      ? hasMore
        ? value.slice(0, 4).join(", ")
        : value.join(", ")
      : "";
  };
}

customElements.define("summary-text", SummaryText);
