import { LitElement, html, css } from "lit-element";
import "mv-button";
import "mv-container";
import "mv-form";
export class FormSection extends LitElement {
  static get properties() {
    return {
      store: { type: Object, attribute: false, reflect: true },
      schema: { type: Object, attribute: false, reflect: true },
      "selected-features": { type: Object, attribute: false, reflect: true },
      "enabled-features": { type: Object, attribute: false, reflect: true },
    };
  }

  static get styles() {
    return css`
      .form-section {
        margin-top: -32px;
        height: auto;
      }

      .form-container {
        --mv-container-min-width: auto;
        --mv-container-max-width: 100%;
        --mv-container-min-height: auto;
        --mv-container-max-height: auto;
        --mv-container-padding: 0;
        --mv-container-margin: 0;
        --mv-container-border-radius: 20px 20px 40px 40px;
      }

      .form-details {
        display: grid;
        height: auto;
        grid-template-rows: 250px auto 120px;
      }

      .submit-container {
        --mv-container-min-width: auto;
        --mv-container-max-width: 100%;
        --mv-container-min-height: auto;
        --mv-container-margin: 20px 0;
        --mv-container-padding: 10px 20px;
        --mv-container-border-radius: 20px;
      }

      .submit-content {
        width: 100%;
        height: 66px;
        display: flex;
        justify-content: flex-end;
        align-items: center;
      }
    `;
  }

  constructor() {
    super();
  }

  render() {
    const { features } = this.store.state;
    const enabledFeatures = this["enabled-features"];
    return html`
      <div class="form-container">
        <div class="form-section">
          <mv-container class="form-container">
            <mv-form .store="${this.store}" .schema="${this.schema}">
              <div class="form-details">
                <slot></slot>
                <features-module container>
                  <features-module
                    section
                    feature="Reconnaissance"
                    color="#002060"
                  >
                    <features-module
                      item
                      name="socialProfiles"
                      group="reconnaissance"
                      label="Social Profiles"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                    <features-module
                      item
                      name="assets"
                      group="reconnaissance"
                      label="Assets"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                    <features-module
                      item
                      name="onlineMentions"
                      group="reconnaissance"
                      label="Online Mentions"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                  </features-module>

                  <features-module
                    section
                    feature="Analysis & Surveillance"
                    color="#2E75b6"
                  >
                    <features-module
                      item
                      name="socialProfiles"
                      group="analysisAndSurveillance"
                      label="Social Profiles"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                    <features-module
                      item
                      name="monitoring"
                      group="analysisAndSurveillance"
                      label="Monitoring"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                    <features-module
                      item
                      name="crossAnalysis"
                      group="analysisAndSurveillance"
                      label="Cross Analysis"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                  </features-module>

                  <features-module
                    section
                    feature="Corporate Affiliations"
                    color="#148C9C"
                  >
                    <features-module
                      item
                      name="iep"
                      group="corporateAffiliations"
                      label="IEP"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                    <features-module
                      item
                      name="kyc"
                      group="corporateAffiliations"
                      label="KYC"
                      .selected-features="${features}"
                      .enabled-features="${enabledFeatures}"
                      @update-feature="${this.updateFeature}"
                    >
                    </features-module>
                  </features-module>
                </features-module>
              </div>
            </mv-form>
          </mv-container>
        </div>
        <div class="submit-section">
          <mv-container class="submit-container">
            <div class="submit-content">
              <mv-button type="rounded" @button-clicked="${this.submitForm}">
                Submit
              </mv-button>
            </div>
          </mv-container>
        </div>
      </div>
    `;
  }

  updateFeature = (event) => {
    const { features } = this.store.state;
    const { target, detail } = event;
    const { name, group, checked } = detail;
    const updatedFeatures = {
      ...features,
      [group]: {
        ...features[group],
        [name]: checked,
      },
    };
    this.dispatchEvent(
      new CustomEvent("update-features", {
        detail: { features: updatedFeatures, target },
      })
    );
  };

  submitForm = () => {
    this.dispatchEvent(new CustomEvent("submit-form"));
  };
}

customElements.define("form-section", FormSection);
