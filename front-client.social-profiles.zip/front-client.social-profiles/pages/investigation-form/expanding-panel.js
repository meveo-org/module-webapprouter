import { LitElement, html, css } from "lit-element";
import "mv-font-awesome";
import "./summary-text.js";

export class ExpandingPanel extends LitElement {
  static get properties() {
    return {
      label: { type: String },
      summaryLabel: { type: String },
      value: { type: Array, attribute: false, reflect: true },
      open: { type: Boolean },
    };
  }

  static get styles() {
    return css`
      .expanding-panel {
        border: 1px solid #bfc0c4;
        border-radius: 5px;
        margin: 5px 0;
        transition: all 500ms;
      }

      .label-group {
        padding: 20px;
      }

      .content.open {
        padding: 0 20px 10px 20px;
      }

      .content {
        font-family: MuseoSans;
        padding-top: 0;
      }

      .label-group {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-content: center;
        cursor: pointer;
        user-select: none;
      }

      .label-group mv-fa {
        font-size: var(--font-size-l);
        color: #008fc3;
      }

      .label {
        font-family: MuseoSans;
        font-weight: bold;
        font-size: var(--font-size-l);
        color: #008fc3;
      }

      .close {
        visibility: hidden;
        display: none;
      }

      .open {
        visibility: visible;
        display: block;
      }
    `;
  }

  constructor() {
    super();
    this.value = [];
    this.label = "";
    this.summaryLabel = "";
    this.open = false;
  }

  render() {
    const summaryViewable = !this.open && this.value.length > 0;
    const summaryClass = summaryViewable ? "open" : "close";
    return html`
      <div class="expanding-panel">
        <div class="label-group" @click="${this.togglePanel}">
          <div class="label">${this.label}</div>
          ${this.open
            ? html` <mv-fa icon="chevron-up"></mv-fa> `
            : html` <mv-fa icon="chevron-down"></mv-fa> `}
        </div>
        <div class="summary ${summaryClass}">
          <summary-text
            label="${this.summaryLabel}"
            .value="${this.value}"
          ></summary-text>
        </div>
        <div class="content ${this.open ? "open" : "close"}">
          <slot></slot>
        </div>
      </div>
    `;
  }

  togglePanel = () => {
    this.dispatchEvent(new CustomEvent("toggle-panel"));
  };
}

customElements.define("expanding-panel", ExpandingPanel);
