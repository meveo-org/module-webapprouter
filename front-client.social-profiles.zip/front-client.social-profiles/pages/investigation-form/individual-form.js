import { html, css } from "lit-element";
import { MvElement } from "mv-element";
import { validate, changeField, matchError } from "mv-form-utils";
import { and, or } from "../../components/utils/index.js";
import "mv-form-field";
import "mv-select";
import "mv-calendar";
import "./form-section.js";
import "./location-form.js";
import "./multi-input.js";
import "./features-module.js";

import schema from "../../model/IndividualForm.json";

const GENDER_OPTIONS = [
  {
    label: "Male",
    value: "male",
  },
  {
    label: "Female",
    value: "female",
  },
];

export class IndividualForm extends MvElement {
  static get properties() {
    return {
      firstName: { type: String, attribute: false },
      lastName: { type: String, attribute: false },
      gender: { type: String, attribute: false },
      birthDate: { type: Date, attribute: false },
      placeOfBirth: { type: String, attribute: false },
      nationality: { type: String, attribute: false },
      aliases: { type: Array, attribute: false },
      places: { type: Array, attribute: false },
      visitedPlaces: { type: Array, attribute: false },
      emails: { type: Array, attribute: false },
      phoneNumbers: { type: Array, attribute: false },
      userNames: { type: Array, attribute: false },
      socialProfiles: { type: Array, attribute: false },
      relatives: { type: Array, attribute: false },
      acquaintances: { type: Array, attribute: false },
      hobbies: { type: Array, attribute: false },
      education: { type: Array, attribute: false },
      companies: { type: Array, attribute: false },
      websites: { type: Array, attribute: false },
      brands: { type: Array, attribute: false },
      otherAssets: { type: Array, attribute: false },
      socialMentions: { type: Array, attribute: false },
      reputation: { type: Array, attribute: false },
      otherFootprints: { type: Array, attribute: false },
      errors: { type: Object, attribute: false },
      features: { type: Object, attribute: false },
    };
  }

  static get styles() {
    return css`
      mv-select {
        --mv-select-font-size: 16px;
        --mv-select-input-padding: 6.25px;
      }

      .personal-details {
        margin-top: 50px;
        display: flex;
        width: 100%;
        flex-direction: column;
      }

      .name,
      .birth-info,
      .nationality {
        display: grid;
        grid-column-gap: 5px;
        align-items: flex-start;
        align-content: flex-start;
        justify-items: center;
        justify-content: center;
        margin: 0 auto;
        min-height: 68px;
        --mv-input-min-width: 276px;
      }

      .dash {
        padding-top: 12px;
      }

      .name {
        grid-template-columns: 1fr 1fr 12px auto;
      }

      .birth-info {
        grid-template-columns: 1fr 12px auto;
        min-height: 72px;
      }

      .birth-date {
        margin-top: -5px;
      }

      .nationality {
        grid-template-columns: auto;
      }

      .first-name {
        font-weight: bold;
        text-transform: capitalize;
      }

      .last-name {
        font-weight: bold;
        text-transform: uppercase;
      }

      .additional-details {
        margin: 20px 40px 40px 40px;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-column-gap: 30px;
      }

      .detail-group {
        margin-top: 20px;
      }

      .group {
        font-weight: bold;
      }

      .places {
        margin-top: 10px;
      }
    `;
  }

  static get model() {
    return {
      modelClass: "IndividualForm",
      mappings: [
        { property: "firstName", value: "firstName" },
        { property: "lastName", value: "lastName" },
        { property: "gender", value: "gender" },
        { property: "birthDate", value: "birthDate" },
        { property: "placeOfBirth", value: "placeOfBirth" },
        { property: "nationality", value: "nationality" },
        { property: "aliases", value: "aliases" },
        { property: "places", value: "places" },
        { property: "visitedPlaces", value: "visitedPlaces" },
        { property: "emails", value: "emails" },
        { property: "phoneNumbers", value: "phoneNumbers" },
        { property: "userNames", value: "userNames" },
        { property: "socialProfiles", value: "socialProfiles" },
        { property: "relatives", value: "relatives" },
        { property: "acquaintances", value: "acquaintances" },
        { property: "hobbies", value: "hobbies" },
        { property: "education", value: "education" },
        { property: "companies", value: "companies" },
        { property: "websites", value: "websites" },
        { property: "brands", value: "brands" },
        { property: "otherAssets", value: "otherAssets" },
        { property: "socialMentions", value: "socialMentions" },
        { property: "reputation", value: "reputation" },
        { property: "otherFootprints", value: "otherFootprints" },
        { property: "features", value: "features" },
      ],
    };
  }

  constructor() {
    super();
  }

  render() {
    const enabledFeatures = this.mapEnabledFeatures();
    const birthDate = this.birthDate && new Date(this.birthDate);

    return html`
      <form-section
        .store="${this.store}"
        .schema="${schema}"
        .enabled-features="${enabledFeatures}"
        @update-features="${this.updateFeatures}"
        @submit-form="${this.submitForm}"
      >
        <div class="personal-details">
          <div class="name">
            <mv-form-field
              name="firstName"
              placeholder="First name"
              label-position="none"
              .value="${this.firstName}"
              .error="${matchError(this.errors, "firstName")}"
              required
            ></mv-form-field>
            <mv-form-field
              name="lastName"
              placeholder="Last name"
              label-position="none"
              .value="${this.lastName}"
              .error="${matchError(this.errors, "lastName")}"
              required
            ></mv-form-field>
            <div class="dash">&#x2013;</div>
            <mv-form-field
              name="gender"
              label-position="none"
              .error="${matchError(this.errors, "gender")}"
            >
              <mv-select
                slot="field"
                .value="${this.findGender(this.gender)}"
                .options="${GENDER_OPTIONS}"
                @select-option="${this.changeGender}"
                @on-clear="${this.clearGender}"
              ></mv-select>
            </mv-form-field>
          </div>
          <div class="birth-info">
            <div class="birth-date">
              <mv-form-field
                name="birthDate"
                label-position="none"
                .error="${matchError(this.errors, "birthDate")}"
              >
                <mv-calendar
                  name="birthDate"
                  slot="field"
                  name="birthDate"
                  theme="light"
                  placeholder="Birth Date"
                  .selected-date="${birthDate}"
                  @select-date="${this.changeDate}"
                  dropdown
                ></mv-calendar>
              </mv-form-field>
            </div>
            <div class="dash">&#x2013;</div>
            <div class="birth-place">
              <mv-form-field
                name="placeOfBirth"
                placeholder="Place of birth"
                label-position="none"
                .value="${this.placeOfBirth}"
                .error="${matchError(this.errors, "placeOfBirth")}"
              ></mv-form-field>
            </div>
          </div>
          <div class="nationality">
            <mv-form-field
              name="nationality"
              placeholder="Nationality"
              label-position="none"
              .value="${this.nationality}"
              .error="${matchError(this.errors, "nationality")}"
            ></mv-form-field>
          </div>
        </div>
        <div class="additional-details">
          <div class="detail-column">
            <div class="detail-group">
              <div class="aliases group">
                <multi-input
                  name="aliases"
                  label="Aliases"
                  .values="${this.aliases || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="locations group">Locations</div>
              <div class="places">
                <location-form
                  name="places"
                  label="Places"
                  .locations="${this.places || []}"
                  .errors="${this.errors}"
                ></location-form>
              </div>
              <div class="visited-places">
                <location-form
                  name="visitedPlaces"
                  label="Visited places"
                  .locations="${this.visitedPlaces || []}"
                  .errors="${this.errors}"
                ></location-form>
              </div>
            </div>
            <div class="detail-group">
              <div class="contact-details group">Contact details</div>
              <div class="emails">
                <multi-input
                  name="emails"
                  label="Emails"
                  type="email"
                  .values="${this.emails || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="phone-numbers">
                <multi-input
                  name="phoneNumbers"
                  label="Phone numbers"
                  .values="${this.phoneNumbers || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
          <div class="detail-column">
            <div class="detail-group">
              <div class="online-identity group">Online Identity</div>
              <div class="usernames">
                <multi-input
                  name="userNames"
                  label="User names"
                  .values="${this.userNames || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="social-profiles">
                <multi-input
                  name="socialProfiles"
                  label="Social profiles"
                  .values="${this.socialProfiles || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
            <div class="detail-group">
              <div class="private-life group">Private Life</div>
              <div class="relatives">
                <multi-input
                  name="relatives"
                  label="Relatives"
                  .values="${this.relatives || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="acquaintances">
                <multi-input
                  name="acquaintances"
                  label="Acquaintances"
                  .values="${this.acquaintances || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="hobbies">
                <multi-input
                  name="hobbies"
                  label="Hobbies"
                  .values="${this.hobbies || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
          <div class="detail-column">
            <div class="detail-group">
              <div class="professional-life group">
                Professional life
              </div>
              <div class="education">
                <multi-input
                  name="education"
                  label="Education"
                  .values="${this.education || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="companies">
                <multi-input
                  name="companies"
                  label="Companies"
                  .values="${this.companies || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
            <div class="detail-group">
              <div class="assets group">Assets</div>
              <div class="websites">
                <multi-input
                  name="websites"
                  label="Websites"
                  .values="${this.websites || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="brands">
                <multi-input
                  name="brands"
                  label="Brands"
                  .values="${this.brands || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="other">
                <multi-input
                  name="otherAssets"
                  label="Other"
                  .values="${this.otherAssets || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
          <div class="detail-column">
            <div class="detail-group">
              <div class="footprints group">Footprints</div>
              <div class="social-mentions">
                <multi-input
                  name="socialMentions"
                  label="Social mentions"
                  .values="${this.socialMentions || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="reputation">
                <multi-input
                  name="reputation"
                  label="Reputation"
                  .values="${this.reputation || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="other">
                <multi-input
                  name="otherFootprints"
                  label="Other"
                  .values="${this.otherFootprints || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
        </div>
      </form-section>
    `;
  }

  connectedCallback() {
    this.addEventListener("update-errors", this.handleErrors);
    this.addEventListener("clear-errors", this.clearErrors);
    super.connectedCallback();
  }

  mapEnabledFeatures = () => {
    const {
      firstName,
      lastName,
      aliases,
      userNames,
      phoneNumbers,
      emails,
    } = this.store.state;
    const enableFeatures = or(
      and(firstName, lastName),
      aliases,
      userNames,
      phoneNumbers,
      emails
    );

    return {
      reconnaissance: {
        socialProfiles: enableFeatures,
        assets: enableFeatures,
        onlineMentions: enableFeatures,
      },
      analysisAndSurveillance: {
        socialProfiles: false,
        monitoring: false,
        crossAnalysis: false,
      },
      corporateAffiliations: { iep: false, kyc: false },
    };
  };

  findGender = (gender) => {
    return GENDER_OPTIONS.find((option) => option.value === gender);
  };

  changeGender = (event) => {
    const {
      target,
      detail: {
        option: { value },
      },
    } = event;
    changeField(target, { name: "gender", value, originalEvent: event });
  };

  clearGender = (event) => {
    const {
      detail: { originalEvent },
    } = event;
    changeField(originalEvent.target, {
      name: "gender",
      value: null,
      originalEvent: event,
    });
  };

  changeDate = (event) => {
    const { target, detail } = event;
    changeField(target, {
      name: "birthDate",
      value: detail.date ? detail.date.toISOString() : "",
      originalEvent: event,
    });
  };

  confirmClearForm = () => {
    return confirm("Are you sure you want to clear the form? ");
  };

  clearErrors = () => {
    this.errors = null;
  };

  handleErrors = (event) => {
    this.errors = event.detail.errors;
  };

  updateFeatures = (event) => {
    const {
      detail: { target, features },
    } = event;
    changeField(target, {
      name: "features",
      value: features,
      originalEvent: event,
    });
  };

  submitForm = () => {
    const errors = validate(schema, this.store.state);
    const hasError = errors && Object.keys(errors).some((key) => !!errors[key]);
    if (hasError) {
      this.errors = errors;
      alert("Please fill out the form completely before submitting.");
    } else {
      const results = this.store.state;
      // TODO use the form results
      console.log("Results: ", results);
      history.pushState(null, "", "./results/dashboard");
    }
  };
}

customElements.define("individual-form", IndividualForm);
