import { html, css } from "lit-element";
import { MvElement } from "mv-element";
import { changeField } from "mv-form-utils";
import "mv-form";
import "mv-form-field";
import "mv-listbox";
import "mv-tags";
import "./expanding-panel.js";

import schema from "../../model/PerimeterForm.json";

export class PerimeterForm extends MvElement {
  static get properties() {
    return {
      openPanels: { type: Object, attribute: false, reflect: true },
      locations: { type: Array, attribute: false, reflect: true },
      credential: { type: Array, attribute: false, reflect: true },
      categories: { type: Array, attribute: false, reflect: true },
      languages: { type: Array, attribute: false, reflect: true },
      socialMention: { type: Array, attribute: false, reflect: true },
      errors: { type: Object, attribute: false, reflect: true },
    };
  }

  static get styles() {
    return css`
      :host {
        --mv-listbox-padding: 20px 20px 0 20px;
        --mv-listbox-border: 1px solid #e1e2e7;
        --mv-listbox-shadow: none;
      }
    `;
  }

  static get model() {
    return {
      modelClass: "PerimeterForm",
      mappings: [
        { property: "locations", value: "locations" },
        { property: "credential", value: "credential" },
        { property: "categories", value: "categories" },
        { property: "languages", value: "languages" },
        { property: "socialMention", value: "socialMention" },
      ],
    };
  }

  constructor() {
    super();
    this.openPanels = {};
  }

  render() {
    return html`
      <div class="perimeter-form-main">
        <mv-form .store="${this.store}" .schema="${schema}">
          <div class="form-contents">
            <div class="form-fields">
              <mv-listbox list>
                <mv-listbox item>
                  <expanding-panel
                    label="Location of the investigator"
                    summaryLabel="Locations"
                    .value="${this.locations || []}"
                    ?open="${this.openPanels.locations}"
                    @toggle-panel="${this.togglePanel("locations")}"
                  >
                    <mv-form-field name="locations" label-position="none">
                      <mv-tags
                        slot="field"
                        .tags="${this.locations || []}"
                        @add-tag="${this.updateValue("locations")}"
                        @remove-tag="${this.updateValue("locations")}"
                        placeholder="Enter locations..."
                      ></mv-tags>
                    </mv-form-field>
                  </expanding-panel>
                </mv-listbox>

                <mv-listbox item>
                  <expanding-panel
                    label="Credential"
                    summaryLabel="Credentials"
                    .value="${this.credential || []}"
                    ?open="${this.openPanels.credential}"
                    @toggle-panel="${this.togglePanel("credential")}"
                  >
                    <mv-form-field name="credential" label-position="none">
                      <mv-tags
                        slot="field"
                        .tags="${this.credential || []}"
                        @add-tag="${this.updateValue("credential")}"
                        @remove-tag="${this.updateValue("credential")}"
                        placeholder="Enter credential..."
                      ></mv-tags>
                    </mv-form-field>
                  </expanding-panel>
                </mv-listbox>

                <mv-listbox item>
                  <expanding-panel
                    label="Category of services"
                    summaryLabel="Categories"
                    .value="${this.categories || []}"
                    ?open="${this.openPanels.categories}"
                    @toggle-panel="${this.togglePanel("categories")}"
                  >
                    <mv-form-field name="categories" label-position="none">
                      <mv-tags
                        slot="field"
                        .tags="${this.categories || []}"
                        @add-tag="${this.updateValue("categories")}"
                        @remove-tag="${this.updateValue("categories")}"
                        placeholder="Enter categories..."
                      ></mv-tags>
                    </mv-form-field>
                  </expanding-panel>
                </mv-listbox>

                <mv-listbox item>
                  <expanding-panel
                    label="Language of results"
                    summaryLabel="Languages"
                    .value="${this.languages || []}"
                    ?open="${this.openPanels.languages}"
                    @toggle-panel="${this.togglePanel("languages")}"
                  >
                    <mv-form-field name="languages" label-position="none">
                      <mv-tags
                        slot="field"
                        .tags="${this.languages || []}"
                        @add-tag="${this.updateValue("languages")}"
                        @remove-tag="${this.updateValue("languages")}"
                        placeholder="Enter languages..."
                      ></mv-tags>
                    </mv-form-field>
                  </expanding-panel>
                </mv-listbox>

                <mv-listbox item>
                  <expanding-panel
                    label="Social mention"
                    summaryLabel="Social mentions"
                    .value="${this.socialMention || []}"
                    ?open="${this.openPanels.socialMention}"
                    @toggle-panel="${this.togglePanel("socialMention")}"
                  >
                    <mv-form-field name="socialMention" label-position="none">
                      <mv-tags
                        slot="field"
                        .tags="${this.socialMention || []}"
                        @add-tag="${this.updateValue("socialMention")}"
                        @remove-tag="${this.updateValue("socialMention")}"
                        placeholder="Enter social mention..."
                      ></mv-tags>
                    </mv-form-field>
                  </expanding-panel>
                </mv-listbox>
              </mv-listbox>
            </div>
          </div>
        </mv-form>
      </div>
    `;
  }

  togglePanel = (name) => () => {
    this.openPanels = { ...this.openPanels, [name]: !this.openPanels[name] };
  };

  updateValue = (name) => (event) => {
    const { target, detail } = event;
    const { tags } = detail;
    changeField(target, { name, value: tags, originalEvent: event });
  };
}

customElements.define("perimeter-form", PerimeterForm);
