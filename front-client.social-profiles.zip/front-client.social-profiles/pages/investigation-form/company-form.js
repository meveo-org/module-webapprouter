import { html, css } from "lit-element";
import { MvElement } from "mv-element";
import { validate, changeField, matchError } from "mv-form-utils";
import { or } from "../../components/utils/index.js";
import "mv-form-field";
import "mv-calendar";

import "./multi-input.js";
import "./features-module.js";
import "./form-section.js";

import schema from "../../model/CompanyForm.json";

export class CompanyForm extends MvElement {
  static get properties() {
    return {
      //Identify
      companyName: { type: String, attribute: false },
      registrationDate: { type: String, attribute: false },
      registrationId: { type: String, attribute: false },
      country: { type: String, attribute: false },
      aliases: { type: Array, attribute: false },

      // Locations
      places: { type: Array, attribute: false },

      // Contact details
      emails: { type: Array, attribute: false },
      phoneNumbers: { Array: String, attribute: false },

      // Online Identity
      userNames: { type: Array, attribute: false },
      socialProfiles: { Array: String, attribute: false },

      // Affiliations
      keyPeople: { type: Array, attribute: false },
      employees: { type: Array, attribute: false },
      corporateGroup: { type: Array, attribute: false },

      // Assets
      websites: { type: Array, attribute: false },
      trademarks: { type: Array, attribute: false },
      patents: { type: Array, attribute: false },
      otherAssets: { type: Array, attribute: false },

      //Footprints
      socialMentions: { type: Array, attribute: false },
      reputation: { type: Array, attribute: false },
      otherFootprints: { type: Array, attribute: false },

      errors: { type: Object, attribute: false },
      features: { type: Object, attribute: false },
    };
  }

  static get styles() {
    return css`
      .company-form {
        display: flex;
        flex-direction: column;
        height: auto;
      }

      .form-section {
        margin-top: -32px;
        height: auto;
      }

      .form-container {
        --mv-container-min-width: auto;
        --mv-container-max-width: 100%;
        --mv-container-min-height: auto;
        --mv-container-max-height: auto;
        --mv-container-padding: 0;
        --mv-container-margin: 0;
        --mv-container-border-radius: 20px 20px 40px 40px;
      }

      .submit-container {
        --mv-container-min-width: auto;
        --mv-container-max-width: 100%;
        --mv-container-min-height: auto;
        --mv-container-margin: 20px 0;
        --mv-container-padding: 10px 20px;
        --mv-container-border-radius: 20px;
      }

      .submit-content {
        width: 100%;
        height: 66px;
        display: flex;
        justify-content: flex-end;
        align-items: center;
      }

      .company-container {
        display: grid;
        height: auto;
        grid-template-rows: 250px auto 120px;
      }

      .company-details {
        margin-top: 50px;
        display: flex;
        width: 100%;
        flex-direction: column;
        min-height: 50px;
      }

      .name,
      .registration-info,
      .country {
        display: grid;
        grid-column-gap: 5px;
        align-items: flex-start;
        align-content: flex-start;
        justify-items: center;
        justify-content: center;
        margin: 0 auto;
        min-height: 68px;
        --mv-input-min-width: 310px;
      }

      .dash {
        padding-top: 12px;
      }

      .registration-info {
        grid-template-columns: 1fr 12px auto;
        min-height: 72px;
      }

      .registration-date {
        margin-top: -5px;
      }

      .additional-details {
        margin: 20px 40px 40px 40px;
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-column-gap: 30px;
      }

      .detail-group {
        margin-top: 20px;
      }

      .group {
        font-weight: bold;
      }
    `;
  }

  static get model() {
    return {
      modelClass: "CompanyForm",
      mappings: [
        { property: "companyName", value: "companyName" },
        { property: "registrationDate", value: "registrationDate" },
        { property: "registrationId", value: "registrationId" },
        { property: "country", value: "country" },
        { property: "aliases", value: "aliases" },

        { property: "places", value: "places" },

        { property: "emails", value: "emails" },
        { property: "phoneNumbers", value: "phoneNumbers" },

        { property: "userNames", value: "userNames" },
        { property: "socialProfiles", value: "socialProfiles" },

        { property: "keyPeople", value: "keyPeople" },
        { property: "employees", value: "employees" },
        { property: "corporateGroup", value: "corporateGroup" },

        { property: "websites", value: "websites" },
        { property: "trademarks", value: "trademarks" },
        { property: "patents", value: "patents" },
        { property: "otherAssets", value: "otherAssets" },

        { property: "socialMentions", value: "socialMentions" },
        { property: "reputation", value: "reputation" },
        { property: "otherFootprints", value: "otherFootprints" },
      ],
    };
  }

  constructor() {
    super();
  }

  render() {
    const enabledFeatures = this.mapEnabledFeatures();
    const registrationDate =
      this.registrationDate && new Date(this.registrationDate);

    return html`
      <form-section
        .store="${this.store}"
        .schema="${schema}"
        .enabled-features="${enabledFeatures}"
        @update-features="${this.updateFeatures}"
        @submit-form="${this.submitForm}"
      >
        <div class="company-details">
          <div class="name">
            <mv-form-field
              name="companyName"
              placeholder="Company Name"
              label-position="none"
              .value="${this.companyName}"
              .error="${matchError(this.errors, "companyName")}"
              required
            ></mv-form-field>
          </div>
          <div class="registration-info">
            <div class="registration-date">
              <mv-form-field
                name="registrationDate"
                label-position="none"
                .error="${matchError(this.errors, "registrationDate")}"
              >
                <mv-calendar
                  slot="field"
                  name="registrationDate"
                  theme="light"
                  .selected-date="${registrationDate}"
                  @select-date="${this.changeDate}"
                  placeholder="Registration Date"
                  dropdown
                ></mv-calendar>
              </mv-form-field>
            </div>
            <div class="dash">&#x2013;</div>
            <div class="registration-id">
              <mv-form-field
                name="registrationId"
                placeholder="Registration Id"
                label-position="none"
                .value="${this.registrationId}"
                .error="${matchError(this.errors, "registrationId")}"
              ></mv-form-field>
            </div>
          </div>
          <div class="country">
            <mv-form-field
              name="country"
              placeholder="Country"
              label-position="none"
              .value="${this.country}"
              .error="${matchError(this.errors, "country")}"
            ></mv-form-field>
          </div>
        </div>
        <div class="additional-details">
          <div class="detail-column">
            <div class="detail-group">
              <div class="aliases group">
                <multi-input
                  name="aliases"
                  label="Aliases"
                  .values="${this.aliases || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="locations group">
                <location-form
                  name="places"
                  label="Locations"
                  .locations="${this.places || []}"
                  .errors="${this.errors}"
                ></location-form>
              </div>
            </div>
            <div class="detail-group">
              <div class="contact-details group">Contact details</div>
              <div class="emails">
                <multi-input
                  name="emails"
                  label="Emails"
                  type="email"
                  .values="${this.emails || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="phone-numbers">
                <multi-input
                  name="phoneNumbers"
                  label="Phone numbers"
                  .values="${this.phoneNumbers || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
          <div class="detail-column">
            <div class="detail-group">
              <div class="online-identity group">
                Online Identity
              </div>
              <div class="usernames">
                <multi-input
                  name="userNames"
                  label="User names"
                  .values="${this.userNames || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="social-profiles">
                <multi-input
                  name="socialProfiles"
                  label="Social profiles"
                  .values="${this.socialProfiles || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
            <div class="detail-group">
              <div class="affiliations group">Affiliations</div>
              <div class="key-people">
                <multi-input
                  name="keyPeople"
                  label="Key People"
                  .values="${this.keyPeople || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="employees">
                <multi-input
                  name="employees"
                  label="Employees"
                  .values="${this.employees || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="corporate-group">
                <multi-input
                  name="corporateGroup"
                  label="Corporate Group"
                  .values="${this.corporateGroup || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
          <div class="detail-column">
            <div class="detail-group">
              <div class="assets group">Assets</div>
              <div class="websites">
                <multi-input
                  name="websites"
                  label="Websites"
                  .values="${this.websites || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="trademarks">
                <multi-input
                  name="trademarks"
                  label="Trademarks"
                  .values="${this.trademarks || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="patents">
                <multi-input
                  name="patents"
                  label="Patents"
                  .values="${this.patents || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="other">
                <multi-input
                  name="otherAssets"
                  label="Other"
                  .values="${this.otherAssets || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
          <div class="detail-column">
            <div class="detail-group">
              <div class="footprints group">Footprints</div>
              <div class="social-mentions">
                <multi-input
                  name="socialMentions"
                  label="Social mentions"
                  .values="${this.socialMentions || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="reputation">
                <multi-input
                  name="reputation"
                  label="Reputation"
                  .values="${this.reputation || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
              <div class="other">
                <multi-input
                  name="otherFootprints"
                  label="Other"
                  .values="${this.otherFootprints || []}"
                  .errors="${this.errors}"
                ></multi-input>
              </div>
            </div>
          </div>
        </div>
      </form-section>
    `;
  }

  connectedCallback() {
    this.addEventListener("update-form", this.handleFormUpdate);
    this.addEventListener("update-errors", this.handleErrors);
    this.addEventListener("clear-errors", this.clearErrors);
    super.connectedCallback();
  }

  mapEnabledFeatures = () => {
    const {
      companyName,
      aliases,
      userNames,
      phoneNumbers,
      emails,
    } = this.store.state;
    const enableFeatures = or(
      companyName,
      aliases,
      userNames,
      phoneNumbers,
      emails
    );

    return {
      reconnaissance: {
        socialProfiles: enableFeatures,
        assets: enableFeatures,
        onlineMentions: enableFeatures,
      },
      analysisAndSurveillance: {
        socialProfiles: false,
        monitoring: false,
        crossAnalysis: false,
      },
      corporateAffiliations: { iep: false, kyc: false },
    };
  };

  changeDate = (event) => {
    const { target, detail } = event;
    changeField(target, {
      name: "registrationDate",
      value: detail.date ? detail.date.toISOString() : "",
      originalEvent: event,
    });
  };

  clearErrors = () => {
    this.errors = null;
  };

  handleErrors = (event) => {
    this.errors = event.detail.errors;
  };

  updateFeatures = (event) => {
    const {
      detail: { target, features },
    } = event;
    changeField(target, {
      name: "features",
      value: features,
      originalEvent: event,
    });
  };

  submitForm = () => {
    const errors = validate(schema, this.store.state);
    const hasError = errors && Object.keys(errors).some((key) => !!errors[key]);
    if (hasError) {
      this.errors = errors;
      alert("Please fill out the form completely before submitting.");
    } else {
      const results = this.store.state;
      // TODO use the form results
      console.log("Results: ", results);
      history.pushState(null, "", "./results/dashboard");
    }
  };
}

customElements.define("company-form", CompanyForm);
