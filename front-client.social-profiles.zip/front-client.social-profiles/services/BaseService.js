import MeveoAPI from '../MeveoAPI';
import * as properties from '../properties';

export default class BaseService {
	constructor() {
	}

	get meveoAPI() {
		return new MeveoAPI(properties.MEVEO_PATH, localStorage.getItem('token'), properties.MEVEO_PROVIDER);
	}

	socialProfiles_investigation(data, callback) {
		this.meveoAPI.socialProfiles_investigation(data).then(response => {
				if (callback) {
					callback('success', response);
				}
			},
			error => {
				if (callback) {
					callback('error', error);
				}
			}
		);
	}

}
