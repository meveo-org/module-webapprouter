export const profileColumns = [
  {
    name: "platform",
    title: "Platform",
    tooltip: "Platform",
    type: "STRING"
  },
  {
    name: "avatar",
    title: "Picture + Alias + ID",
    tooltip: "Picture + Alias + ID",
    type: "IMAGE"
  },
  {
    name: "username",
    title: "Username",
    tooltip: "Username",
    type: "STRING"
  },
  {
    name: "criteria",
    title: "Number of criteria found",
    tooltip: "Number of criteria found",
    type: "DATE"
  },
  {
    name: "matching",
    title: "Matching",
    tooltip: "Matching",
    type: "STRING"
  },
  {
    name: "lso3",
    title: "LSO3",
    tooltip: "LSO3",
    type: "DATE"
  }
];
