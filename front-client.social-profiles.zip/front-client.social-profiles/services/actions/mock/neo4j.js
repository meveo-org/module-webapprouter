export const neo4j = [
  {
    "columns": [
      "end",
      "end2",
      "end3",
      "r",
      "r2",
      "r3",
      "start"
    ],
    "data": [
      {
        "graph": {
          "nodes": [
            {
              "id": "29141",
              "labels": [
                "Address"
              ],
              "properties": {
                "country": "France",
                "streetType": "RTE",
                "address": "2000  ROUTE DES LUCIOLES 06410 BIOT  France",
                "city_IDX": "biot",
                "city": "BIOT",
                "streetNumber": "2000",
                "latitude": "43.616274",
                "postalCode": "06410",
                "streetName_IDX": "routedeslucioles",
                "streetName": "ROUTE DES LUCIOLES",
                "missionType": "KYC",
                "countryCode": "FR",
                "address_key": "kyc06410biotalpesmaritimesfrancerifft",
                "internal_updateDate": 1559232082443,
                "internal_active": "TRUE",
                "address_IDX": "2000routedeslucioles06410biotfrance",
                "longitude": "7.067898"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "25639",
              "type": "located_in",
              "startNode": "29836",
              "endNode": "29141",
              "properties": {
                "initial": false,
                "until": "-"
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "29141",
              "labels": [
                "Address"
              ],
              "properties": {
                "country": "France",
                "streetType": "RTE",
                "address": "2000  ROUTE DES LUCIOLES 06410 BIOT  France",
                "city_IDX": "biot",
                "city": "BIOT",
                "streetNumber": "2000",
                "latitude": "43.616274",
                "postalCode": "06410",
                "streetName_IDX": "routedeslucioles",
                "streetName": "ROUTE DES LUCIOLES",
                "missionType": "KYC",
                "countryCode": "FR",
                "address_key": "kyc06410biotalpesmaritimesfrancerifft",
                "internal_updateDate": 1559232082443,
                "internal_active": "TRUE",
                "address_IDX": "2000routedeslucioles06410biotfrance",
                "longitude": "7.067898"
              }
            },
            {
              "id": "29719",
              "labels": [
                "Source"
              ],
              "properties": {
                "sourceName_IDX": "googleplace",
                "sourceCode": "GOOGLE_PLACE",
                "missionType": "KYC",
                "entityName": "rifft",
                "companyName": "rifft",
                "internal_updateDate": 1559232082369,
                "sourceName": "Google Place",
                "internal_active": "TRUE",
                "source_key": "kycrifftgoogle_place"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "26738",
              "type": "found_in",
              "startNode": "29719",
              "endNode": "29141",
              "properties": {
                "initial": false,
                "until": "-",
                "creationDate": "30/05/2019"
              }
            },
            {
              "id": "25639",
              "type": "located_in",
              "startNode": "29836",
              "endNode": "29141",
              "properties": {
                "initial": false,
                "until": "-"
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "29746",
              "labels": [
                "QueryCategory"
              ],
              "properties": {
                "queryCategoryCode": "KYC_FINANCIAL_CRIME",
                "score": 2.496666666666668,
                "queryCategoryName_IDX": "financialcrime",
                "queryCategory_key": "financialcrimerifft",
                "entityName": "rifft",
                "queryCategoryName": "FINANCIAL CRIME",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293924
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "26612",
              "type": "has_query_category",
              "startNode": "29836",
              "endNode": "29746",
              "properties": {
                "totalSeverityIndexes": 495,
                "initial": false,
                "nbrResultsPerCat": 95,
                "until": "-",
                "positivePages": [
                  "2.28|https://wydden.com/fanatisme-et-desamour-que-se-passe-t-il-avec-lecosysteme-startup/|escroqueries?  escro  rifft||29/06/2018|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/arnaque-financiere/une-premiere-victoire-procedurale-contre-allcharge-seroph-holding-et-worldpay/|escroqueries?  escro  rifft||28/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/actualites/le-patron-de-la-startup-rifft-soupconne-descroquerie-au-crowdfunding/|escroqueries?  escro  escroc  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/actualites/le-parquet-de-bruxelles-met-en-garde-contre-une-escroquerie-de-grande-ampleur/|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/tag/justice/|escroqueries?  escro  escroc  detournement  rifft|Soupcon|08/04/2019|null|null",
                  "2.28|https://www.verif.com/societe/RIFFT-809106917/|liquidation  rifft||06/12/2018|null|null",
                  "2.28|https://www.verif.com/societe/RIFFT-809106917/|judiciaire  liquidation  redressement  rifft||06/12/2018|null|null",
                  "2.28|https://www.societe.com/societe/rifft-809106917.html|judiciaire  liquidation  redressement  rifft||30/05/2019|null|null",
                  "2.28|https://www.score3.fr/RIFFT-809106917.shtml|liquidation  rifft||01/12/2017|null|null",
                  "2.28|https://www.score3.fr/RIFFT-809106917.shtml|judiciaire  liquidation  rifft||01/12/2017|null|null",
                  "2.28|https://www.rudebaguette.com/2018/05/rifft-ces-las-vegas-prison/|liquidation  escroqueries?  escro  rifft|Soupcon|01/05/2018|null|null",
                  "2.28|https://www.rudebaguette.com/2018/05/rifft-ces-las-vegas-prison/|liquidation  collective  rifft||01/05/2018|null|null",
                  "2.28|https://www.repreneurs.com/jugement-de-conversion-en-liquidation-judiciaire/275890-rifft|liquidation  cessation  procedure  collective  rifft||06/12/2018|null|null",
                  "2.28|https://www.repreneurs.com/jugement-de-conversion-en-liquidation-judiciaire/275890-rifft|judiciaire  liquidation  redressement  des paiements  cessation  procedure  rifft||06/12/2018|null|null",
                  "2.28|https://www.reddit.com/r/france/comments/84u5v2/escroquerie_au_financement_le_fondateur_de_rifft/|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://www.procedurecollective.fr/fr/liquidation-judiciaire/1405932/rifft.aspx|liquidation  cessation  rifft||20/06/2018|null|null",
                  "2.28|https://www.procedurecollective.fr/fr/liquidation-judiciaire/1405932/rifft.aspx|judiciaire  liquidation  redressement  des paiements  cessation  usage  procedure  rifft||20/06/2018|null|null",
                  "2.28|https://www.ouest-france.fr/societe/faits-divers/annecy-arnaque-au-crowdfunding-un-pdg-accuse-de-detournement-de-fonds-5625590|escroqueries?  escro  escroc  detournement  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  rifft||14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  escroqueries?  escro  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/un-ancien-collaborateur-du-startupper-escroc-il-etait-tres-fort-215456|corruption  escroqueries?  escro  escroc  virement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|corruption  rifft||16/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|corruption  escroqueries?  escro  escroc  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.maddyness.com/2018/03/16/la-startup-rifft-soupconnee-davoir-arnaque-ses-clients-le-ceo-mis-en-examen-pour-escroquerie/|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.linguee.com/english-german/translation/insider+trading+policy.html|insider trading  rifft||null|null|null",
                  "2.28|https://www.linformaticien.com/actualites/id/48975/rifft-de-la-french-tech-au-palais-de-justice.aspx|escroqueries?  escro  rifft|Soupcon|28/05/2019|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  organisation   escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  collective  rifft||12/04/2018|null|null",
                  "2.28|https://www.lejournaldesentreprises.com/marseille-nice-toulon/breve/le-p-dg-de-la-start-rifft-soupconne-descroquerie-118338|escroqueries?  escro  rifft|Soupcon|29/05/2019|null|null",
                  "2.28|https://www.ledauphine.com/haute-savoie/2018/03/15/le-pdg-d-une-start-up-soupconne-d-importantes-escroqueries-au-crowdfunding|escroqueries?  escro  rifft||15/03/2018|null|null",
                  "2.28|https://www.infogreffe.fr/entreprise-societe/809106917-rifft-060115B001190000.html|procedure  collective  rifft||17/04/2018|null|null",
                  "2.28|https://www.ideal-investisseur.fr/finance-numerique/arnaque-au-crowdfunding-quelles-precautions-prendre-7145.html|judiciaire  redressement  escroqueries?  escro  procedure  rifft|Soupcon|17/03/2018|null|null",
                  "2.28|https://www.frenchweb.fr/le-patron-de-la-start-up-rifft-mis-en-examen-pour-avoir-detourne-4-millions-deuros-via-le-crowdfunding/319878|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.forum-get-easy.com/index.php?topic=3405.0|escroqueries?  escro  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|https://www.forum-get-easy.com/index.php?topic=3292.0|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.forexcenter.fr/liste-noire/?courtier=bfmvip.com|argent  blanchiment  rifft||30/08/2018|null|null",
                  "2.28|https://www.facebook.com/WiSurf.Officiel/|escro  rifft||null|null|null",
                  "2.28|https://www.facebook.com/MultiWin.plan.PageOfficielle/reviews/|escroqueries?  escro  escroc  rifft|Soupcon|null|null|null",
                  "2.28|https://www.facebook.com/ArnaqueRIFFT|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://www.crowdlending.fr/category/actualites/|liquidation  rifft||04/12/2018|null|null",
                  "2.28|https://www.crowdlending.fr/avec-rifft-le-coq-de-la-french-tech-a-du-plomb-dans-laile/|escro  escroc  rifft||30/01/2015|null|null",
                  "2.28|https://www.companieslist.co.uk/08836246-rifft-limited|liquidation  dissolution  dissolved  rifft||23/11/2018|null|null",
                  "2.28|https://www.cbanque.com/forums/fil/financement-participatif-multiwin-plan.26441/page-3|escroqueries?  escro  parties? civiles?  rifft||30/01/2017|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=rifft|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=passation|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=bankofficevest|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.24matins.fr/nice-le-gerant-dune-start-up-aurait-arnaque-des-milliers-dinternautes-grace-au-financement-participatif-734537|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.20minutes.fr/justice/2238063-20180315-nice-patron-start-up-escroque-pres-10000-donateurs-nouvelle-affaire-madoff|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://tribuca.net/actualites_31007377-derriere-laffaire-rifft-comment-eviter-larnaque-au-crowdfunding|escroqueries?  escro  rifft|Soupcon|01/03/2019|null|null",
                  "2.28|https://tribuca.net/actualites_30799111-le-pdg-de-rifft-soupconne-davoir-escroque-des-milliers-dinternautes|escroqueries?  escro  rifft|Soupcon|27/05/2019|null|null",
                  "2.28|https://reussirsonmlm.com/ct-band-avis-crowdfunding/|fraude  rifft||19/03/2018|null|null",
                  "2.28|https://netbusinessrating.com/fr/fiche-14338-worldventures|escroqueries?  escro  denonciation  rifft||11/12/2018|null|null",
                  "2.28|https://netbusinessrating.com/fr/art_rifft-une-start-up-francaise-qui-se-finance-de-facon-opaque-avec-multiwinplan_333|escro  parties? civiles?  rifft||13/02/2017|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan|escroqueries?  escro  escroc  detournement  procedure  rifft|Soupcon|null|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan/forum/message49808|escroqueries?  escro  rifft|Soupcon|06/12/2018|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan/forum/message46635|escroqueries?  escro  escroc  usage  rifft||01/12/2018|null|null",
                  "2.28|https://m.facebook.com/NBRfr/|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://m.facebook.com/NBRfr/?__tn__=C-R|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://france3-regions.francetvinfo.fr/auvergne-rhone-alpes/haute-savoie/annecy/arnaque-au-financement-participatif-pdg-stat-up-sophia-antipolis-arrete-annecy-1440805.html|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://fr-fr.facebook.com/Wi-Surf-1540120562953029/|escro  rifft||12/03/2018|null|null",
                  "2.28|https://fr-fr.facebook.com/MultiWin.plan.PageOfficielle/reviews/|escroqueries?  escro  escroc  rifft|Soupcon|21/04/2018|null|null",
                  "2.28|https://foxyrating.com/fr/art_rifft-une-start-up-francaise-qui-se-finance-de-facon-opaque-avec-multiwinplan_333|escro  parties? civiles?  rifft||13/02/2017|null|null",
                  "2.28|https://forum.actufinance.fr/multiwinplan-arnaque-t229415|liquidation  rifft|Soupcon|null|null|null",
                  "2.28|https://curation-simple-crm.blogspot.com/2018/04/rifft-startup-dechue-de-la-frenchtech.html|escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://business.lesechos.fr/entrepreneurs/actu/0301444556343-escroquerie-au-financement-le-fondateur-de-rifft-mis-en-examen-319548.php|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://bfmbusiness.bfmtv.com/entreprise/le-pdg-de-cette-start-up-francaise-arrete-pour-escroquerie-au-crowdfunding-1397453.html|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|http://www.webtimemedias.com/article/sophia-le-pdg-de-rifft-soupconne-descroquerie-au-crowfunding-20180315-62337|escroqueries?  escro  rifft|Soupcon|19/03/2018|null|null",
                  "2.28|http://www.varmatin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|escroqueries?  escro  escroc  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|http://www.politologue.com/actualite/actu.COMMENT-FRANCOIS-FILLON-A-ETE-INSTRUMENTALISE-PAR-LE-STARTUPPER-ESCROC-DE-SOPHIA-ANTIPOLIS-NICE-MATIN.zwzpC|escroqueries?  escro  escroc  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.lefigaro.fr/secteur/high-tech/2018/03/15/32001-20180315ARTFIG00382-crowdfunding-le-pdg-d-une-start-up-mis-en-examen-pour-le-detournement-de-4-millions-d-euros.php|escroqueries?  escro  escroc  detournement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.francesoir.fr/societe-faits-divers/escroquerie-au-crowdfundig-le-patron-une-start-francaise-en-prison|escroqueries?  escro  detournement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3451.0|escroqueries?  escro  parties? civiles?  rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3397.0|escroqueries?  escro  escroc  detournement  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3392.0|escroqueries?  escro  filouterie   rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=40|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=20|escroqueries?  escro  escroc  filouterie   detournement  procedure  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=10|escroqueries?  escro  escroc  detournement  parties? civiles?  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=veracarte|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft|fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft|argent  blanchiment  fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft%20usa|fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=blanchiment%20argent|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexcenter.fr/liste-noire/?courtier=vipbinary.com|argent  blanchiment  rifft||30/08/2018|null|null",
                  "2.28|http://www.businessman.fr/information-veille-economique-actualite-entreprise-high-tech-france/information-veille-economique-actualite-entreprise-high-tech/justice-le-pdg-de-rifft-souponn-descroquerie/584369|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=support%20venture%20limited|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=copyop.com|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=184|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/lucas-goreta|detournement  rifft|Soupcon|21/03/2018|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/crowdfunding|detournement  rifft|Soupcon|25/08/2012|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/chaine-de-ponzi|escro  escroc  detournement  rifft|Soupcon|null|null|null",
                  "2.28|http://gender.vivianedebeaufort.fr/la-startup-rifft-soupconnee-davoir-arnaque-ses-investisseurs/|escroqueries?  escro  rifft||16/03/2018|null|null",
                  "2.28|http://entreprises.lefigaro.fr/rifft-06/entreprise-809106917|liquidation  cessation  rifft||06/12/2018|null|null",
                  "2.28|http://entreprises.lefigaro.fr/rifft-06/entreprise-809106917|judiciaire  liquidation  redressement  des paiements  cessation  procedure  rifft||06/12/2018|null|null",
                  "2.28|http://cdn.assets02.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  escroqueries?  escro  rifft|Soupcon|14/03/2018|null|null"
                ],
                "sourceName": "Bing",
                "totalPageScores": 249.14999999999947
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "29746",
              "labels": [
                "QueryCategory"
              ],
              "properties": {
                "queryCategoryCode": "KYC_FINANCIAL_CRIME",
                "score": 2.496666666666668,
                "queryCategoryName_IDX": "financialcrime",
                "queryCategory_key": "financialcrimerifft",
                "entityName": "rifft",
                "queryCategoryName": "FINANCIAL CRIME",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293924
              }
            },
            {
              "id": "30004",
              "labels": [
                "Source"
              ],
              "properties": {
                "sourceName_IDX": "bing",
                "sourceCode": "BING",
                "missionType": "KYC",
                "entityName": "rifft",
                "internal_updateDate": 1559237293924,
                "sourceName": "Bing",
                "internal_active": "TRUE",
                "source_key": "kycrifftbing"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "25456",
              "type": "has_source",
              "startNode": "30004",
              "endNode": "29746",
              "properties": {
                "initial": false,
                "nbrResultsPerCat": 95,
                "until": "-",
                "positivePages": [
                  "2.28|https://wydden.com/fanatisme-et-desamour-que-se-passe-t-il-avec-lecosysteme-startup/|escroqueries?  escro  rifft||29/06/2018|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/arnaque-financiere/une-premiere-victoire-procedurale-contre-allcharge-seroph-holding-et-worldpay/|escroqueries?  escro  rifft||28/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/actualites/le-patron-de-la-startup-rifft-soupconne-descroquerie-au-crowdfunding/|escroqueries?  escro  escroc  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/actualites/le-parquet-de-bruxelles-met-en-garde-contre-une-escroquerie-de-grande-ampleur/|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/tag/justice/|escroqueries?  escro  escroc  detournement  rifft|Soupcon|08/04/2019|null|null",
                  "2.28|https://www.verif.com/societe/RIFFT-809106917/|liquidation  rifft||06/12/2018|null|null",
                  "2.28|https://www.verif.com/societe/RIFFT-809106917/|judiciaire  liquidation  redressement  rifft||06/12/2018|null|null",
                  "2.28|https://www.societe.com/societe/rifft-809106917.html|judiciaire  liquidation  redressement  rifft||30/05/2019|null|null",
                  "2.28|https://www.score3.fr/RIFFT-809106917.shtml|liquidation  rifft||01/12/2017|null|null",
                  "2.28|https://www.score3.fr/RIFFT-809106917.shtml|judiciaire  liquidation  rifft||01/12/2017|null|null",
                  "2.28|https://www.rudebaguette.com/2018/05/rifft-ces-las-vegas-prison/|liquidation  escroqueries?  escro  rifft|Soupcon|01/05/2018|null|null",
                  "2.28|https://www.rudebaguette.com/2018/05/rifft-ces-las-vegas-prison/|liquidation  collective  rifft||01/05/2018|null|null",
                  "2.28|https://www.repreneurs.com/jugement-de-conversion-en-liquidation-judiciaire/275890-rifft|liquidation  cessation  procedure  collective  rifft||06/12/2018|null|null",
                  "2.28|https://www.repreneurs.com/jugement-de-conversion-en-liquidation-judiciaire/275890-rifft|judiciaire  liquidation  redressement  des paiements  cessation  procedure  rifft||06/12/2018|null|null",
                  "2.28|https://www.reddit.com/r/france/comments/84u5v2/escroquerie_au_financement_le_fondateur_de_rifft/|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://www.procedurecollective.fr/fr/liquidation-judiciaire/1405932/rifft.aspx|liquidation  cessation  rifft||20/06/2018|null|null",
                  "2.28|https://www.procedurecollective.fr/fr/liquidation-judiciaire/1405932/rifft.aspx|judiciaire  liquidation  redressement  des paiements  cessation  usage  procedure  rifft||20/06/2018|null|null",
                  "2.28|https://www.ouest-france.fr/societe/faits-divers/annecy-arnaque-au-crowdfunding-un-pdg-accuse-de-detournement-de-fonds-5625590|escroqueries?  escro  escroc  detournement  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  rifft||14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  escroqueries?  escro  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/un-ancien-collaborateur-du-startupper-escroc-il-etait-tres-fort-215456|corruption  escroqueries?  escro  escroc  virement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|corruption  rifft||16/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|corruption  escroqueries?  escro  escroc  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.maddyness.com/2018/03/16/la-startup-rifft-soupconnee-davoir-arnaque-ses-clients-le-ceo-mis-en-examen-pour-escroquerie/|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.linguee.com/english-german/translation/insider+trading+policy.html|insider trading  rifft||null|null|null",
                  "2.28|https://www.linformaticien.com/actualites/id/48975/rifft-de-la-french-tech-au-palais-de-justice.aspx|escroqueries?  escro  rifft|Soupcon|28/05/2019|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  organisation   escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  collective  rifft||12/04/2018|null|null",
                  "2.28|https://www.lejournaldesentreprises.com/marseille-nice-toulon/breve/le-p-dg-de-la-start-rifft-soupconne-descroquerie-118338|escroqueries?  escro  rifft|Soupcon|29/05/2019|null|null",
                  "2.28|https://www.ledauphine.com/haute-savoie/2018/03/15/le-pdg-d-une-start-up-soupconne-d-importantes-escroqueries-au-crowdfunding|escroqueries?  escro  rifft||15/03/2018|null|null",
                  "2.28|https://www.infogreffe.fr/entreprise-societe/809106917-rifft-060115B001190000.html|procedure  collective  rifft||17/04/2018|null|null",
                  "2.28|https://www.ideal-investisseur.fr/finance-numerique/arnaque-au-crowdfunding-quelles-precautions-prendre-7145.html|judiciaire  redressement  escroqueries?  escro  procedure  rifft|Soupcon|17/03/2018|null|null",
                  "2.28|https://www.frenchweb.fr/le-patron-de-la-start-up-rifft-mis-en-examen-pour-avoir-detourne-4-millions-deuros-via-le-crowdfunding/319878|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.forum-get-easy.com/index.php?topic=3405.0|escroqueries?  escro  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|https://www.forum-get-easy.com/index.php?topic=3292.0|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.forexcenter.fr/liste-noire/?courtier=bfmvip.com|argent  blanchiment  rifft||30/08/2018|null|null",
                  "2.28|https://www.facebook.com/WiSurf.Officiel/|escro  rifft||null|null|null",
                  "2.28|https://www.facebook.com/MultiWin.plan.PageOfficielle/reviews/|escroqueries?  escro  escroc  rifft|Soupcon|null|null|null",
                  "2.28|https://www.facebook.com/ArnaqueRIFFT|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://www.crowdlending.fr/category/actualites/|liquidation  rifft||04/12/2018|null|null",
                  "2.28|https://www.crowdlending.fr/avec-rifft-le-coq-de-la-french-tech-a-du-plomb-dans-laile/|escro  escroc  rifft||30/01/2015|null|null",
                  "2.28|https://www.companieslist.co.uk/08836246-rifft-limited|liquidation  dissolution  dissolved  rifft||23/11/2018|null|null",
                  "2.28|https://www.cbanque.com/forums/fil/financement-participatif-multiwin-plan.26441/page-3|escroqueries?  escro  parties? civiles?  rifft||30/01/2017|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=rifft|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=passation|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=bankofficevest|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.24matins.fr/nice-le-gerant-dune-start-up-aurait-arnaque-des-milliers-dinternautes-grace-au-financement-participatif-734537|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.20minutes.fr/justice/2238063-20180315-nice-patron-start-up-escroque-pres-10000-donateurs-nouvelle-affaire-madoff|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://tribuca.net/actualites_31007377-derriere-laffaire-rifft-comment-eviter-larnaque-au-crowdfunding|escroqueries?  escro  rifft|Soupcon|01/03/2019|null|null",
                  "2.28|https://tribuca.net/actualites_30799111-le-pdg-de-rifft-soupconne-davoir-escroque-des-milliers-dinternautes|escroqueries?  escro  rifft|Soupcon|27/05/2019|null|null",
                  "2.28|https://reussirsonmlm.com/ct-band-avis-crowdfunding/|fraude  rifft||19/03/2018|null|null",
                  "2.28|https://netbusinessrating.com/fr/fiche-14338-worldventures|escroqueries?  escro  denonciation  rifft||11/12/2018|null|null",
                  "2.28|https://netbusinessrating.com/fr/art_rifft-une-start-up-francaise-qui-se-finance-de-facon-opaque-avec-multiwinplan_333|escro  parties? civiles?  rifft||13/02/2017|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan|escroqueries?  escro  escroc  detournement  procedure  rifft|Soupcon|null|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan/forum/message49808|escroqueries?  escro  rifft|Soupcon|06/12/2018|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan/forum/message46635|escroqueries?  escro  escroc  usage  rifft||01/12/2018|null|null",
                  "2.28|https://m.facebook.com/NBRfr/|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://m.facebook.com/NBRfr/?__tn__=C-R|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://france3-regions.francetvinfo.fr/auvergne-rhone-alpes/haute-savoie/annecy/arnaque-au-financement-participatif-pdg-stat-up-sophia-antipolis-arrete-annecy-1440805.html|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://fr-fr.facebook.com/Wi-Surf-1540120562953029/|escro  rifft||12/03/2018|null|null",
                  "2.28|https://fr-fr.facebook.com/MultiWin.plan.PageOfficielle/reviews/|escroqueries?  escro  escroc  rifft|Soupcon|21/04/2018|null|null",
                  "2.28|https://foxyrating.com/fr/art_rifft-une-start-up-francaise-qui-se-finance-de-facon-opaque-avec-multiwinplan_333|escro  parties? civiles?  rifft||13/02/2017|null|null",
                  "2.28|https://forum.actufinance.fr/multiwinplan-arnaque-t229415|liquidation  rifft|Soupcon|null|null|null",
                  "2.28|https://curation-simple-crm.blogspot.com/2018/04/rifft-startup-dechue-de-la-frenchtech.html|escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://business.lesechos.fr/entrepreneurs/actu/0301444556343-escroquerie-au-financement-le-fondateur-de-rifft-mis-en-examen-319548.php|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://bfmbusiness.bfmtv.com/entreprise/le-pdg-de-cette-start-up-francaise-arrete-pour-escroquerie-au-crowdfunding-1397453.html|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|http://www.webtimemedias.com/article/sophia-le-pdg-de-rifft-soupconne-descroquerie-au-crowfunding-20180315-62337|escroqueries?  escro  rifft|Soupcon|19/03/2018|null|null",
                  "2.28|http://www.varmatin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|escroqueries?  escro  escroc  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|http://www.politologue.com/actualite/actu.COMMENT-FRANCOIS-FILLON-A-ETE-INSTRUMENTALISE-PAR-LE-STARTUPPER-ESCROC-DE-SOPHIA-ANTIPOLIS-NICE-MATIN.zwzpC|escroqueries?  escro  escroc  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.lefigaro.fr/secteur/high-tech/2018/03/15/32001-20180315ARTFIG00382-crowdfunding-le-pdg-d-une-start-up-mis-en-examen-pour-le-detournement-de-4-millions-d-euros.php|escroqueries?  escro  escroc  detournement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.francesoir.fr/societe-faits-divers/escroquerie-au-crowdfundig-le-patron-une-start-francaise-en-prison|escroqueries?  escro  detournement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3451.0|escroqueries?  escro  parties? civiles?  rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3397.0|escroqueries?  escro  escroc  detournement  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3392.0|escroqueries?  escro  filouterie   rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=40|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=20|escroqueries?  escro  escroc  filouterie   detournement  procedure  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=10|escroqueries?  escro  escroc  detournement  parties? civiles?  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=veracarte|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft|fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft|argent  blanchiment  fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft%20usa|fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=blanchiment%20argent|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexcenter.fr/liste-noire/?courtier=vipbinary.com|argent  blanchiment  rifft||30/08/2018|null|null",
                  "2.28|http://www.businessman.fr/information-veille-economique-actualite-entreprise-high-tech-france/information-veille-economique-actualite-entreprise-high-tech/justice-le-pdg-de-rifft-souponn-descroquerie/584369|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=support%20venture%20limited|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=copyop.com|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=184|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/lucas-goreta|detournement  rifft|Soupcon|21/03/2018|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/crowdfunding|detournement  rifft|Soupcon|25/08/2012|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/chaine-de-ponzi|escro  escroc  detournement  rifft|Soupcon|null|null|null",
                  "2.28|http://gender.vivianedebeaufort.fr/la-startup-rifft-soupconnee-davoir-arnaque-ses-investisseurs/|escroqueries?  escro  rifft||16/03/2018|null|null",
                  "2.28|http://entreprises.lefigaro.fr/rifft-06/entreprise-809106917|liquidation  cessation  rifft||06/12/2018|null|null",
                  "2.28|http://entreprises.lefigaro.fr/rifft-06/entreprise-809106917|judiciaire  liquidation  redressement  des paiements  cessation  procedure  rifft||06/12/2018|null|null",
                  "2.28|http://cdn.assets02.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  escroqueries?  escro  rifft|Soupcon|14/03/2018|null|null"
                ],
                "sourceName": "Bing"
              }
            },
            {
              "id": "26612",
              "type": "has_query_category",
              "startNode": "29836",
              "endNode": "29746",
              "properties": {
                "totalSeverityIndexes": 495,
                "initial": false,
                "nbrResultsPerCat": 95,
                "until": "-",
                "positivePages": [
                  "2.28|https://wydden.com/fanatisme-et-desamour-que-se-passe-t-il-avec-lecosysteme-startup/|escroqueries?  escro  rifft||29/06/2018|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/arnaque-financiere/une-premiere-victoire-procedurale-contre-allcharge-seroph-holding-et-worldpay/|escroqueries?  escro  rifft||28/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/actualites/le-patron-de-la-startup-rifft-soupconne-descroquerie-au-crowdfunding/|escroqueries?  escro  escroc  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/vous-informer/actualites/le-parquet-de-bruxelles-met-en-garde-contre-une-escroquerie-de-grande-ampleur/|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.warning-trading.com/tag/justice/|escroqueries?  escro  escroc  detournement  rifft|Soupcon|08/04/2019|null|null",
                  "2.28|https://www.verif.com/societe/RIFFT-809106917/|liquidation  rifft||06/12/2018|null|null",
                  "2.28|https://www.verif.com/societe/RIFFT-809106917/|judiciaire  liquidation  redressement  rifft||06/12/2018|null|null",
                  "2.28|https://www.societe.com/societe/rifft-809106917.html|judiciaire  liquidation  redressement  rifft||30/05/2019|null|null",
                  "2.28|https://www.score3.fr/RIFFT-809106917.shtml|liquidation  rifft||01/12/2017|null|null",
                  "2.28|https://www.score3.fr/RIFFT-809106917.shtml|judiciaire  liquidation  rifft||01/12/2017|null|null",
                  "2.28|https://www.rudebaguette.com/2018/05/rifft-ces-las-vegas-prison/|liquidation  escroqueries?  escro  rifft|Soupcon|01/05/2018|null|null",
                  "2.28|https://www.rudebaguette.com/2018/05/rifft-ces-las-vegas-prison/|liquidation  collective  rifft||01/05/2018|null|null",
                  "2.28|https://www.repreneurs.com/jugement-de-conversion-en-liquidation-judiciaire/275890-rifft|liquidation  cessation  procedure  collective  rifft||06/12/2018|null|null",
                  "2.28|https://www.repreneurs.com/jugement-de-conversion-en-liquidation-judiciaire/275890-rifft|judiciaire  liquidation  redressement  des paiements  cessation  procedure  rifft||06/12/2018|null|null",
                  "2.28|https://www.reddit.com/r/france/comments/84u5v2/escroquerie_au_financement_le_fondateur_de_rifft/|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://www.procedurecollective.fr/fr/liquidation-judiciaire/1405932/rifft.aspx|liquidation  cessation  rifft||20/06/2018|null|null",
                  "2.28|https://www.procedurecollective.fr/fr/liquidation-judiciaire/1405932/rifft.aspx|judiciaire  liquidation  redressement  des paiements  cessation  usage  procedure  rifft||20/06/2018|null|null",
                  "2.28|https://www.ouest-france.fr/societe/faits-divers/annecy-arnaque-au-crowdfunding-un-pdg-accuse-de-detournement-de-fonds-5625590|escroqueries?  escro  escroc  detournement  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  rifft||14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  escroqueries?  escro  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/un-ancien-collaborateur-du-startupper-escroc-il-etait-tres-fort-215456|corruption  escroqueries?  escro  escroc  virement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|corruption  rifft||16/03/2018|null|null",
                  "2.28|https://www.nicematin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|corruption  escroqueries?  escro  escroc  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.maddyness.com/2018/03/16/la-startup-rifft-soupconnee-davoir-arnaque-ses-clients-le-ceo-mis-en-examen-pour-escroquerie/|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://www.linguee.com/english-german/translation/insider+trading+policy.html|insider trading  rifft||null|null|null",
                  "2.28|https://www.linformaticien.com/actualites/id/48975/rifft-de-la-french-tech-au-palais-de-justice.aspx|escroqueries?  escro  rifft|Soupcon|28/05/2019|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  organisation   escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://www.lemondeinformatique.fr/actualites/lire-rifft-start-up-dechue-de-la-french-tech-et-du-ces-71447.html|liquidation  collective  rifft||12/04/2018|null|null",
                  "2.28|https://www.lejournaldesentreprises.com/marseille-nice-toulon/breve/le-p-dg-de-la-start-rifft-soupconne-descroquerie-118338|escroqueries?  escro  rifft|Soupcon|29/05/2019|null|null",
                  "2.28|https://www.ledauphine.com/haute-savoie/2018/03/15/le-pdg-d-une-start-up-soupconne-d-importantes-escroqueries-au-crowdfunding|escroqueries?  escro  rifft||15/03/2018|null|null",
                  "2.28|https://www.infogreffe.fr/entreprise-societe/809106917-rifft-060115B001190000.html|procedure  collective  rifft||17/04/2018|null|null",
                  "2.28|https://www.ideal-investisseur.fr/finance-numerique/arnaque-au-crowdfunding-quelles-precautions-prendre-7145.html|judiciaire  redressement  escroqueries?  escro  procedure  rifft|Soupcon|17/03/2018|null|null",
                  "2.28|https://www.frenchweb.fr/le-patron-de-la-start-up-rifft-mis-en-examen-pour-avoir-detourne-4-millions-deuros-via-le-crowdfunding/319878|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.forum-get-easy.com/index.php?topic=3405.0|escroqueries?  escro  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|https://www.forum-get-easy.com/index.php?topic=3292.0|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.forexcenter.fr/liste-noire/?courtier=bfmvip.com|argent  blanchiment  rifft||30/08/2018|null|null",
                  "2.28|https://www.facebook.com/WiSurf.Officiel/|escro  rifft||null|null|null",
                  "2.28|https://www.facebook.com/MultiWin.plan.PageOfficielle/reviews/|escroqueries?  escro  escroc  rifft|Soupcon|null|null|null",
                  "2.28|https://www.facebook.com/ArnaqueRIFFT|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://www.crowdlending.fr/category/actualites/|liquidation  rifft||04/12/2018|null|null",
                  "2.28|https://www.crowdlending.fr/avec-rifft-le-coq-de-la-french-tech-a-du-plomb-dans-laile/|escro  escroc  rifft||30/01/2015|null|null",
                  "2.28|https://www.companieslist.co.uk/08836246-rifft-limited|liquidation  dissolution  dissolved  rifft||23/11/2018|null|null",
                  "2.28|https://www.cbanque.com/forums/fil/financement-participatif-multiwin-plan.26441/page-3|escroqueries?  escro  parties? civiles?  rifft||30/01/2017|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=rifft|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=passation|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.alertestrading.fr/alertes-trading/search.php?mots=bankofficevest|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|https://www.24matins.fr/nice-le-gerant-dune-start-up-aurait-arnaque-des-milliers-dinternautes-grace-au-financement-participatif-734537|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://www.20minutes.fr/justice/2238063-20180315-nice-patron-start-up-escroque-pres-10000-donateurs-nouvelle-affaire-madoff|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://tribuca.net/actualites_31007377-derriere-laffaire-rifft-comment-eviter-larnaque-au-crowdfunding|escroqueries?  escro  rifft|Soupcon|01/03/2019|null|null",
                  "2.28|https://tribuca.net/actualites_30799111-le-pdg-de-rifft-soupconne-davoir-escroque-des-milliers-dinternautes|escroqueries?  escro  rifft|Soupcon|27/05/2019|null|null",
                  "2.28|https://reussirsonmlm.com/ct-band-avis-crowdfunding/|fraude  rifft||19/03/2018|null|null",
                  "2.28|https://netbusinessrating.com/fr/fiche-14338-worldventures|escroqueries?  escro  denonciation  rifft||11/12/2018|null|null",
                  "2.28|https://netbusinessrating.com/fr/art_rifft-une-start-up-francaise-qui-se-finance-de-facon-opaque-avec-multiwinplan_333|escro  parties? civiles?  rifft||13/02/2017|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan|escroqueries?  escro  escroc  detournement  procedure  rifft|Soupcon|null|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan/forum/message49808|escroqueries?  escro  rifft|Soupcon|06/12/2018|null|null",
                  "2.28|https://maniabook.argentmania.com/business/mlm/multi-win-plan/forum/message46635|escroqueries?  escro  escroc  usage  rifft||01/12/2018|null|null",
                  "2.28|https://m.facebook.com/NBRfr/|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://m.facebook.com/NBRfr/?__tn__=C-R|escroqueries?  escro  rifft|Soupcon|null|null|null",
                  "2.28|https://france3-regions.francetvinfo.fr/auvergne-rhone-alpes/haute-savoie/annecy/arnaque-au-financement-participatif-pdg-stat-up-sophia-antipolis-arrete-annecy-1440805.html|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|https://fr-fr.facebook.com/Wi-Surf-1540120562953029/|escro  rifft||12/03/2018|null|null",
                  "2.28|https://fr-fr.facebook.com/MultiWin.plan.PageOfficielle/reviews/|escroqueries?  escro  escroc  rifft|Soupcon|21/04/2018|null|null",
                  "2.28|https://foxyrating.com/fr/art_rifft-une-start-up-francaise-qui-se-finance-de-facon-opaque-avec-multiwinplan_333|escro  parties? civiles?  rifft||13/02/2017|null|null",
                  "2.28|https://forum.actufinance.fr/multiwinplan-arnaque-t229415|liquidation  rifft|Soupcon|null|null|null",
                  "2.28|https://curation-simple-crm.blogspot.com/2018/04/rifft-startup-dechue-de-la-frenchtech.html|escroqueries?  escro  rifft|Soupcon|12/04/2018|null|null",
                  "2.28|https://business.lesechos.fr/entrepreneurs/actu/0301444556343-escroquerie-au-financement-le-fondateur-de-rifft-mis-en-examen-319548.php|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|https://bfmbusiness.bfmtv.com/entreprise/le-pdg-de-cette-start-up-francaise-arrete-pour-escroquerie-au-crowdfunding-1397453.html|escroqueries?  escro  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|http://www.webtimemedias.com/article/sophia-le-pdg-de-rifft-soupconne-descroquerie-au-crowfunding-20180315-62337|escroqueries?  escro  rifft|Soupcon|19/03/2018|null|null",
                  "2.28|http://www.varmatin.com/justice/comment-francois-fillon-a-ete-instrumentalise-par-le-startupper-escroc-de-sophia-antipolis-215708|escroqueries?  escro  escroc  rifft|Soupcon|16/03/2018|null|null",
                  "2.28|http://www.politologue.com/actualite/actu.COMMENT-FRANCOIS-FILLON-A-ETE-INSTRUMENTALISE-PAR-LE-STARTUPPER-ESCROC-DE-SOPHIA-ANTIPOLIS-NICE-MATIN.zwzpC|escroqueries?  escro  escroc  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.lefigaro.fr/secteur/high-tech/2018/03/15/32001-20180315ARTFIG00382-crowdfunding-le-pdg-d-une-start-up-mis-en-examen-pour-le-detournement-de-4-millions-d-euros.php|escroqueries?  escro  escroc  detournement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.francesoir.fr/societe-faits-divers/escroquerie-au-crowdfundig-le-patron-une-start-francaise-en-prison|escroqueries?  escro  detournement  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3451.0|escroqueries?  escro  parties? civiles?  rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3397.0|escroqueries?  escro  escroc  detournement  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?topic=3392.0|escroqueries?  escro  filouterie   rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=40|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=20|escroqueries?  escro  escroc  filouterie   detournement  procedure  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forum-get-easy.com/index.php?action=recent;start=10|escroqueries?  escro  escroc  detournement  parties? civiles?  rifft|Soupcon|30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=veracarte|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft|fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft|argent  blanchiment  fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=rifft%20usa|fraude  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexlistenoire.fr/annuaire/search2.php?mots=blanchiment%20argent|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.forexcenter.fr/liste-noire/?courtier=vipbinary.com|argent  blanchiment  rifft||30/08/2018|null|null",
                  "2.28|http://www.businessman.fr/information-veille-economique-actualite-entreprise-high-tech-france/information-veille-economique-actualite-entreprise-high-tech/justice-le-pdg-de-rifft-souponn-descroquerie/584369|escroqueries?  escro  rifft|Soupcon|15/03/2018|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=support%20venture%20limited|argent  blanchiment  escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=copyop.com|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://www.arnaquesauxoptionsbinaires.com/recherche/search.php?mots=184|escroqueries?  escro  rifft||30/05/2019|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/lucas-goreta|detournement  rifft|Soupcon|21/03/2018|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/crowdfunding|detournement  rifft|Soupcon|25/08/2012|null|null",
                  "2.28|http://plus.lefigaro.fr/tag/chaine-de-ponzi|escro  escroc  detournement  rifft|Soupcon|null|null|null",
                  "2.28|http://gender.vivianedebeaufort.fr/la-startup-rifft-soupconnee-davoir-arnaque-ses-investisseurs/|escroqueries?  escro  rifft||16/03/2018|null|null",
                  "2.28|http://entreprises.lefigaro.fr/rifft-06/entreprise-809106917|liquidation  cessation  rifft||06/12/2018|null|null",
                  "2.28|http://entreprises.lefigaro.fr/rifft-06/entreprise-809106917|judiciaire  liquidation  redressement  des paiements  cessation  procedure  rifft||06/12/2018|null|null",
                  "2.28|http://cdn.assets02.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|corruption  escroqueries?  escro  rifft|Soupcon|14/03/2018|null|null"
                ],
                "sourceName": "Bing",
                "totalPageScores": 249.14999999999947
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "29148",
              "labels": [
                "QueryCategory"
              ],
              "properties": {
                "queryCategoryCode": "KYC_OTHER_CRIMES",
                "score": 2.4966666666666666,
                "queryCategoryName_IDX": "othercrimes",
                "queryCategory_key": "othercrimesrifft",
                "entityName": "rifft",
                "queryCategoryName": "OTHER CRIMES",
                "internal_updateDate": 1559236223494,
                "internal_active": "TRUE"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "26488",
              "type": "has_query_category",
              "startNode": "29836",
              "endNode": "29148",
              "properties": {
                "totalSeverityIndexes": 3,
                "initial": false,
                "nbrResultsPerCat": 4,
                "until": "-",
                "positivePages": [
                  "2.28|https://www.reddit.com/r/france/comments/84u5v2/escroquerie_au_financement_le_fondateur_de_rifft/|meurtre  rifft|Soupcon|null|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|viols?  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/index.php/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|viols?  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|http://assets02.nicematin.com/justice/un-ancien-collaborateur-du-startupper-escroc-il-etait-tres-fort-215456|agression  viols?  rifft|Soupcon|15/03/2018|null|null"
                ],
                "sourceName": "Bing",
                "totalPageScores": 1.51
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "30004",
              "labels": [
                "Source"
              ],
              "properties": {
                "sourceName_IDX": "bing",
                "sourceCode": "BING",
                "missionType": "KYC",
                "entityName": "rifft",
                "internal_updateDate": 1559237293924,
                "sourceName": "Bing",
                "internal_active": "TRUE",
                "source_key": "kycrifftbing"
              }
            },
            {
              "id": "29148",
              "labels": [
                "QueryCategory"
              ],
              "properties": {
                "queryCategoryCode": "KYC_OTHER_CRIMES",
                "score": 2.4966666666666666,
                "queryCategoryName_IDX": "othercrimes",
                "queryCategory_key": "othercrimesrifft",
                "entityName": "rifft",
                "queryCategoryName": "OTHER CRIMES",
                "internal_updateDate": 1559236223494,
                "internal_active": "TRUE"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "25318",
              "type": "has_source",
              "startNode": "30004",
              "endNode": "29148",
              "properties": {
                "initial": false,
                "nbrResultsPerCat": 4,
                "until": "-",
                "positivePages": [
                  "2.28|https://www.reddit.com/r/france/comments/84u5v2/escroquerie_au_financement_le_fondateur_de_rifft/|meurtre  rifft|Soupcon|null|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|viols?  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/index.php/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|viols?  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|http://assets02.nicematin.com/justice/un-ancien-collaborateur-du-startupper-escroc-il-etait-tres-fort-215456|agression  viols?  rifft|Soupcon|15/03/2018|null|null"
                ],
                "sourceName": "Bing"
              }
            },
            {
              "id": "26488",
              "type": "has_query_category",
              "startNode": "29836",
              "endNode": "29148",
              "properties": {
                "totalSeverityIndexes": 3,
                "initial": false,
                "nbrResultsPerCat": 4,
                "until": "-",
                "positivePages": [
                  "2.28|https://www.reddit.com/r/france/comments/84u5v2/escroquerie_au_financement_le_fondateur_de_rifft/|meurtre  rifft|Soupcon|null|null|null",
                  "2.28|https://www.nicematin.com/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|viols?  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|https://www.nicematin.com/index.php/justice/une-start-up-de-sophia-antipolis-aurait-escroque-des-milliers-de-donateurs-215184|viols?  rifft|Soupcon|14/03/2018|null|null",
                  "2.28|http://assets02.nicematin.com/justice/un-ancien-collaborateur-du-startupper-escroc-il-etait-tres-fort-215456|agression  viols?  rifft|Soupcon|15/03/2018|null|null"
                ],
                "sourceName": "Bing",
                "totalPageScores": 1.51
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            },
            {
              "id": "29005",
              "labels": [
                "QueryCategory"
              ],
              "properties": {
                "queryCategoryCode": "KYC_TERRORISM",
                "score": 2.4966666666666666,
                "queryCategoryName_IDX": "terrorism",
                "queryCategory_key": "terrorismrifft",
                "entityName": "rifft",
                "queryCategoryName": "TERRORISM",
                "internal_updateDate": 1558002328350,
                "internal_active": "TRUE"
              }
            }
          ],
          "relationships": [
            {
              "id": "26746",
              "type": "has_query_category",
              "startNode": "29836",
              "endNode": "29005",
              "properties": {
                "totalSeverityIndexes": 3,
                "initial": false,
                "nbrResultsPerCat": 1,
                "until": "-",
                "positivePages": [
                  "1.51|https://docplayer.org/39644589-Die-schweizer-museumszeitschrift-la-revue-suisse-des-musees-la-rivista-svizzera-dei-musei.html|taliban  rifft||null|null|null"
                ],
                "sourceName": "Bing",
                "totalPageScores": 1.51
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "30004",
              "labels": [
                "Source"
              ],
              "properties": {
                "sourceName_IDX": "bing",
                "sourceCode": "BING",
                "missionType": "KYC",
                "entityName": "rifft",
                "internal_updateDate": 1559237293924,
                "sourceName": "Bing",
                "internal_active": "TRUE",
                "source_key": "kycrifftbing"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            },
            {
              "id": "29005",
              "labels": [
                "QueryCategory"
              ],
              "properties": {
                "queryCategoryCode": "KYC_TERRORISM",
                "score": 2.4966666666666666,
                "queryCategoryName_IDX": "terrorism",
                "queryCategory_key": "terrorismrifft",
                "entityName": "rifft",
                "queryCategoryName": "TERRORISM",
                "internal_updateDate": 1558002328350,
                "internal_active": "TRUE"
              }
            }
          ],
          "relationships": [
            {
              "id": "26583",
              "type": "has_source",
              "startNode": "30004",
              "endNode": "29005",
              "properties": {
                "initial": false,
                "nbrResultsPerCat": 1,
                "until": "-",
                "positivePages": [
                  "1.51|https://docplayer.org/39644589-Die-schweizer-museumszeitschrift-la-revue-suisse-des-musees-la-rivista-svizzera-dei-musei.html|taliban  rifft||null|null|null"
                ],
                "sourceName": "Bing"
              }
            },
            {
              "id": "26746",
              "type": "has_query_category",
              "startNode": "29836",
              "endNode": "29005",
              "properties": {
                "totalSeverityIndexes": 3,
                "initial": false,
                "nbrResultsPerCat": 1,
                "until": "-",
                "positivePages": [
                  "1.51|https://docplayer.org/39644589-Die-schweizer-museumszeitschrift-la-revue-suisse-des-musees-la-rivista-svizzera-dei-musei.html|taliban  rifft||null|null|null"
                ],
                "sourceName": "Bing",
                "totalPageScores": 1.51
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "30004",
              "labels": [
                "Source"
              ],
              "properties": {
                "sourceName_IDX": "bing",
                "sourceCode": "BING",
                "missionType": "KYC",
                "entityName": "rifft",
                "internal_updateDate": 1559237293924,
                "sourceName": "Bing",
                "internal_active": "TRUE",
                "source_key": "kycrifftbing"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "26487",
              "type": "found_in",
              "startNode": "30004",
              "endNode": "29836",
              "properties": {
                "initial": false,
                "until": "-",
                "internal_identifier": "Company_29836_rifft_FR_null"
              }
            }
          ]
        }
      },
      {
        "graph": {
          "nodes": [
            {
              "id": "28584",
              "labels": [
                "Activity"
              ],
              "properties": {
                "activity_key": "rifft",
                "companyName": "rifft",
                "activityDescription": "Recherche-développement : autres sciences physiques et naturelles",
                "internal_active": "TRUE",
                "internal_updateDate": 1559232080584,
                "activityType": "APE",
                "activityType_IDX": "ape",
                "activityDescription_IDX": "recherchedeveloppement:autressciencesphysiquesetnaturelles"
              }
            },
            {
              "id": "29836",
              "labels": [
                "Company"
              ],
              "properties": {
                "score": 2.496666666666668,
                "country": "France",
                "missionType": "KYC",
                "internal_status": true,
                "countryCode": "FR",
                "companyName": "rifft",
                "company_key": "kycrifftfr",
                "internal_active": "TRUE",
                "internal_updateDate": 1559237293845,
                "creationDate": "30/05/2019",
                "status": "Inactive",
                "companyName_IDX": "rifft"
              }
            }
          ],
          "relationships": [
            {
              "id": "26324",
              "type": "has_activity",
              "startNode": "29836",
              "endNode": "28584",
              "properties": {
                "initial": false,
                "until": "*"
              }
            }
          ]
        }
      }
    ]
  },
  {
    "columns": [
      "ID(start)"
    ],
    "data": [
      {
        "row": [
          29836
        ],
        "meta": [
          null
        ]
      }
    ]
  }
]
