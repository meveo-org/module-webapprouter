export const profiles = [
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215941,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "Starting Price",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870301,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "Aalborg",
    platform: "Facebook",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-17T04:00:11.674Z",
    matching: "level 2",
    status: "DETECT",
    lso3: "2020-02-17T04:00:11.674Z",
    icon: "facebook.png",
    relevancy: "Free Demo",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429031,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "Szczecin",
    platform: "Google",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-16T04:00:11.674Z",
    matching: "level 3",
    status: "BOOKMARK",
    lso3: "2020-02-16T04:00:11.674Z",
    icon: "google.png",
    relevancy: "Platform",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819761,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "Techmakers",
    platform: "Instagram",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-15T04:00:11.674Z",
    matching: "level 4",
    status: "DETECT",
    lso3: "2020-02-15T04:00:11.674Z",
    icon: "instagram.png",
    relevancy: "Training",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031631,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "Hamburg",
    platform: "Linkedin",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-14T04:00:11.674Z",
    matching: "level 5",
    status: "DETECT",
    lso3: "2020-02-14T04:00:11.674Z",
    icon: "linkedin.png",
    relevancy: "Support",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672421,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "Hamburg",
    platform: "Twitter",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-13T04:00:11.674Z",
    matching: "level 2",
    status: "DETECT",
    lso3: "2020-02-13T04:00:11.674Z",
    icon: "twitter.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014751,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "Cloud",
    platform: "Whatsapp",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-01-18T04:00:11.674Z",
    lso3: "2020-01-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    icon: "whatsapp.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868011,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Youtube",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2019-02-18T04:00:11.674Z",
    matching: "level 4",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "youtube.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293721,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Pinterest",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "pinterest.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499551,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Skype",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "skype.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245581,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Viber",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "viber.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865401,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056471,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060431,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971461,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770171,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215942,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870302,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429032,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819762,
    url: "womentechmakershamburg",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031632,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672422,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014752,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868012,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293722,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499552,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245582,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865402,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056472,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060432,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971462,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770172,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215943,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870303,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429033,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819763,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031633,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672423,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014753,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868013,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293723,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499553,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245583,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865403,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056473,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060433,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971463,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770173,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215944,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870304,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429034,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819764,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031634,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672424,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014754,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868014,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293724,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499554,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245584,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865404,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056474,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060434,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971464,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770174,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215945,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870305,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429035,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819765,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031635,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672425,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014755,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868015,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293725,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499555,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245585,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865405,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056475,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060435,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971465,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770175,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215946,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870306,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429036,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819766,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031636,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672426,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014756,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868016,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293726,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499556,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245586,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865406,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056476,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060436,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971466,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770176,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215947,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870307,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429037,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819767,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031637,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672427,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014757,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868017,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293727,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499557,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245587,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865407,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056477,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060437,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971467,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770177,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Copenhagen",
    country: "Denmark",
    id: 278215948,
    url: "Google-Cloud-Developer-Community-Copenhagen",
    username: "GDG Cloud Copenhagen",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 12.569999694824219,
    lat: 55.68000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Aalborg",
    country: "Denmark",
    id: 226870308,
    url: "GDG-Aalborg",
    username: "Google Developer Group Aalborg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.930000305175781,
    lat: 57.029998779296875,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Szczecin",
    country: "Poland",
    id: 293429038,
    url: "GDGSzczecin",
    username: "GDG Szczecin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 14.529999732971191,
    lat: 53.43000030517578,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192819768,
    url: "womentechmakershamburg",
    username: "Women Techmakers",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 192031638,
    url: "GDG-Hamburg-Android",
    username: "GDG Hamburg Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hamburg",
    country: "Germany",
    id: 125672428,
    url: "Google-Developer-Group-Hamburg",
    username: "Google Developer Group Hamburg",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10,
    lat: 53.54999923706055,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 245014758,
    url: "Cloud-GDG-Berlin",
    username: "GDG Berlin Cloud",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 229868018,
    url: "Women-Techmakers-Berlin",
    username: "Women Techmakers Berlin",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Berlin",
    country: "Germany",
    id: 180293728,
    url: "berlindroid",
    username: "GDG Berlin Android",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 13.380000114440918,
    lat: 52.52000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Kristiansand",
    country: "Norway",
    id: 275499558,
    url: "Google-Developer-Group-Sorlandet-GDG",
    username: "Google Developer Group Sørlandet (GDG)",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 7.989999771118164,
    lat: 58.150001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Braunschweig",
    country: "Germany",
    id: 260245588,
    url: "GDG-Braunschweig",
    username: "GDG Braunschweig",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.510000228881836,
    lat: 52.27000045776367,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hannover",
    country: "Germany",
    id: 293865408,
    url: "Hannover-Mobile-Development-Meetup",
    username: "GDG Hannover for Mobile Development",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.729999542236328,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Hildesheim",
    country: "Germany",
    id: 297056478,
    url: "hildesheimGDG",
    username: "GDG Hildesheim",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 9.949999809265137,
    lat: 52.15999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Bydgoszcz",
    country: "Poland",
    id: 288060438,
    url: "gdg-bydgoscz",
    username: "Google Cloud Developer Community Bydgoszcz",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 18.010000228881836,
    lat: 53.119998931884766,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Poznan",
    country: "Poland",
    id: 292971468,
    url: "GDG-Poznań",
    username: "GDG Poznań",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 16.899999618530273,
    lat: 52.400001525878906,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  },
  {
    city: "Oslo",
    country: "Norway",
    id: 185770178,
    url: "GDG-Cloud-Norway",
    username: "GDG Cloud Oslo, Norway",
    name: "GDG Cloud Copenhagen",
    platform: "Amazon",
    lon: 10.75,
    lat: 59.90999984741211,
    criteria: "2020-02-18T04:00:11.674Z",
    matching: "level 1",
    status: "VALIDATE",
    lso3: "2019-02-18T04:00:11.674Z",
    icon: "amazon.png",
    relevancy: "LitElement",
    avatar: {
      href: "https://images.unsplash.com/photo-1569413157219-3f3010178e4a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80",
      alt: "avatar",
      title: "avatar"
    },
    screenshot: {
      href: "https://images.unsplash.com/photo-1572739275114-ec3764ba1477?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
      alt: "screenshot",
      title: "screenshot"
    }
  }
];