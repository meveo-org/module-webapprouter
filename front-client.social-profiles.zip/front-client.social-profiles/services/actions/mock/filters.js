export const filters = [
  {
    id: "platform",
    name: "Platform",
    label: "Platform",
    type: "SEARCH"
  },
  {
    id: "id",
    name: "Id",
    label: "Alias + ID",
    type: "SEARCH"
  },
  {
    id: "username",
    name: "Username",
    label: "Username",
    type: "SEARCH"
  },
  {
    id: "criteria",
    name: "Number of criteria linked",
    label: "Criteria",
    type: "SEARCH"
  },
  {
    id: "matching",
    name: "Matching",
    label: "Matching",
    type: "SEARCH"
  },
  {
    id: "lso3",
    name: "Lso3",
    label: "LSO3",
    type: "SEARCH"
  },
  {
    id: "status",
    name: "Status",
    label: "Status",
    type: "DROPDOWN"
  }
];
