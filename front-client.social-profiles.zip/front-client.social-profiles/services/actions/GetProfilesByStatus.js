import { profileColumns } from "./mock/profile-columns.js";
import { profiles } from "./mock/profiles.js";

const FILTERS = {
  "id": "id",
  "platform": "platform",
  "username": "username",
  "criteria": "criteria",
  "matching": "matching",
  "lso3": "lso3",
  "status": "status"
};

const STATUSES = {
  "detected": "DETECT",
  "validated": "VALIDATE",
  "bookmarked": "BOOKMARK"
};

const findId = (list) => {
  return list.map(item => item.slice(0, item.indexOf("-")));
};

const filterListById = (list, id) => {
  if (id === FILTERS.id) {
    return (list || []).filter(filter => filter.id === id).flatMap(filter => findId(filter.data));
  }
  return (list || []).filter(filter => filter.id === id).flatMap(filter => filter.data);
};

const checkListByValue = (list, value, property) => {
  if (!!property && ["criteria", "lso3"].includes(property)) {
    return list.length > 0 ? list.includes((new Date(value)).toLocaleDateString("en-US"))
      : (new Date(value)).toLocaleDateString("en-US")
  }
  return list.length > 0 ? list.includes(value && value.toString()) : value;
};

const EVENT = {
  SUCCESS: "GetProfiles-SUCCESS",
  ERROR: "GetProfiles-ERROR"
};

export const registerEventListeners = (
  component,
  successCallback,
  errorCallback
) => {
  if (successCallback) {
    component.addEventListener(EVENT.SUCCESS, successCallback);
  }
  if (errorCallback) {
    component.addEventListener(EVENT.ERROR, errorCallback);
  }
};

export const getRequestSchema = async (parameters, config) => null;

export const getResponseSchema = async (parameters, config) => {
  return {
    name: "GetProfilesResponse",
    description: "Schema definition for a profiles result list table columns",
    properties: profileColumns
  };
};

export const executeApiCall = async (
  component,
  params,
  successCallback,
  errorCallback
) => {
  registerEventListeners(component, successCallback, errorCallback);
  const parameters = params || {};
  const { status, offset, limit, filters } = parameters;
  const profilesFilteredByStatus = profiles.filter(profile => profile.status === STATUSES[status]);

  const ids = filterListById(filters, FILTERS.id);
  const platforms = filterListById(filters, FILTERS.platform);
  const usernames = filterListById(filters, FILTERS.username);
  const criterias = filterListById(filters, FILTERS.criteria);
  const matchings = filterListById(filters, FILTERS.matching);
  const lso3s = filterListById(filters, FILTERS.lso3);
  const statuses = filterListById(filters, FILTERS.status);

  const filteredProfiles = filters
    ? profilesFilteredByStatus.filter(profile =>
      checkListByValue(ids, profile[FILTERS.id]) &&
      checkListByValue(platforms, profile[FILTERS.platform]) &&
      checkListByValue(usernames, profile[FILTERS.username]) &&
      checkListByValue(statuses, profile[FILTERS.status]) &&
      checkListByValue(matchings, profile[FILTERS.matching]) &&
      checkListByValue(criterias, profile[FILTERS.criteria], FILTERS.criteria) &&
      checkListByValue(lso3s, profile[FILTERS.lso3], FILTERS.lso3)
    )
    : profilesFilteredByStatus;

  try {
    const result = {
      count: filteredProfiles.length,
      results: filteredProfiles.slice(offset, offset + limit).sort((previous, next) => (previous.matching < next.matching) ? 1 : -1)
    };

    component.dispatchEvent(
      new CustomEvent(EVENT.SUCCESS, { detail: { result }, bubbles: true })
    );
  } catch (error) {
    component.dispatchEvent(
      new CustomEvent(EVENT.ERROR, { detail: { error }, bubbles: true })
    );
  }
};
