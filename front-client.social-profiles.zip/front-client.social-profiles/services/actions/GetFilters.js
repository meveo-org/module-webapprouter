import { filters } from "./mock/filters.js";
import { profiles } from "./mock/profiles.js";

const EVENT = {
  SUCCESS: "GetFilters-SUCCESS",
  ERROR: "GetFilters-ERROR"
};

export const registerEventListeners = (
  component,
  successCallback,
  errorCallback
) => {
  if (successCallback) {
    component.addEventListener(EVENT.SUCCESS, successCallback);
  }
  if (errorCallback) {
    component.addEventListener(EVENT.ERROR, errorCallback);
  }
};

export const getRequestSchema = async (parameters, config) => null;

export const getResponseSchema = async (parameters, config) => null;

export const executeApiCall = async (
  component,
  params,
  successCallback,
  errorCallback
) => {
  registerEventListeners(component, successCallback, errorCallback);
  const parameters = params || {};

  try {
    const result = filters.map(filter => ({
      ...filter,
      data: filter.id === "status" ?
        ["VALIDATE", "DETECT", "BOOKMARK"] :
        [...new Set(profiles.map(profile => {
          if (["criteria", "lso3"].includes(filter.id)) {
            return (new Date(profile[filter.id])).toLocaleDateString("en-US");
          }
          if (filter.id === "id") {
            return `${profile[filter.id]}-${profile.name}`;
          } else {
            return profile[filter.id];
          }
        }))],
    }));
    component.dispatchEvent(
      new CustomEvent(EVENT.SUCCESS, { detail: { result }, bubbles: true })
    );
  } catch (error) {
    component.dispatchEvent(
      new CustomEvent(EVENT.ERROR, { detail: { error }, bubbles: true })
    );
  }
};
