import { profiles } from "./mock/profiles.js";

const EVENT = {
  SUCCESS: "GetMapProfiles-SUCCESS",
  ERROR: "GetMapProfiles-ERROR"
};

export const registerEventListeners = (
  component,
  successCallback,
  errorCallback
) => {
  if (successCallback) {
    component.addEventListener(EVENT.SUCCESS, successCallback);
  }
  if (errorCallback) {
    component.addEventListener(EVENT.ERROR, errorCallback);
  }
};

export const getRequestSchema = async (parameters, config) => null;

export const getResponseSchema = async (parameters, config) => null;

export const executeApiCall = async (
  component,
  params,
  successCallback,
  errorCallback
) => {
  registerEventListeners(component, successCallback, errorCallback);
  const parameters = params || {};

  try {
    const result = profiles;
    component.dispatchEvent(
      new CustomEvent(EVENT.SUCCESS, { detail: { result }, bubbles: true })
    );
  } catch (error) {
    component.dispatchEvent(
      new CustomEvent(EVENT.ERROR, { detail: { error }, bubbles: true })
    );
  }
};
