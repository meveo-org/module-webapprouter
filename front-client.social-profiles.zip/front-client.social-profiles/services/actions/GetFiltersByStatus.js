import { filters } from "./mock/filters.js";
import { profiles } from "./mock/profiles.js";

const EVENT = {
  SUCCESS: "GetFilters-SUCCESS",
  ERROR: "GetFilters-ERROR"
};

const STATUSES = {
  "detected": "DETECT",
  "validated": "VALIDATE",
  "bookmarked": "BOOKMARK"
};

export const registerEventListeners = (
  component,
  successCallback,
  errorCallback
) => {
  if (successCallback) {
    component.addEventListener(EVENT.SUCCESS, successCallback);
  }
  if (errorCallback) {
    component.addEventListener(EVENT.ERROR, errorCallback);
  }
};

export const getRequestSchema = async (parameters, config) => null;

export const getResponseSchema = async (parameters, config) => null;

export const executeApiCall = async (
  component,
  params,
  successCallback,
  errorCallback
) => {
  registerEventListeners(component, successCallback, errorCallback);
  const parameters = params || {};
  const { status } = parameters;
  const profilesFilteredByStatus = profiles.filter(profile => profile.status === STATUSES[status]);

  try {
    const result = filters.filter(filter => filter.id !== "status").map(filter => ({
      ...filter,
      data: [...new Set(profilesFilteredByStatus.map(profile => {
        if (["criteria", "lso3"].includes(filter.id)) {
          return (new Date(profile[filter.id])).toLocaleDateString("en-US");
        }
        if (filter.id === "id") {
          return `${profile[filter.id]}-${profile.name}`;
        } else {
          return profile[filter.id];
        }
      }))],
    }));
    component.dispatchEvent(
      new CustomEvent(EVENT.SUCCESS, { detail: { result }, bubbles: true })
    );
  } catch (error) {
    component.dispatchEvent(
      new CustomEvent(EVENT.ERROR, { detail: { error }, bubbles: true })
    );
  }
};
