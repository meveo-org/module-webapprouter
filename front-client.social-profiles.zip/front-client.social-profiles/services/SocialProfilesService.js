import BaseService from './BaseService';
import SocialProfiles from '../model/SocialProfiles';

export default class SocialProfilesService extends BaseService {

	constructor() {
		super();
	}

	launch_investigation(data) {
		let entity = new SocialProfiles(data);
		return new Promise((resolve, reject) => {

			super.socialProfiles_investigation(entity, (code, response) => {
				(code == 'success') ? resolve(response) : reject(response);
			});
		});
	}

}
