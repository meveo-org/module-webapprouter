export declare function ensureAnchorHistory(): void;
