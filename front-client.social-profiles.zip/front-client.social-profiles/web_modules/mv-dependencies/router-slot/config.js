export const CATCH_ALL_WILDCARD = "**";
export const TRAVERSE_FLAG = "\\.\\.\\/";
export const PARAM_IDENTIFIER = /:([^\\/]+)/g;
export const ROUTER_SLOT_TAG_NAME = "router-slot";
export const GLOBAL_ROUTER_EVENTS_TARGET = window;
export const HISTORY_PATCH_NATIVE_KEY = `native`;
//# sourceMappingURL=config.js.map