export declare const CATCH_ALL_WILDCARD = "**";
export declare const TRAVERSE_FLAG = "\\.\\.\\/";
export declare const PARAM_IDENTIFIER: RegExp;
export declare const ROUTER_SLOT_TAG_NAME = "router-slot";
export declare const GLOBAL_ROUTER_EVENTS_TARGET: Window & typeof globalThis;
export declare const HISTORY_PATCH_NATIVE_KEY = "native";
