export default class SocialProfiles {
  constructor(datum) {
    this.cetCode = "SocialProfiles";
    this.customFields = {
      "customField": [
        {
          "code": "lastName",
          "stringValue": datum.last_name || null
        },
        {
          "code": "firstName",
          "stringValue": datum.first_name || null
        },
        {
          "code": "secondName",
          "stringValue": datum.second_name || null
        },
        {
          "code": "username",
          "stringValue": datum.username || null
        },
        {
          "code": "phoneNumber",
          "stringValue": datum.phone_number || null
        },
        {
          "code": "emailAddress",
          "stringValue": datum.email_address || null
        },
        {
          "code": "additionalClue",
          "stringValue": datum.additional_clue || null
        },
        {
          "code": "excludedKeyword",
          "stringValue": datum.excluded_keyword || null
        }
      ]
    };

  }

  get meveoJson(){
    return JSON.stringify(this);
  }
}
