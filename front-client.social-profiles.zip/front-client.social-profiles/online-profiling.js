import { LitElement, html, css } from "lit-element";
import "mv-router";

class OnlineProfiling extends LitElement {
  static get properties() {
    return {};
  }

  static get styles() {
    return css``;
  }

  constructor() {
    super();
  }

  render() {
    return html`
      <mv-router>
        <!-- component paths are relative to /web_modules/mv-router -->
        <mv-router
          default
          route
          path="form"
          component="../../pages/investigation-form/investigation-form.js"
        ></mv-router>
        <mv-router
          route
          path="results/:view/:status"          
          component="../../pages/results-visualization/dashboard/listing-details.js"
          name="online-profiling-details"
          storage-modes="local"
        ></mv-router>
        <mv-router
          route
          path="results/:view"          
          component="../../pages/results-visualization/results-visualization.js"
          name="online-profiling-results"
          storage-modes="local"
        ></mv-router>
      </mv-router>
    `;
  }
}

customElements.define("online-profiling", OnlineProfiling);
