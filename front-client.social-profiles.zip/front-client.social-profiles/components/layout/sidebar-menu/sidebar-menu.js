import { LitElement, html, css } from "lit-element";
import "mv-menu-panel";
import "mv-linear-icons";

class SidebarMenu extends LitElement {
  static get properties() {
    return {
      mission: { type: Object, attribute: false, reflect: true },
      investigation: { type: Object, attribute: false, reflect: true },
      enabled: { type: Object, attribute: false, reflect: true },
      selected: { type: String },
      sidebar: { type: Boolean },
      collapsed: { type: Boolean },
    };
  }

  static get styles() {
    return css`
      mv-menu-panel {
        font-family: "MuseoSans";
        --font-size-m: 1rem;
        --mv-menu-panel-item-height: 50px;
        --mv-menu-panel-item-padding: 0;
        --mv-menu-panel-dark-background: #3f4753;
        --mv-menu-panel-header-height: 100px;
        --mv-menu-panel-header-dark-background: linear-gradient(
          90deg,
          #dc3545 0%,
          #e45d4e 100%
        );
      }

      .sidebar {
        position: fixed;
        height: calc(100vh - 80px);
        z-index: 99;
        padding: 0;
        box-shadow: 0 1px 30px 1px rgba(0, 0, 0, 0.11);
        background-color: #3f4753;
        --mv-menu-panel-width: 330px;
      }

      .sidebar.collapsed {
        --mv-menu-panel-width: 65px;
        --mv-menu-panel-popout-width: 330px;
      }

      .sidebar-header {
        min-width: 100%;
        height: 100px;
        padding-left: 30px;
        display: grid;
        grid-template-columns: 65px 148px 65px;
        grid-column-gap: 10px;
        align-items: center;
        font-size: 2rem;
      }

      .sidebar-header.collapsed {
        grid-template-columns: 0 0 65px;
      }

      .collapse-button {
        width: 65px;
        height: 100px;
        font-size: 2rem;
        border: none;
        background: transparent;
        color: #ffffff;
        outline: none;
        cursor: pointer;
      }

      .collapse-button:hover {
        background-color: #f45d4e;
      }

      .investigations-count {
        width: 100%;
        font-size: 0.8rem;
        font-weight: 300;
      }

      .sidebar-header.collapsed .mission-code,
      .sidebar-header.collapsed .investigations-count {
        display: none;
      }

      .sidebar-header.collapsed .collapse-button {
        margin-left: -30px;
      }

      .text {
        font-size: 1rem;
        display: grid;
        grid-template-columns: 55px auto;
        grid-column-gap: 10px;
        align-items: center;
        width: 100%;
        height: 50px;
        padding: 0;
      }

      .group.text {
        grid-template-columns: 55px auto 25px;
      }

      .sidebar.collapsed .text {
        grid-template-columns: 55px;
      }

      .text mv-lnr {
        padding-left: 30px;
      }

      .sidebar.collapsed .text mv-lnr {
        padding-left: 25px;
      }

      .new-investigation {
        width: 269px;
        height: 48px;
        margin: 16px 30px;
        border-radius: 5px;
        font-family: "MuseoSans";
        font-size: 16px;
        color: #fff;
        background-color: #a8b7c5;
        box-shadow: 0 2px 4px 1px rgba(93, 94, 97, 0.35);
        text-shadow: 1px 1px 2px rgba(93, 94, 97, 0.5);
        border: 1px solid #a8b7c5;
        outline: none;
        cursor: pointer;
      }
    `;
  }

  constructor() {
    super();
    this.mission = { code: "SP" };
    this.investigation = { count: 0 };
    this.theme = "dark";
    this.collapsed = false;
    this.selected = "";
    this.enabled = { socialProfiles: false };
  }

  render() {
    const { theme, mission, investigation } = this;
    const collapsedClass = this.collapsed ? " collapsed" : "";

    return html`
      <div class="sidebar${collapsedClass}">
        <mv-menu-panel menu show-header .theme="${theme}">
          <mv-menu-panel label>
            <div class="${`sidebar-header${collapsedClass}`}">
              <div class="mission-code">${mission.code}</div>
              <div class="investigations-count">
                Investigations (${investigation.count || 0})
              </div>
              <button class="collapse-button" @click="${this.toggleSidebar}">
                ${this.collapsed
                  ? html` <div><mv-fa icon="chevron-right"></mv-fa></div>`
                  : html` <div><mv-fa icon="chevron-left"></mv-fa></div> `}
              </button>
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "favorites" }}"
            ?selected="${this.selected === "favorites"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="star"></mv-lnr>
              ${this.collapsed ? html`` : html`<span>Favorites</span>`}
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            custom
            group
            .value="${{ selected: "socialProfiles" }}"
            ?selected="${this.selected === "socialProfiles"}"
            ?open="${this.enabled.socialProfiles}"
            ?popout="${this.collapsed}"
            @select-group="${this.toggleGroup}"
          >
            <mv-menu-panel label>
              <div class="group text">
                <mv-lnr icon="user"></mv-lnr>
                ${this.collapsed
                  ? html``
                  : html`
                      <span>Social Profiling</span>
                      ${this.enabled.socialProfiles
                        ? html`<mv-fa icon="chevron-down"></mv-fa>`
                        : html`<mv-fa icon="chevron-right"></mv-fa>`}
                    `}
              </div>
            </mv-menu-panel>
            <mv-menu-panel item>
              <button class="new-investigation">New investigation</button>
            </mv-menu-panel>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "topic-monitoring" }}"
            ?selected="${this.selected === "topic-monitoring"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="users"></mv-lnr>
              ${this.collapsed ? html`` : html`<span>Topic Monitoring</span>`}
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "website-investigations" }}"
            ?selected="${this.selected === "website-investigations"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="earth"></mv-lnr>
              ${this.collapsed
                ? html``
                : html`<span>Website Investigations</span>`}
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "archived-investigations" }}"
            ?selected="${this.selected === "archived-investigations"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="earth"></mv-lnr>
              ${this.collapsed
                ? html``
                : html`<span>Website Investigations</span>`}
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "monitoring" }}"
            ?selected="${this.selected === "monitoring"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="chart-bars"></mv-lnr>
              ${this.collapsed ? html`` : html`<span>Monitoring</span>`}
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "reports" }}"
            ?selected="${this.selected === "reports"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="file-empty"></mv-lnr>
              ${this.collapsed ? html`` : html`<span>Reports</span>`}
            </div>
          </mv-menu-panel>

          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "team" }}"
            ?selected="${this.selected === "team"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="bubble"></mv-lnr>
              ${this.collapsed ? html`` : html`<span>Team</span>`}
            </div>
          </mv-menu-panel>
          <mv-menu-panel
            item
            disabled
            .value="${{ selected: "settings" }}"
            ?selected="${this.selected === "settings"}"
            @select-item="${this.selectItem}"
          >
            <div class="text">
              <mv-lnr icon="cog"></mv-lnr>
              ${this.collapsed ? html`` : html`<span>Settings</span>`}
            </div>
          </mv-menu-panel>
        </mv-menu-panel>
      </div>
    `;
  }

  selectItem = (event) => {
    const { detail } = event;
    const {
      value: { selected },
    } = detail;
    this.selected = selected;
    this.dispatchEvent(
      new CustomEvent("select-item", {
        detail: { selected: this.selected },
      })
    );
  };

  toggleSidebar = () => {
    this.enabled = {};
    this.dispatchEvent(new CustomEvent("toggle-sidebar"));
  };

  toggleGroup = (event) => {
    const { detail } = event;
    const {
      value: { selected },
    } = detail;
    this.enabled = { ...this.enabled, [selected]: !this.enabled[selected] };
    this.selected = this.enabled ? selected : "";
  };
}

customElements.define("sidebar-menu", SidebarMenu);
