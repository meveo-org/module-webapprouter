import { LitElement, html, css } from "lit-element";
import "mv-linear-icons";
import "mv-dropdown";
import "mv-header";
import "mv-menu";
import "mv-font-awesome";

class TopbarMenu extends LitElement {
  static get properties() {
    return {
      language: { type: String, attribute: true },
    };
  }

  static get styles() {
    return css`
      :host {
        --mv-header-height: 80px;
        --mv-header-dark-background: var(--dark-4-background);
        --mv-header-item-padding: 0;
        --mv-header-margin-left: -10px;
        --mv-dropdown-level-height: 80px;
        --mv-level-dropdown-box-shadow: none;
        --mv-dropdown-sublevel-position-top: 80px;
      }

      html,
      body {
        margin: 0;
        padding: 0;
        border: 0;
        font-size: 100%;
        font: inherit;
        vertical-align: baseline;
      }

      .topbar {
        width: 100%;
        position: fixed;
        top: 0;
        height: 80px;
        z-index: 101;
        box-shadow: 0 2px 15px 0 rgba(0, 0, 0, 0.05);
        left: 0;
        background-color: var(--dark-4-background);
      }

      .topbar-wrapper {
        position: relative;
        display: flex;
        height: 80px;
      }

      .topbar-left {
        position: absolute;
        left: 0;
        display: flex;
        height: 100%;
        width: 50%;
      }

      .topbar-left-container {
        text-align: center;
        display: flex;
        align-items: center;
        height: 80px;
      }

      .topbar-right {
        position: absolute;
        right: 0;
        display: flex;
        height: 100%;
        margin-right: 15px;
      }

      button {
        outline: none;
      }

      .menu-icon {
        color: #b0b3b6 !important;
        width: 123px;
        display: flex;
        font-size: 2.1rem;
        align-items: center;
        justify-content: center;
      }
      .menu-icon:hover {
        color: #ffffff !important;
      }

      .logo-container {
        display: inline-block;
        text-align: center;
        margin: auto;
        width: 175px;
        height: 50px;
        margin-left: 20px;
      }

      .topbar-left-menu {
        height: 80px;
        width: 113px;
        padding: 0;
        cursor: pointer;
        position: relative;
        display: flex;
        border: none;
        transition: all 0.3s;
        background-color: var(--dark-4-background);
      }

      .topbar-left-menu:hover {
        background-color: #373e48;
      }

      .topbar-avatar {
        height: 100%;
        width: 265px;
        display: flex;
        cursor: pointer;
        position: relative;
        border-radius: 0;
        border: none;
        transition: all 0.3s;
        box-shadow: none;
        padding: 0 20px;
        background-color: transparent;
        align-items: center;
      }

      .UserAvatar {
        display: inline-block;
        color: #fff;
      }

      .UserAvatar--inner {
        box-sizing: border-box;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .topbar-avatar-name {
        font-size: 1rem;
        line-height: 18px;
        font-weight: 400;
        display: block;
        margin-left: 10px;
        color: #ffffff !important;
        font-family: "Comfortaa-Bold", sans-serif;
        padding-left: 10px;
      }

      .topbar-icon {
        height: 18px;
        margin: auto 0;
        fill: #b1c3c8;
      }

      .topbar-language {
        min-width: 75px;
        display: flex;
        align-items: center;
        justify-content: center;
        --mv-dropdown-trigger-height: 80px;
        --mv-dropdown-min-width: 75px;
        --mv-dropdown-max-width: 75px;
        --mv-dropdown-content-max-height: 140px;
      }

      .topbar-language > button {
        padding: 0 4px;
        width: 100%;
      }

      .topbar-btn {
        font-size: 1.3rem;
        color: #646777;
        height: 100%;
        position: relative;
        display: flex;
        border: none;
        background: transparent !important;
        transition: all 0.3s;
        align-items: center;
        justify-content: center;
      }

      .topbar-language-btn-title:not(:last-child) {
        margin-right: 5px;
      }

      .topbar-language-btn-title {
        display: flex;
        font-size: 0.8rem;
        align-items: center;
        margin: auto 0;
        color: #fff;
      }

      .topbar-language-btn-title img {
        height: 11px;
        width: 16px;
        margin-right: 4px;
      }

      .topbar-btn .down-btn {
        margin: auto;
        height: 18px;
        width: 18px;
        fill: #b1c3c8;
        font-size: 12px;
        color: #b1c3c8;
        display: flex;
        align-items: center;
      }

      svg:not(:root) {
        overflow: hidden;
      }

      ul.language-menu {
        padding: 0;
        margin: 10px 0;
      }

      .language-menu li {
        font-size: var(--font-size-s);
        list-style: none;
        padding: 6px 17px;
      }

      .language-menu li:hover {
        color: #ffffff;
        background-color: #2a3138;
      }

      ul.settings-menu {
        padding: 0;
        margin: 10px 0;
      }

      .settings-menu li {
        font-size: var(--font-size-s);
        list-style: none;
        padding: 6px 17px;
      }

      .settings-menu li:hover {
        color: #ffffff;
        background-color: #2a3138;
      }

      .topbar-profile {
        display: flex;
        align-items: center;
        justify-content: center;
        --mv-dropdown-trigger-height: 65px;
      }

      .avatar {
        line-height: 48px;
        text-align: center;
        border-radius: 100%;
        max-width: 48px;
        width: 48px;
        max-height: 48px;
        height: 48px;
        background-color: rgb(52, 152, 219);
      }

      .dropdown {
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .title {
        padding: 10px;
      }

      .topbar-language {
        --mv-dropdown-level-width: 90px;
        --mv-dropdown-sublevel-width: 80px;
      }
    `;
  }

  constructor() {
    super();
    this.missionbar = true;
    this.theme = "dark";
  }

  render() {
    return html`
      <div class="topbar">
        <mv-header>
          <mv-header item>
            <button class="topbar-left-menu menu-icon" id="menu" @click="${
              this.toggleMissionBar
            }">
              <mv-lnr icon="menu"></mv-lnr>
          	</button>
          </mv-header>
          <mv-header item>
            <div class="logo-container">
          		<img alt="logo" src="../../../img/webdrone-logo-white.svg">
          	</div>
          </mv-header>
          <mv-header item position="right">
            <div class="topbar-language">
              <mv-menu type="dropdown" .theme="${this.theme}">
                <mv-menu text="">
                  <span slot="title">
                    <button class="topbar-btn">
                      <span class="topbar-language-btn-title">
                          ${
                            this.language === "en"
                              ? html`<img
                                    src="../../../img/language/gb.png"
                                    alt="en"
                                  /><span>EN</span>`
                              : html`<img
                                    src="../../../img/language/fr.png"
                                    alt="fr"
                                  /><span>FR</span>`
                          }
                				</span>
                        <span class="down-btn">
                          <mv-lnr icon="chevron-down"></mv-lnr>
                        </span>
                			</span>
                  </button>
                  </span>
                  <mv-menu
                    text="EN"
                    @submenu-clicked="${this.updateLanguage("en")}"
                  ></mv-menu>
                  <mv-menu
                    text="FR"
                    @submenu-clicked="${this.updateLanguage("fr")}"
                  ></mv-menu>
                </mv-menu>
              </mv-menu>
            </div>
          </mv-header>
          <mv-header item position="right">
            <div class="topbar-profile">
              <mv-menu type="dropdown" .theme="${this.theme}">
                <mv-menu text="">
                  <span slot="title">
                    <div class="dropdown">
                      <div class="avatar">ma</div>
                      <div class="title">meveo.admin</div>
                      <mv-fa icon="caret-down"></mv-fa>
                    </div>
                  </span>
                  <mv-menu text="Profile Setttings"></mv-menu>
                  <mv-menu text="Log Out"></mv-menu>
                </mv-menu>
              </mv-menu>
            </div>
          </mv-header>
        </mv-header>
      </div>
    `;
  }

  toggleMissionBar = () => {
    this.dispatchEvent(new CustomEvent("toggle-missionbar"));
  };

  updateLanguage = (language) => () => {
    this.language = language;
    this.dispatchEvent(
      new CustomEvent("update-language", {
        detail: { language: this.language },
      })
    );
  };
}

customElements.define("topbar-menu", TopbarMenu);
