import { LitElement, html, css } from "lit-element";
import * as GetMissionsAPI from "GetMissionsAPI";
import { COLORS, sumChars, initials } from "../../utils/index.js";

class MissionbarMenu extends LitElement {
  static get properties() {
    return {
      missions: { type: Array, attribute: false },
      collapsed: { type: Boolean },
    };
  }

  static get styles() {
    return css`
      .missionbar {
        position: fixed;
        height: calc(100vh - 80px);
        width: 113px;
        z-index: 100;
        background: linear-gradient(to top, #1a1e23, #3f4753) !important;
        margin: 0;
        padding: 0;
        color: #646777;
      }

      .missionbar .missions-header {
        padding: 38px 0 38px 10px;
        text-transform: uppercase;
        color: #fff;
        font-size: 1rem;
        font-weight: 300;
        font-family: var(--missionbar-font, "MuseoSans");
      }

      .missionbar .missions-count {
        margin-left: 5px;
        color: #00d8ff;
      }

      .scrollbar {
        max-height: 300px;
        max-width: calc(100% - 5px);
        overflow-y: auto;
        margin: 15px 0;
        scrollbar-color: #5a6473 #788394;
        scrollbar-width: thin;
      }

      .scrollbar.nav-list {
        max-width: 100%;
        width: 100%;
        max-height: calc(100vh - 195px);
        height: calc(100vh - 195px);
        margin: 0;
      }

      .missionbar .mission-icon-container:first-child {
        margin-top: 0;
      }

      .missionbar .mission-icon-container--active {
        font-weight: 500;
      }

      .missionbar .mission-name {
        font-size: 2.1rem;
        font-family: "MuseoSans", sans-serif;
        color: #fff;
        text-shadow: -1px 1px 1px #e4a71b;
      }

      .missionbar .mission-icon-container {
        font-weight: 100;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        margin-top: 15px;
        margin-bottom: 15px;
        width: 100%;
        height: 125px;
        position: relative;
        font-size: 1.4rem;
      }

      .scrollbar {
        scrollbar-color: #5a6473 #788394;
      }

      .missionbar .mission-button {
        border-radius: 50%;
        min-width: 63px;
        max-width: 63px;
        min-height: 63px;
        max-height: 63px;
        width: 63px;
        height: 63px;
        cursor: pointer;
        padding: 0;
        margin: 0;
        transition: all 0.3s;
        text-decoration: none;
        justify-content: center;
        user-select: none;
        align-items: center;
        display: inline-flex;
      }

      .missionbar .mission-label-container {
        width: 100%;
        padding: 10px 0;
        display: -ms-flexbox;
        display: flex;
        align-content: center;
        align-items: center;
      }

      .theme-light .missionbar .mission-label {
        background: #fff;
      }

      .missionbar .mission-label {
        font-size: 1rem;
        text-align: right;
        background-color: transparent !important;
        font-family: "MuseoSans", sans-serif;
        color: #fff !important;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        width: 65%;
        padding-right: 10px;
      }

      .scrollbar {
        scrollbar-color: #5a6473 #788394;
      }

      .missionbar .mission-icon-container--active {
        font-weight: 500;
      }

      .missionbar .mission-icon-container--active::before {
        content: "";
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 5px;
        opacity: 1;
        transition: all 0.3s;
      }

      .missionbar .mission-icon-container--red .mission-button {
        background-color: #dd5c55;
        border-color: transparent;
      }

      .missionbar
        .mission-icon-container--red:hover.mission-icon-container--active::before {
        background-color: #dc4d46;
      }

      .missionbar
        .mission-icon-container--red.mission-icon-container--active::before {
        background-color: #dd5c55;
      }

      .missionbar .mission-icon-container--orange .mission-button {
        background-color: #ff9600;
        border-color: transparent;
      }

      .missionbar
        .mission-icon-container--orange:hover.mission-icon-container--active::before {
        background-color: #ff8400;
      }

      .missionbar
        .mission-icon-container--orange.mission-icon-container--active::before {
        background-color: #ff8400;
      }

      .missionbar .mission-icon-container--green .mission-button {
        background-color: #54ca95;
        border-color: transparent;
      }

      .missionbar
        .mission-icon-container--green:hover.mission-icon-container--active::before {
        background-color: #54ca95;
      }

      .missionbar
        .mission-icon-container--green.mission-icon-container--active::before {
        background-color: #54ca95;
      }

      .missionbar .mission-label-container .mission-counter {
        font-size: 0.6rem;
        padding: 4px 6px;
        border-radius: 50%;
        background-color: #252e3d;
        text-align: center;
        color: #fff;
      }

      .collapsed {
        display: none;
      }
    `;
  }

  constructor() {
    super();
    this.missions = [];

    //TODO hardcoded mission code
    this.currentMission = {
      code: "SP",
      name: "Social Profiles",
    };
  }

  render() {
    return html`
      <div class="missionbar${this.collapsed ? " collapsed" : ""}">
        <div class="missions-header">
          Missions<span class="missions-count">(${this.missions.length})</span>
        </div>
        <div class="scrollbar nav-list">
          ${this.missions.map((mission) => {
            const color = COLORS[sumChars(mission.name) % COLORS.length];
            const missionName = initials(mission.name);
            const isActiveMission =
              this.currentMission && mission.code === this.currentMission.code;
            const activeClass = isActiveMission ? "--active" : "";

            return html`
              <div
                class="mission-icon-container mission-icon-container--${color} mission-icon-container${activeClass}"
              >
                <a
                  class="mission-button"
                  tabindex="0"
                  role="button"
                  aria-disabled="false"
                  href="./results/list"
                >
                  <div class="mission-name">${missionName}</div>
                </a>
                <div class="mission-label-container">
                  <div class="mission-label">${missionName}</div>
                  <div class="mission-counter">1</div>
                </div>
              </div>
            `;
          })}
        </div>
      </div>
    `;
  }

  firstUpdated() {
    this.loadData();
  }

  loadData = () => {
    GetMissionsAPI.executeApiCall(this, null, this.loadMissions);
  };

  loadMissions = (event) => {
    const {
      detail: { result },
    } = event;
    this.missions = result;
  };
}

customElements.define("missionbar-menu", MissionbarMenu);
