import { html, css } from "lit-element";
import { MvElement } from "mv-element";
import "mv-header";
import "mv-main";
import "mv-footer";
import "./topbar-menu/topbar-menu.js";
import "./missionbar-menu/missionbar-menu.js";
import "./sidebar-menu/sidebar-menu.js";

export default class PageLayout extends MvElement {
  static get properties() {
    return {
      hasBackButton: { type: Boolean, attribute: "has-back-button" },
      selected: { type: String, reflect: true, attribute: false },
      missionbar: { type: Boolean, attribute: false },
      sidebar: { type: Boolean, attribute: false },
      language: { type: String, attribute: false },
      theme: { type: String, attribute: true },
    };
  }

  static get styles() {
    return css`
      :host {
        top: 0;
        padding: 0;
        margin: 0;
        --mv-footer-item-light-color: #444444;
        --mv-header-height: 80px;
        --mv-footer-height: 40px;
        --mv-menu-panel-width: 0;
        --mv-main-margin-left: 0;
        --mv-content-padding: 0;
      }

      mission-bar {
        background: linear-gradient(to top, #1a1e23, #3f4753);
      }

      .wrapper {
        background: var(--light-9-background);
        height: 100%;
        position: relative;
        overflow-y: hidden;
        --mv-footer-margin-left: 443px;
        --main-container-padding-left: 0;
        --grid-template-columns: 113px 330px auto;
      }

      .wrapper.missionbar-collapse {
        --grid-template-columns: 0 330px auto;
        --mv-footer-margin-left: 330px;
      }

      .wrapper.sidebar-collapse {
        --grid-template-columns: 113px 65px auto;
        --mv-footer-margin-left: 178px;
      }

      .wrapper.sidebar-collapse.missionbar-collapse {
        --grid-template-columns: 0 65px auto;
        --mv-footer-margin-left: 65px;
      }

      .main-section {
        display: grid;
        grid-template-columns: var(--grid-template-columns);
        transition: all 0.3s;
        grid-gap: 0;
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100%;
      }

      .main-content {
        width: 100%;
      }

      .container-wrap {
        transition: padding-left 0.3s;
      }
    `;
  }

  static get model() {
    return {
      modelClass: "Application",
      mappings: [
        { property: "missionbar", value: "missionbar" },
        { property: "sidebar", value: "sidebar" },
        { property: "language", value: "language" },
      ],
    };
  }

  constructor() {
    super();
    this.menu = {
      sidebar: true,
      missionbar: true,
      languages: [],
      missions: [],
      investigations: [],
      selected: {
        mission: {},
        investigation: {},
        language: {},
        theme: "",
      },
    };
    this.selected = "social-profile";
    this.theme = "light";
    this.sidebar = true;
    this.missionbar = true;
    this.language = "en";
  }

  render() {
    const sidebarClass = !this.sidebar ? " sidebar-collapse" : "";
    const missionbarClass = !this.missionbar ? " missionbar-collapse" : "";

    return html`
      <div class="wrapper${sidebarClass}${missionbarClass}">
        <mv-main>
          <mv-header slot="header">
            <mv-header item>
              <topbar-menu
                @toggle-missionbar="${this.toggleMissionbar}"
                @update-language="${this.updateLanguage}"
                .language="${this.language}"
              ></topbar-menu>
            </mv-header>
          </mv-header>
          <div class="main-section">
            <missionbar-menu ?collapsed="${!this.missionbar}"></missionbar-menu>
            <sidebar-menu
              ?collapsed="${!this.sidebar}"
              @sidebar-item-clicked="${this.sidebarItemClicked}"
              @toggle-sidebar="${this.toggleSidebar}"
            ></sidebar-menu>
            <slot></slot>
          </div>
          <mv-footer slot="footer" .theme="${this.theme}">
            <mv-footer item>
              <small> Webdrone SAS<br />Copyright 2020 </small>
            </mv-footer>
          </mv-footer>
        </mv-main>
      </div>
    `;
  }

  sidebarItemClicked = (event) => {
    const {
      detail: { selected },
    } = event;
    this.selected = selected;
  };

  toggleMissionbar = (event) => {
    this.missionbar = !this.missionbar;
    this.updateStore("missionbar", this.missionbar);
  };

  toggleSidebar = () => {
    this.sidebar = !this.sidebar;
    this.updateStore("sidebar", this.sidebar);
  };

  updateLanguage = (event) => {
    const {
      detail: { language },
    } = event;
    this.language = language;
    this.updateStore("language", this.language);
  };

  updateStore = (name, value) => {
    this.store.updateValue(name, value);
  };
}

customElements.define("page-layout", PageLayout);
