import { LitElement, html, css } from "lit-element";
import "mv-dropdown";
import "mv-tags";
import "mv-checkbox";

const extractOptions = (options, value, checked) => {
  return options.reduce((list, item) => {
    const exists = item.value === value;
    if (exists) {
      return [...list, { ...item, checked }];
    }
    return [...list, item];
  }, []);
};

const extractList = list => {
  return list.map(item => item.value);
};

const filterList = (list, value) => {
  return list.filter(item => item !== value);
};

const filterTags = (options, savedTags) => {
  return [...savedTags, ...extractList(options.filter(option => option.checked === true))];
};

const changeOptions = (options, checked) => {
  return options.map(option => ({ ...option, checked }));
};

class SearchFilter extends LitElement {
  static get properties() {
    return {
      name: { type: String, attribute: true },
      options: { type: Array, attribute: false, reflect: true },
      data: { type: Array, attribute: false },
      label: { type: String, attribute: true },
      value: { type: String, attribute: true },
      checkedAll: { type: Boolean, attribute: true },
      tags: { type: Array, attribute: false },
      storedTags: { type: Array, attribute: false },
      savedTags: { type: Array, attribute: false }
    };
  }

  static get styles() {
    return css`
      .count {
        width: 33px;
        height: 33px;
        border-radius: 50%;
        background-color: #007FAD;
        margin-left: 5px;
        color: #FFFFFF;
      }
      
      mv-button {
        --mv-button-hover-light-background: #99D2E7;
        --mv-button-padding: 5px 40px;
      }
      
      .wrap-title, .count {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      mv-dropdown {
        --mv-dropdown-trigger-height: 58px;
        --mv-dropdown-min-width: 350px;
        --mv-dropdown-max-width: 350px;
        --mv-dropdown-content-max-height: 400px;
        --mv-dropdown-header-padding: 12px 15px;
        --mv-dropdown-content-margin: 10px 0;
      }
      
      ul {
        list-style: none;
        padding: 0 0 0 10px;
      }
      
      .no-option {
        text-align: center;
        height: 37px;
      }
      
      .select-all {
        margin-bottom: 20px;
        display: flex;
        justify-content: space-between;
      }
      
      .clear-selection {
        margin-top: -3px;
        margin-right: 10px;
        color: #67AFD3;
      }
      
      .clear-selection:hover {
        color: #007ADF;
      }
    `;
  }

  constructor() {
    super();
    this.name = "";
    this.options = [];
    this.data = [];
    this.value = "";
    this.checkedAll = false;
    this.tags = [];
    this.storedTags = [];
    this.savedTags = [];
  }

  render() {
    const count = this.tags.length > 0 ? this.tags.length : null;
    const styleButton = count ? "" : "--mv-button-padding: 12px 55px";
    return html`
      <div class="item top center">
        <mv-dropdown container justify="center" position="bottom">
          <mv-dropdown trigger>
            <mv-button type="outline" button-style="info" style="${styleButton}">
              <div class="wrap-title">
                <div class="title">${this.label}</div>
                ${count ? html`<div class="count">${count}</div>` : html``}
              </div>
            </mv-button>
          </mv-dropdown>
          <mv-dropdown header>${this.label}</mv-dropdown>
          <mv-dropdown footer>
            <mv-tags
              .tags="${this.tags}"
              @add-tag="${this.updateTags}"
              @remove-tag="${this.removeTags}"
              @change-tag="${this.changeTags}"
              placeholder="Select..."
              .value="${this.value}"
            ></mv-tags>
          </mv-dropdown>
          <mv-dropdown content>
            <ul>
              ${this.options.length > 0
                ? html`
                  <li class="select-all">
                    <mv-checkbox
                      .checked="${!!this.checkedAll}"
                      @click-checkbox="${this.selectAll}"
                      label="Select all"
                      .value="Select all"
                    ></mv-checkbox>
                    <div class="clear-selection" @click="${this.clear}">Clear Selection</div>
                  </li>`
                : html``}
              ${this.options.map(option => html`
                <li>
                  <mv-checkbox
                    .checked="${!!option.checked}"
                    @click-checkbox="${this.handleClickCheckbox}"
                    .label="${option.value}"
                    .value="${option.value}"
                  ></mv-checkbox>
                </li>
              `)}
            </ul>
            ${this.options.length === 0 ? html`<div class="no-option">No options</div>` : html``}
          </mv-dropdown>
        </mv-dropdown>
      </div>
    `;
  }

  firstUpdated() {
    this.savedTags = this.storedTags;
  }

  updated(changedProperties) {
    changedProperties.forEach((oldValue, propName) => {
      this.resetSavedTags(propName, oldValue);
    });
  }

  resetSavedTags = (prop, value) => {
    if (prop === "storedTags" && value && value.length !== 0 && this.storedTags && this.storedTags.length === 0) {
      this.savedTags = [];
    }
  };

  changeValue = (eventName, value) => {
    this.dispatchEvent(
      new CustomEvent(eventName, {
        detail: { ...value }
      })
    );
  };

  removeTags = event => {
    const { detail } = event;
    const { value } = detail;
    const { name } = this;
    const hasSavedTags = this.savedTags.some(tag => tag === value);
    if (hasSavedTags) {
      this.tags = filterList(this.tags, value);
      this.savedTags = filterList(this.savedTags, value);
      this.changeValue("filter-change", { name, tags: this.tags });
    } else {
      this.options = extractOptions(this.options, value, false);
      this.tags = filterTags(this.options, this.savedTags);
      this.changeValue("filter-change", { name, tags: this.tags });
    }
    this.changeValue("option-change", { name, option: this.options });
  };

  changeTags = event => {
    const { detail: { value } } = event;
    const { name } = this;
    const options = value ?
      this.data.filter(data => data.value.toString().toLowerCase().indexOf(value.toLowerCase()) !== -1) :
      [];
    const optionNotTags = this.savedTags.length > 0
      ? options.filter(option => (!this.savedTags.includes(option.value) && !this.tags.includes(option.value)))
      : options.filter(option => !this.tags.includes(option.value));
    this.changeValue("option-change", { name, option: optionNotTags });
    this.changeValue("value-change", { name, value });
  };

  handleClickCheckbox = event => {
    const { detail: { originalEvent, value, checked } } = event;
    const { name } = this;
    originalEvent.stopPropagation();
    this.options = extractOptions(this.options, value, checked);
    this.tags = filterTags(this.options, this.savedTags);
    this.changeValue("filter-change", { name, tags: this.tags });
    this.changeValue("option-change", { name, option: this.options });
  };

  clear = () => {
    const { name } = this;
    this.options = changeOptions(this.options, false);
    this.tags = this.tags.filter(tag => !extractList(this.options).includes(tag));
    this.changeValue("option-change", { name, option: this.options, checkedAll: false });
    this.changeValue("filter-change", { name, tags: this.tags });
  };

  selectAll = event => {
    const { detail: { originalEvent, checked } } = event;
    const { name } = this;
    originalEvent.stopPropagation();
    this.options = changeOptions(this.options, checked);
    const tags = [...this.savedTags, ...extractList(this.options)];
    this.changeValue("filter-change", { name, tags: checked ? tags : this.savedTags });
    this.checkedAll = checked;
    this.changeValue("option-change", { name, option: this.options, checkedAll: this.checkedAll });
  };
}

customElements.define("search-filter", SearchFilter);
