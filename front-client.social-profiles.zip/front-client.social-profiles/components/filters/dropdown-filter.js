import { LitElement, html, css } from "lit-element";
import "mv-dropdown";
import "mv-checkbox";

class DropdownFilter extends LitElement {
  static get properties() {
    return {
      name: { type: String, attribute: true },
      data: { type: Array, attribute: false },
      label: { type: String, attribute: true }
    };
  }

  static get styles() {
    return css`
      .count {
        width: 33px;
        height: 33px;
        border-radius: 50%;
        background-color: #007FAD;
        margin-left: 5px;
        color: #FFFFFF;
      }
      
      mv-button {
        --mv-button-hover-light-background: #99D2E7;
        --mv-button-padding: 5px 40px;
      }
      
      .wrap-title, .count {
        display: flex;
        align-items: center;
        justify-content: center;
      }
      
      li {
        margin-bottom: 10px;
      }
      
      mv-dropdown {
        --mv-dropdown-trigger-height: 58px;
        --mv-dropdown-min-width: 250px;
        --mv-dropdown-max-width: 250px;
        --mv-dropdown-content-max-height: 400px;
        --mv-dropdown-header-padding: 12px 15px;
        --mv-dropdown-content-margin: 10px 0;
      }
      
      ul {
        list-style: none;
        padding: 0 0 0 10px;
      }
    `;
  }

  constructor() {
    super();
    this.name = "";
    this.data = [];
    this.label = "";
  }

  render() {
    const count = this.data.filter(item => item.checked).length;
    const styleButton = count ? "" : "--mv-button-padding: 12px 55px";
    return html`
      <div class="item top center">
        <mv-dropdown container justify="center" position="bottom">
          <mv-dropdown trigger>
            <mv-button type="outline" button-style="info" style="${styleButton}">
              <div class="wrap-title">
                <div class="title">${this.label}</div>
                ${count ? html`<div class="count">${count}</div>` : html``}
              </div>
            </mv-button>
          </mv-dropdown>
          <mv-dropdown header>${this.label}</mv-dropdown>
          <mv-dropdown content>
            <ul>
              ${this.data.map(option => html`
                <li>
                  <mv-checkbox
                    .checked="${!!option.checked}"
                    @click-checkbox="${this.handleClickCheckbox}"
                    .label="${option.value}"
                    .value="${option.value}"
                  ></mv-checkbox>
                </li>
              `)}
            </ul>
          </mv-dropdown>
        </mv-dropdown>
      </div>
    `;
  }

  handleClickCheckbox = event => {
    const { detail } = event;
    const { originalEvent, value } = detail;
    const { name } = this;
    originalEvent.stopPropagation();
    this.data = this.data.reduce((list, item) => {
      const exists = item.value === value;
      if (exists) {
        return [...list, { ...item, checked: !item.checked }];
      }
      return [...list, item];
    }, []);
    this.dispatchEvent(
      new CustomEvent("data-change", {
        detail: { ...detail, name, data: this.data }
      })
    );
  }
}

customElements.define("dropdown-filter", DropdownFilter);
