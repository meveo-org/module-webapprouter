import { LitElement, html, css } from "lit-element";
import "mv-container";
import "mv-button";

class FiltersOptions extends LitElement {
  static get properties() {
    return {
    };
  }

  static get styles() {
    return css`
      mv-container {
        --mv-container-max-width: 100%;
        --mv-container-margin: 0 20px;
      }

      .wrap-filters {
        display: grid;
        grid-template-columns: 5% 75% 20%;
      }

      .filters {
        display: flex;
        flex-wrap: wrap;
        align-items: left;
        justify-content: left;
      }

      .buttons mv-button {
        --mv-button-padding: 16px 30px;
        margin-top: 3px;
      }

      .wrap-title, .buttons {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
      }

      .wrap-title {
        color: #80828C;
      }
    `;
  }

  constructor() {
    super();
  }

  render() {
    return html`
      <mv-container>
        <div class="wrap-filters">
          <div class="wrap-title">Filters</div>
          <div class="filters">
            <slot></slot>
          </div>
          <div class="buttons">
            <mv-button button-style="cancel" @button-clicked="${this.handleReset}">Reset</mv-button>
            <mv-button @button-clicked="${this.handleFilter}">Apply</mv-button>
          </div>
        </div>
      </mv-container>
    `;
  }

  handleFilter = () => {
    this.dispatchEvent(new CustomEvent("apply-filter"));
  };

  handleReset = () => {
    this.dispatchEvent(new CustomEvent("reset-filter"));
  };
}

customElements.define("filters-options", FiltersOptions);
