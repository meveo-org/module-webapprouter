import { LitElement, html, css } from "lit-element";
import "mv-dialog";
import "mv-font-awesome";

class InvestigationOverview extends LitElement {
  static get properties() {
    return {
      open: { type: Boolean },
      investigation: { type: Object, attribute: false, reflect: true }
    };
  }

  static get styles() {
    return css`
      :host {
        --mv-dropdown-trigger-height: 27px;
        --mv-dropdown-min-width: 460px;
        --mv-dropdown-max-width: 460px;
        --mv-dropdown-content-max-height: 578px;
        --mv-dropdown-header-padding: 10px 15px;
      }

      .investigation-type {
        text-align: center;
        margin: auto 0;
        align-items: center;
        background-color: #54ca95;
        height: 24px;
        border-radius: 5px;
        font-family: MuseoSans;
        padding: 0 10px;
        font-size: 0.8rem;
        font-weight: 500;
        color: #ffffff;
        text-shadow: 0px 1px 2px #008563;
        text-transform: uppercase;
        display: flex;
        cursor: pointer;
      }

      .investigation-type .investigation-icon {
        color: inherit;
        border: none;
        background: none;
        border-left: 1px solid currentColor;
      }

      .investigation-icon {
        padding: 0 0 0 10px;
        border-style: none;
        text-transform: none;
        overflow: visible;
        margin: 0;
        border-radius: 0;
        border: 0;
        cursor: pointer;
        outline: none;
      }

      .investigation-label {
        padding-right: 10px;
      }

      ul.investigation-overview {
        padding: 0;
        margin: 10px 0;
      }

      .investigation-overview li {
        font-size: var(--font-size-s);
        list-style: none;
        padding: 6px 17px;
      }

      .investigation-overview li:hover {
        color: #ffffff;
        background-color: #2a3138;
      }

      .header-label {
        padding: 5px 0;
        font-size: 20px;
      }

      .close-icon {
        color: #a8abb9;
      }

      .close-icon:hover {
        color: #ffffff;
      }

      .overview-details {
        font-family: MuseoSans;
        font-size: var(--font-size-m);
        font-weight: 100;
        color: #ffffff;
        width: calc(100% - 40px);
        margin: 20px;
        border-spacing: 0 5px;
        border-collapse: separate;
      }

      .overview-row td {
        padding: 5px 10px;
        border-top: 1px solid #a8abb9;
        border-bottom: 1px solid #a8abb9;
      }

      .overview-row td:first-child {
        width: 130px;
        font-weight: 500;
        border-left: 1px solid #a8abb9;
        border-radius: 5px 0 0 5px;
      }

      .overview-row td:last-child {
        border-right: 1px solid #a8abb9;
        border-radius: 0 5px 5px 0;
      }

      .sublevel {
        border: 1px solid #a8abb9;
        border-radius: 5px;
      }

      .sublevel-contents {
        width: 100%;
      }

      .sublevel-contents tr {
        padding: 0;
        margin: 0;        
      }

      .sublevel-contents th,
      .sublevel-contents td {
        text-align: left;
        padding: 5px 10px;
      }

      .sublevel-contents th:first-child,
      .sublevel-contents td:first-child {
        width: 130px;        
      }

      .sublevel-contents ul {
        margin: 0;
        padding: 0;
      }

      .sublevel-contents li {
        list-style: none;
      }

      .more-link {
        display: inline-block;
        font-size: var(--font-size-xs);
        color: #00b9fe;
      }
    `;
  }

  constructor() {
    super();
    this.open = false;
    this.investigation = {
      name: "",
      type: ""
    };
  }

  render() {
    return html`
      <mv-dropdown container justify="left" position="bottom">
        <mv-dropdown trigger>
          <div class="investigation-type">
            <span class="investigation-label">${this.investigation.type}</span>
            <button class="investigation-icon">
              <mv-fa icon="external-link-alt"></mv-fa>
            </button>
          </div>
        </mv-dropdown>
        <mv-dropdown header>
          <span class="header-label">Parameters Summary</span>
          <span class="close-icon" @click="${this.handleClose}">&#10005;</span>
        </mv-dropdown>
        <mv-dropdown content>
          <table class="overview-details">
            <tbody>
              <tr class="overview-row">
                <td>Type</td>
                <td>Discovery</td>
              </tr>
              <tr class="overview-row">
                <td>Type of Website</td>
                <td>E-commerce, Marketplaces, Social Network</td>
              </tr>
              <tr class="overview-row">
                <td>Location</td>
                <td>
                  Germany, France, United Kingdom, United States...
                  <span class="more-link">+195 more</span>
                </td>
              </tr>
              <tr class="overview-row">
                <td>Thematics</td>
                <td>Counterfeit</td>
              </tr>
              <tr>
                <td colspan="2" class="sublevel">
                  <table class="sublevel-contents">
                    <thead>
                      <tr>
                        <th>Brand</th>
                        <th>Product</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Dior</td>
                        <td>
                          <ul>
                            <li>Sauvage</li>
                            <li>Poison</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <td>Decathlon</td>
                        <td>
                          <ul>
                            <li>EasyBreath</li>
                          </ul>
                        </td>
                      </tr>
                      <tr>
                        <td>Sony</td>
                        <td>
                          <ul>
                            <li>Vaio</li>
                          </ul>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
            </tbody>
          </table>
        </mv-dropdown>
      </mv-dropdown>
    `;
  }

  handleClose = event => {
    const { target } = event;
    target.dispatchEvent(
      new CustomEvent("close-mv-dropdown", { bubbles: true })
    );
  };
}

customElements.define("investigation-overview", InvestigationOverview);
