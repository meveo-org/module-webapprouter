import { LitElement, html, css } from "lit-element";
import "mv-dialog";
import "mv-input";

class RenameDialog extends LitElement {
  static get properties() {
    return {
      open: { type: Boolean },
      investigation: { type: Object, attribute: false, reflect: true }
    };
  }

  static get styles() {
    return css`
      .rename-dialog {
        --mv-dialog-width: 500px;
        --mv-dialog-max-height: 280px;
      }

      .dialog-content {
        --mv-input-border: 1px solid #666;
        --mv-input-active-border: 1px solid #28a745;
        --mv-input-color: #000;
        margin-top: 15px;
      }

      .investigation-dialog-label {
        margin-bottom: 10px;
        font-size: 14px;
        color: #818181;
        font-family: "MuseoSans", sans-serif;
      }

      .investigation-field-container {
        margin-top: 10px;
        margin-bottom: 25px;
      }
    `;
  }

  constructor() {
    super();
    this.open = false;
    this.investigation = {
      name: ""
    };
  }

  render() {
    return html`
      <mv-dialog
        ?open="${this.open}"
        @close-dialog="${this.close}"
        @ok-dialog="${this.rename}"
        class="rename-dialog"
        left-label="Cancel"
        right-label="Save"
        header-label="Rename"
        closeable
        close-on-click
      >
        <div class="dialog-content">
          <div class="investigation-dialog-label">Investigation name</div>
          <div class="investigation-field-container">
            <mv-input
              name="name"
              type="text"
              .value=${this.investigation.name}
              placeholder="Enter investigation name"
              @input-change="${this.changeName}"
            ></mv-input>
          </div>
        </div>
      </mv-dialog>
    `;
  }

  close = event => {
    this.dispatchEvent(
      new CustomEvent("close-dialog", { detail: { name: "rename" } })
    );
  };

  rename = event => {
    console.log("event :", event);
    const { investigation } = this;
    this.dispatchEvent(
      new CustomEvent("rename-investigation", {
        detail: { investigation }
      })
    );
  };

  changeName = event => {
    const {
      detail: { value }
    } = event;
    this.investigation = {
      ...this.investigation,
      name: value
    };
  };
}

customElements.define("rename-dialog", RenameDialog);
