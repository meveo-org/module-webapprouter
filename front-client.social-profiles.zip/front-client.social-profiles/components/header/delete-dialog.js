import { LitElement, html, css } from "lit-element";
import "mv-dialog";
import "mv-linear-icons";

class DeleteDialog extends LitElement {
  static get properties() {
    return {
      open: { type: Boolean },
      investigation: { type: Object, attribute: false, reflect: true }
    };
  }

  static get styles() {
    return css`
      .delete-dialog {
        --mv-dialog-width: 400px;
        --mv-dialog-max-height: 350px;
      }

      .delete-icon-container {
        width: 77px;
        height: 77px;
        background: linear-gradient(to right, #f77062 0%, #e52f2f 55%);
        box-sizing: 1px 1px 0 rgba(18, 110, 213, 0.5);
        border-radius: 50%;
        margin: auto;
        display: flex;
        align-items: center;
        justify-content: center;
        outline: none;
        margin-top: 25px;
      }

      .trash-icon {
        font-size: 32px;
        color: #fff;
      }

      .delete-dialog-message {
        text-align: center;
        color: #818181;
        margin-top: 20px;
        padding: 10px;
        font-size: 14px;
        font-family: var(--font-family);
        line-height: 1.5;
      }
    `;
  }

  constructor() {
    super();
    this.open = false;
    this.investigation = {
      name: ""
    };
  }

  render() {
    return html`
      <mv-dialog
        class="delete-dialog"
        ?open="${this.open}"
        @close-dialog="${this.close}"
        @ok-dialog="${this.deleteInvestigation}"
        left-label="Cancel"
        right-label="Delete"
        header-label="Delete"
        closeable
        close-on-click
      >
        <div class="delete-icon-container">
          <span class="trash-icon">
            <mv-lnr icon="trash"></mv-lnr>
          </span>
        </div>
        <div class="delete-dialog-message">
          You are about to move <strong>${this.investigation.name}</strong> into
          the trash.
        </div>
      </mv-dialog>
    `;
  }

  close = () => {
    this.dispatchEvent(
      new CustomEvent("close-dialog", { detail: { name: "delete" } })
    );
  };

  deleteInvestigation = () => {
    const { investigation } = this;
    this.dispatchEvent(
      new CustomEvent("delete-investigation", { detail: { investigation } })
    );
  };
}

customElements.define("delete-dialog", DeleteDialog);
