import { LitElement, html, css } from "lit-element";
import "router-slot";
import "mv-header";
import "mv-input";
import "mv-linear-icons";
import "mv-dialog";
import "mv-font-awesome";
import "mv-breadcrumbs";
import "mv-tooltip";
import "mv-dropdown";

import "../../components/header/delete-dialog.js";
import "../../components/header/rename-dialog.js";
import "../../components/header/investigation-overview.js";

class InvestigationHeader extends LitElement {
  static get properties() {
    return {
      hasBackButton: { type: Boolean, attribute: "has-back-button" },
      investigation: { type: Object, attribute: false },
      openDialog: { type: Object, attribute: false },
      showFilters: { type: Boolean, attribute: true }
    };
  }

  static get styles() {
    return css`
      :host {        
        top: 0;
        padding: 0;
        margin: 0;
        width: 100%;
        color: #80828c;
        z-index: 999;
        --mv-header-light-background: #fff;
        --mv-header-height: 90px;
        --mv-header-shadow: 0 0 12px 0 rgba(42, 42, 42, 0.65);
        --mv-tooltip-font-family: MuseoSans;
        --mv-tooltip-content-font-size: 12px;
        --mv-breadcrumbs-link-decoration: none;
        --mv-dropdown-trigger-height: 72px;
        --mv-dropdown-min-width: 200px;
        --mv-dropdown-max-width: 200px;
        --mv-dropdown-content-max-height: 245px;
      }

      a {
        text-decoration: none;
      }

      button:focus {
        outline: 0;
      }

      .dashboard-title {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-family: Comfortaa-Bold;
        color: #64666e;
        margin: auto 15px;
        font-size: 30px;
        max-width: 415px;
      }

      .icon-button {
        width: 48px;
        min-width: 48px;
        max-width: 48px;
        height: 48px;
        min-height: 48px;
        max-height: 48px;
        border-radius: 24px;
        color: #80828c;
        background-color: #ffffff;
        border: none;
        margin: auto;
        padding: 3px 0 0 0;
        font-size: 20px;
      }

      .icon-button:hover,
      .icon-button.active {
        color: #ffffff;
        background-color: #3999c1;
      }

      ul.settings-menu {
        padding: 0;
        margin: 10px 0;
      }

      .settings-menu li {
        font-size: var(--font-size-s);
        list-style: none;
        padding: 6px 17px;
      }

      .settings-menu li:hover {
        color: #ffffff;
        background-color: #2a3138;
      }

      .percentage-title {
        font-size: var(--font-size-xxs);
        font-weight: normal;
        color: #3999c1;
      }

      .chart-container {
        font-size: 12px;
        min-width: 40px;
        min-height: 40px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: #3999c1;
      }

      .chart-container .pie-chart {
        border: 2px solid #ccc;
        border-radius: 50%;
        width: 38px;
        height: 38px;
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .chart-container .percentage-value {
        font-weight: bold;
        font-size: var(--font-size-s);
        color: #3999c1;
        text-align: center;
      }
    `;
  }

  constructor() {
    super();
    this.hasBackButton = false;
    this.investigation = { name: "Test Investigation", type: "Monitoring" };
    this.openDialog = { delete: false, rename: false };
    this.showFilters = false;
  }

  render() {
    const filtersClass = this.showFilters ? "active" : "";
    return html`
      <mv-header theme="light">
        ${this.hasBackButton
          ? html`
              <mv-header item>
                <mv-tooltip position="bottom">
                  <mv-button
                    type="circle"
                    @button-clicked="${this.navigateBack}"
                  >
                    <mv-lnr icon="chevron-left"></mv-lnr>
                  </mv-button>
                  <span slot="tooltip-content">Back</span>
                </mv-tooltip>
              </mv-header>
            `
          : ""}
        <mv-header item>
          <a href="/">
            <h1 class="dashboard-title">${this.investigation.name}</h1>
          </a>
        </mv-header>
        <mv-header item>
          <investigation-overview
            .investigation="${this.investigation}"
          ></investigation-overview>
        </mv-header>
        <mv-header item position="right">
          <mv-button type="rounded" theme="dark">
            <mv-lnr icon="redo"></mv-lnr>Refresh
          </mv-button>
        </mv-header>
        <mv-header item position="right">
          <mv-tooltip position="bottom">
            <button 
              class="icon-button ${filtersClass}"
              @click="${this.toggleFilters}"
            ><mv-lnr icon="funnel"></mv-lnr></button>
            <span slot="tooltip-content">Filters</span>
          </mv-tooltip>
        </mv-header>
        <mv-header item position="right">
          <mv-dropdown container justify="right" position="bottom" close-on-click>
            <mv-dropdown trigger>
              <mv-tooltip position="bottom">
                <button class="icon-button">
                  <mv-lnr icon="cog"></mv-lnr>
                </button>
                <span slot="tooltip-content">Settings</span>
              </mv-tooltip>
            </mv-dropdown>
            <mv-dropdown content>
              <ul class="settings-menu">
                <li @click=${this.openRenameDialog}>
                  <mv-lnr icon="pencil"></mv-lnr>
                  <span class="popup-item-text">Rename</span>
                </li>
                <li @click=${this.openDeleteDialog}>
                  <mv-lnr icon="trash"></mv-lnr>
                  <span class="popup-item-text">Move to trash</span>
                </li>
              </ul>
            </mv-dropdown>
          </mv-dropdown>
        </mv-header>
        <mv-header item position="right">
          <div class="chart-container">
            <div class="pie-chart">
              <span class="percentage-value">0%</span>
            </div>
            <div class="percentage-title">Verified data</div>
          </div>
        </mv-header>
      </mv-header>
      <delete-dialog
        ?open="${this.openDialog.delete}"
        .investigation="${this.investigation}"
        @close-dialog="${this.closeDialog}"
        @delete-investigation="${this.deleteInvestigation}"
      ></delete-dialog>
      <rename-dialog
        ?open="${this.openDialog.rename}"
        .investigation="${this.investigation}"
        @close-dialog="${this.closeDialog}"
        @rename-investigation="${this.renameInvestigation}"
      ></rename-dialog>
    `;
  }

  navigateBack = () => {
    history.pushState(null, null, "./form");
  };

  openRenameDialog = () => {
    this.openDialog = {
      delete: false,
      rename: true
    };
  };

  renameInvestigation = event => {
    console.log("renameInvestigation", event);
    const {
      detail: { investigation }
    } = event;
    if (investigation.name !== this.investigation.name) {
      this.investigation = { ...investigation };
      this.openDialog = {
        ...this.openDialog,
        rename: false
      };
    } else {
      // TODO - improve error messaging
      alert("Investigation name has not changed.");
    }
  };

  openDeleteDialog = () => {
    this.openDialog = {
      delete: true,
      rename: false
    };
  };

  deleteInvestigation = event => {
    const {
      detail: { investigation }
    } = event;
    // TODO - delete current investigation and navigate away
    this.openDialog = {
      ...this.openDialog,
      delete: false
    };
    setTimeout(() => {
      alert(investigation.name + " was deleted.");
    }, 200);
  };

  closeDialog = event => {
    const {
      detail: { name }
    } = event;
    this.openDialog = {
      ...this.openDialog,
      [name]: false
    };
  };

  toggleFilters = () => {
    this.showFilters = !this.showFilters;
    this.dispatchEvent(new CustomEvent("toggle-filters", { detail: { showFilters: this.showFilters } }));
  };
}

customElements.define("investigation-header", InvestigationHeader);
