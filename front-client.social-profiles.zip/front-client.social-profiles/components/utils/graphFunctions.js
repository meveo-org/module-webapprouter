export function neo4jToGraphJson(graphData) {
	let nodes = [];
	let deletedNodes = [];
	let rels = [];
	let notDuplicatedRels = [];
	let arcLarges = [-30, 80, -80, 110];
	let labels = [];
	let displayNode = false;

	graphData.forEach( result => {
		result.data.forEach(row => {
			if (typeof row.graph !== 'undefined') {
				row.graph.nodes.forEach(node => {
					if (typeof node.properties !== 'undefined') {
						if (node.properties['internal_active'] === 'TRUE') {
							if (node.labels[0] === 'Person') {
								if (node.properties['lastName'] != null && !node.properties['lastName'].endsWith('-tmp')) {
									displayNode = true;
								} else {
									displayNode = false;
								}
							} else {
								displayNode = true;
							}

							let found = nodes.some((m) => m.id === node.id);


							if (displayNode && !found) {
								for (let p in node.properties || {}) {
									if (!p.endsWith('_IDX') && !p.endsWith('_key') && !p.startsWith('internal_')) {
										node[p] = node.properties[p];
										delete node.properties[p];
									}
								}
								// TODO Temporary fix for missing nodes when changing tabs - will investigate further
								// delete node.properties;
								nodes.push(node);
								labels = labels.concat(node.labels.filter(l => labels.indexOf(l) === -1));
							}
						}
					}
					if (!displayNode) {
						deletedNodes = deletedNodes.concat(node);
					}

				});

				row.graph.relationships.forEach(function (r) {
					let found = rels.filter(function (m) {
						return m.edgeId === r.id;
					}).length > 0;
					let deleted = deletedNodes.filter(function (m) {
						return m.id === r.startNode || m.id === r.endNode;
					}).length > 0;

					if (!found && !deleted) {
						let largArcValue = 30;

						let key = r.startNode + "-" + r.endNode;
						let count = notDuplicatedRels.filter(val => val === key).length;
						if (count > 0) {
							largArcValue = arcLarges[count - 1];
						}

						notDuplicatedRels = notDuplicatedRels.concat(key);
						rels = rels.concat({
							edgeId: r.id,
							largeArc: largArcValue,
							source: r.startNode,
							target: r.endNode,
							type: r.type,
							properties: r.properties
						});
					}
				});
			}
		});
	});

	return ({
		graph: {
			nodes: nodes,
			edges: rels
		},
		labels: labels
	});

}

export function groupGraph(graphRes, highlightedIDs) {
	if (typeof graphRes !== 'undefined') {
		// get all source type node
		const sourceNodes = graphRes.nodes.filter(function (n) {
			return n.labels[0].toLowerCase() == "source";
		});
		// get all excluded nodes (source & queryCategory)
		const queryCatNodes = graphRes.nodes.filter(function (n) {
			return n.labels[0].toLowerCase() == "querycategory";
		});
		//get highlighted nodes ids
		const highlightNodes = graphRes.nodes.filter(function (n) {
			return highlightedIDs.indexOf(parseInt(n.id)) > -1;
		});
		// loop highlighted nodes to find related Nodes
		highlightNodes.map((nd, index) => {
			const relatedNodes = [];
			const relatedCommonNodes = [];
			// find related eges
			let highlightEdges = graphRes.edges.filter(edg => {
				return parseInt(edg.source) == parseInt(nd.id) || parseInt(edg.target) == parseInt(nd.id)
			});
			// loop related edges & find related nodes
			highlightEdges.map(edg => {
				let related_node = null;
				if (highlightedIDs.indexOf(parseInt(edg.source)) > -1) {
					related_node = graphRes.nodes.filter(function (n) {
						return parseInt(n.id) == parseInt(edg.target) && n.labels[0].toLowerCase() != "source" && n.labels[0].toLowerCase() != "querycategory" && !n.score;
					});
				} else {
					related_node = graphRes.nodes.filter(function (n) {
						return parseInt(n.id) == parseInt(edg.source) && n.labels[0].toLowerCase() != "source" && n.labels[0].toLowerCase() != "querycategory" && !n.score;
					});
				}

				if (typeof related_node[0] !== 'undefined') {
					let node_edges = graphRes.edges.filter(function (ed) {
						return (parseInt(ed.source) == parseInt(related_node[0].id) || parseInt(ed.target) == parseInt(related_node[0].id)) && !sourceNodes.find(sourceND => parseInt(sourceND.id) === parseInt(ed.source) || parseInt(sourceND.id) === parseInt(ed.target))
					})

					if (node_edges.length == 1) {
						related_node[0].until = edg.properties.until;
						related_node[0].sourceName = edg.properties.sourceName;
						if (related_node[0].labels[0].toLowerCase() == "person") {
							related_node[0].label = edg.properties.label;
						}
						relatedNodes.push(related_node[0]);

					} else if (node_edges.length > 1) {
						related_node[0].highlightNodeEdgeId = edg.properties.edgeId;
						relatedCommonNodes.push(related_node[0]);
					}
				}
			});
			// group related nodes
			let groupedRelatedNodes = groupBy(relatedNodes, (nod) => nod.labels[0]);
			let groupedRelatedNodes_clone = JSON.parse(JSON.stringify(groupedRelatedNodes));

			// add related nodes to main node parameters
			highlightNodes[index].relNodes = groupedRelatedNodes_clone;
			highlightNodes[index].relEdges = highlightEdges.slice();

			Object.keys(groupedRelatedNodes_clone).map((key, groupIndex) => {
				// loop common related nodes & link the to corresponding group
				relatedCommonNodes.map(commonNode => {
					if (key == commonNode.labels[0]) {
						let ed_Index = graphRes.edges.findIndex(ed => parseInt(ed.edgeId) == parseInt(commonNode.highlightNodeEdgeId));
						if (ed_Index > -1) {
							if (parseInt(graphRes.edges[edgeIndex].source) == parseInt(nd.id)) {
								graphRes.edges[edgeIndex].source = groupedRelatedNodes_clone[key][0].id;
							} else {
								graphRes.edges[edgeIndex].target = groupedRelatedNodes_clone[key][0].id;
							}
						}
					}
				});
				// add each group to its first node parameters
				const firstNodeIndex = graphRes.nodes.findIndex(n => parseInt(n.id) == parseInt(groupedRelatedNodes_clone[key][0].id));
				graphRes.nodes[firstNodeIndex].groupType = "group_node";
				graphRes.nodes[firstNodeIndex].nodesGroup = groupedRelatedNodes_clone[key];
				graphRes.nodes[firstNodeIndex].groupEdges = [];
				// remove grouped nodes from graph json & remove related edges
				groupedRelatedNodes_clone[key].map((nodeG, i) => {
					nodeG.parentNodeID = groupedRelatedNodes_clone[key][0].id;
					if (i !== 0) { // keep the first node of the group
						// remove the node from graph
						let nodeIndex = graphRes.nodes.findIndex(n => parseInt(n.id) == parseInt(nodeG.id));
						if (nodeIndex > -1) {
							graphRes.nodes.splice(nodeIndex, 1);
						}
						// find all related edges
						let nodeRelatedEdges = graphRes.edges.filter(e => {
							return (parseInt(e.source) == parseInt(nodeG.id) || parseInt(e.target) == parseInt(nodeG.id)) && !queryCatNodes.find(excludedND => parseInt(excludedND.id) === parseInt(e.source) || parseInt(excludedND.id) === parseInt(e.target))
						});

						nodeRelatedEdges.map(edg => {
							let edgeIndex = graphRes.edges.findIndex(ed => parseInt(ed.edgeId) == parseInt(edg.edgeId));
							if (edgeIndex > -1) {
								// add edge to nodes group
								graphRes.edges[edgeIndex].groupType = "group_edge";
								graphRes.nodes[firstNodeIndex].groupEdges.push(graphRes.edges[edgeIndex]);
								// remove the edge from graph
								graphRes.edges.splice(edgeIndex, 1);
							}
						})
					}
				});
			});
		});
	}
}

export function getEdgeCaption(edge) {
	switch (edge.type.toLowerCase()) {
		case "position":
			if (edge.properties.label) {
				return edge.properties.sourceName ? edge.properties.label + " (" + edge.properties.sourceName + ")" : edge.properties.label;
			} else {
				return edge.properties.sourceName ? edge.properties.position + " (" + edge.properties.sourceName + ")" : edge.properties.position;
			}
			return edge.properties.label ? edge.properties.label + " (" + edge.properties.sourceName + ")" : edge.properties.position + " (" + edge.properties.sourceName + ")";
		case "located_in":
			return edge.properties.sourceName ? edge.type + " (" + edge.properties.sourceName + ")" : edge.type;
		case "found_in":
			if (typeof edge.properties.nbrResults !== 'undefined') {
				return edge.type + " {count : " + edge.properties.nbrResults + "}";
			} else {
				return edge.type;
			}
			break;

		case "has_query_category":
			if (typeof edge.properties.nbrResultsPerCat !== 'undefined' && typeof edge.properties.sourceName !== 'undefined') {
				return edge.properties.sourceName + " : " + edge.properties.nbrResultsPerCat;
			} else {
				return edge.type;
			}
			break;

		case "companyposition":
			return edge.properties.label;
			break;

		default:
			return edge.type;
	}
	;
}

export function getNodeCaption(node) {
	if (node.groupType === "group_node") {
		return node.labels[0];
	} else {
		switch (node.labels[0].toLowerCase()) {
			case "person":
				if (node.completName != null && node.completName !== 'undefined') {
					return node.completName;
				} else {
					return node.firstName + " " + node.lastName;
				}
				break;
			case "company":
				return node.companyName + (node.companyNameInNativeLang ? ": " + node.companyNameInNativeLang : "");
				break;
			case "companytype":
				return node.label;
				break;
			case "phone":
				return node.internationalCode + node.phoneNumber;
				break;
			case "address":
				return node.address;
				break;
			case "email":
				return node.email;
				break;
			case "website":
				return node.domainName;
				break;
			case "trademark":
				return node.trademark;
				break;
			case "source":
				return node.sourceName;
				break;
			case "payment":
				return node.paymentMode;
				break;
			case "activity":
				if (node.activityDescription != null && node.activityDescription !== 'undefined') {
					return node.activityDescription;
				} else {
					return node.activityCode;
				}
				break;
			case "financialreport":
				return node.labels[0];
				break;
			case "joboffer":
				return node.name;
				break;
			case "brand":
				return node.name;
				break;
			case "query":
				return node.query + " {count : " + node.nbrResults + "}";
				break;
			case "querycategory":
				return node.queryCategoryName;
				break;
			case "ipaddress":
				return node.ip;
				break;
			case "iprange":
				return node.range;
				break;
			default:
				return node.labels[0];
		}
	}
}

export function getIconByLabel(nodeData) {
	const label = nodeData.labels[0].toLowerCase();
	switch (label) {
		case 'address':
			return '<i class="wd-map-marker fs4"></i>';
			break;
		case 'company':
			return '<i class="wd-apartment fs4"></i>';
			break;
		case 'email':
			return '<i class="wd-at-sign fs4"></i>';
			break;
		case 'group':
			return '<i class="wd-users fs4"></i>';
			break;
		case 'payment':
			return '<i class="wd-credit-card fs4"></i>';
			break;
		case 'person':
			return '<i class="wd-agent fs4"></i>';
			break;
		case 'phone':
			return '<i class="wd-telephone2 fs4"></i>';
			break;
		case 'product':
			return '<i class="wd-bucket fs4"></i>';
			break;
		case 'server':
			return '<i class="wd-server fs4"></i>';
			break;
		case 'source':
			return '<i class="wd-library fs4"></i>';
			break;
		case 'trademark':
			return '<i class="wd-tag fs4"></i>';
			break;
		case 'website':
			return '<i class="wd-site fs4"></i>';
			break;
		case 'whois':
			return '<i class="wd-network fs4"></i>';
			break;
		case 'financialreport':
			return '<i class="wd-cash-euro fs4"></i>';
			break;
		case 'query':
			return '<i class="wd-magnifier fs4"></i>';
			break;
		case 'ipaddress':
			return '<i class="wd-ipaddress fs4"></i>';
			break;
		case 'iprange':
			return '<i class="wd-iprange fs4"></i>';
			break;
		case 'document':
			return '<i class="wd-document fs4"></i>';
		case 'activity':
			return '<i class="wd-briefcase fs4"></i>';
			break;
		case 'companytype':
			return '<i class="wd-pulse fs4"></i>';
			break;
		case 'sanction':
			return '<i class="wd-hammer2 fs4"></i>';
			break;
		case 'querycategory':
			const name = nodeData.queryCategoryName.toLowerCase();
			switch (name) {
				case 'litigation':
					return '<i class="wd-hammer2 fs4"></i>';
					break;
				case 'financial crime':
					return '<i class="wd-bag-euro fs4"></i>';
					break;
				case 'penal procedure':
					return '<i class="wd-briefcase fs4"></i>';
					break;
				case 'terrorism':
					return '<i class="wd-siren fs4"></i>';
					break;
				case 'judicial':
					return '<i class="wd-balance fs4"></i>';
					break;
				case 'other crimes':
					return '<i class="wd-warning fs4"></i>';
					break;
				default:
					return '<i class="wd-archive2 fs4"></i>';
			}
			break;
		default:

	}
}

export function removeByAttr(arr, attr, value) {
	let i = arr.length;
	while (i--) {
		if (arr[i]
			&& arr[i].hasOwnProperty(attr)
			&& (arguments.length > 2 && arr[i][attr] === value)) {

			arr.splice(i, 1);

		}
	}
	return arr;
}

export function paginate(array, page_size, page_number) {
	--page_number; // pages logically start with 1, but technically with 0
	return array.slice(page_number * page_size, (page_number + 1) * page_size);
}

export function extractHostname(url) {
	let hostname;
	//find & remove protocol (http, ftp, etc.) and get hostname
	if (url.indexOf("//") > -1) {
		hostname = url.split('/')[2];
	}
	else {
		hostname = url.split('/')[0];
	}

	//find & remove port number
	hostname = hostname.split(':')[0];
	//find & remove "?"
	hostname = hostname.split('?')[0];

	return hostname;
}

export function stringToArray(str, sep) {
	let dataArray = [];
	if (str != null && str != undefined) {
		if (str.length > 0) {
			dataArray = str.split(sep);
		}
	}
	return dataArray;
}

export function groupBy(xs, f) {
	return xs.reduce((r, v, i, a, k = f(v)) => ((r[k] || (r[k] = [])).push(v), r), {});
}

export function getDateFromTimestamp(unixTimeStamp) { // for datepicker fields
	let date = new Date(unixTimeStamp);
	//return ('0' + date.getDate()).slice(-2) + '/' + ('0' + (date.getMonth() + 1)).slice(-2) + '/' + date.getFullYear();
	return date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
}
