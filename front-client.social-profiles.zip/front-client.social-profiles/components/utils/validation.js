const valueHasContent = (value) =>
  Array.isArray(value) ? value.some(valueHasContent) : !!value;

export const and = (...values) => {
  return values && values.length > 0 && values.every(valueHasContent);
};

export const or = (...values) => {
  return values && values.length > 0 && values.some(valueHasContent);
};
