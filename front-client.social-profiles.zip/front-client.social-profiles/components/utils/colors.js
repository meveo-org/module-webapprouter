export const COLORS = ['orange', 'green', 'red'];

export const sumChars = (str) => {
  let sum = 0;
  for (let i = 0; i < str.length; i += 1) {
    sum += str.charCodeAt(i);
  }

  return sum;
};

export const initials = (name) => {
  if (name.length > 0 && name.length <= 2) {
    return name.toUpperCase();
  } else {
    const initialsArray = name.split(' ');
    if (initialsArray.length === 1) {
      return initialsArray[0].charAt(0).toUpperCase();
    } else {
      return `${initialsArray[0].charAt(0).toUpperCase()}${initialsArray[initialsArray.length - 1].charAt(0).toUpperCase()}`;
    }
  }    
}
