import { LitElement, html, css } from "lit-element";
import "mv-button";
import "mv-font-awesome";
import "mv-tooltip";

export class ProfilesActionColumn extends LitElement {
  static get properties() {
    return {
      profile: { type: Object, attribute: false },
      hideButton: { type: Boolean, attribute: true }
    };
  }

  static get styles() {
    return css`
      :host {
        font-family: var(--font-family, Arial);
        font-size: var(--font-size-m, 10pt);
      }

      .profiles-action-container {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
      }

      .action-button{
        --mv-button-padding: 10px 10px;
        --mv-button-min-width: 30px;
      }
      
      mv-tooltip {
        --mv-tooltip-height: 38px;
      }
    `;
  }

  constructor() {
    super();
    this.hideButton = false;
  }

  render() {
    const { profile } = this;
    const { status } = profile;
    const validateButton = this.hideButton && status === "VALIDATE" ? "display: none" : "";
    const bookmarkButton = this.hideButton && status === "BOOKMARK" ? "display: none" : "";
    return html`
      <div class="profiles-action-container">
        <mv-tooltip>
          <mv-button
            class="action-button"
            type="outline"
            button-style="cancel"
            @button-clicked="${this.handleShowScreenshot(profile)}"
          >
            <mv-fa icon="search-plus"></mv-fa>
          </mv-button>
          <span slot="tooltip-content">Magnifier</span>
        </mv-tooltip>
        
        <span style="${validateButton}">
          <mv-tooltip>
            <mv-button
              class="action-button"
              type="outline"
              ?selected="${status === "VALIDATE"}"
              ?disabled="${status === "VALIDATE"}"
              @button-clicked="${this.handleChangeStatus(profile, "VALIDATE")}"
            >
              <mv-fa icon="check"></mv-fa>
            </mv-button>
            <div slot="tooltip-content">Validate</div>
          </mv-tooltip>
        </span>
        
        <span style="${bookmarkButton}">
          <mv-tooltip>
            <mv-button
              class="action-button"
              type="outline"
              button-style="info"
              ?selected="${status === "BOOKMARK"}"
              ?disabled="${status === "BOOKMARK"}"
              @button-clicked="${this.handleChangeStatus(profile, "BOOKMARK")}"
            >
              <mv-fa icon="question-circle"></mv-fa>
            </mv-button>
            <div slot="tooltip-content">Bookmark</div>
          </mv-tooltip>
        </span>
        
        <mv-tooltip>
          <mv-button
            class="action-button"
            type="outline"
            button-style="error"
            @button-clicked="${this.handleChangeStatus(profile, "TRASH")}"
          >
            <mv-fa icon="trash-alt"></mv-fa>
          </mv-button>
          <div slot="tooltip-content">Trash</div>
        </mv-tooltip>
      </div>
    `;
  }

  handleChangeStatus(profile, status) {
    return originalEvent => {
      this.dispatchEvent(
        new CustomEvent("change-status", {
          detail: { profile, status, originalEvent }
        })
      );
    };
  }

  handleShowScreenshot(profile) {
    return originalEvent => {
      this.dispatchEvent(
        new CustomEvent("show-screenshot", {
          detail: { profile, originalEvent }
        })
      );
    };
  }

}

customElements.define("profiles-actions", ProfilesActionColumn);
